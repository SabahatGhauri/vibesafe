#!/usr/bin/env bash
# Start Game Narrator on Mac/Linux:  ./start.sh
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is missing. Install it from https://nodejs.org then run this again."; exit 1; }
if [ ! -f app/.setup-done ]; then
  echo "First run: setting things up, this takes a few minutes..."
  node setup.js || exit 1
fi
node app/server.js
