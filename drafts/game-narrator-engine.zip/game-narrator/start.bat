@echo off
rem Double-click to start Game Narrator on Windows.
cd /d "%~dp0"
if not exist "%~dp0setup.js" (
  echo.
  echo  It looks like you opened this from INSIDE the zip file.
  echo  Close this window, right-click game-narrator.zip, choose "Extract All...",
  echo  then open the extracted game-narrator folder and double-click start.bat there.
  echo.
  pause & exit /b 1
)
where node >nul 2>nul || (echo Node.js is missing. Install it from https://nodejs.org then run this again. & pause & exit /b 1)
if not exist app\.setup-done (
  echo First run: setting things up, this takes a few minutes...
  node setup.js || (pause & exit /b 1)
)
node app\server.js
pause
