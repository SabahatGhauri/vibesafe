// One-time setup, any OS: builds the renderer, installs Python packages, downloads the voice model.
// Run with: node setup.js   (the start scripts do this automatically the first time)
const fs = require('fs')
const path = require('path')
const https = require('https')
const { spawnSync } = require('child_process')

const ROOT = __dirname
const win = process.platform === 'win32'
const sh = (cmd, args) => {
  console.log(`> ${cmd} ${args.join(' ')}`)
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: 'inherit', shell: win })
  return r.status === 0
}

function findPython () {
  for (const cmd of ['python3', 'python', 'py']) {
    const r = spawnSync(cmd, ['--version'], { encoding: 'utf8', shell: win })
    if (r.status === 0 && /Python 3\.(1[0-9]|9)/.test(r.stdout + r.stderr)) return cmd
  }
  return null
}

function download (url, dest) {
  return new Promise((resolve, reject) => {
    const get = (u) => https.get(u, { headers: { 'User-Agent': 'game-narrator' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return get(new URL(res.headers.location, u).toString())
      if (res.statusCode !== 200) return reject(new Error(`${url}: HTTP ${res.statusCode}`))
      const total = Number(res.headers['content-length']) || 0
      let got = 0
      let last = 0
      const tmp = dest + '.part'
      const out = fs.createWriteStream(tmp)
      res.on('data', (c) => {
        got += c.length
        if (total && Date.now() - last > 1000) { last = Date.now(); process.stdout.write(`\r  ${path.basename(dest)}: ${Math.round(got / total * 100)}%   `) }
      })
      res.pipe(out)
      out.on('finish', () => { out.close(); fs.renameSync(tmp, dest); process.stdout.write(`\r  ${path.basename(dest)}: done      \n`); resolve() })
      out.on('error', reject)
    }).on('error', reject)
    get(url)
  })
}

;(async () => {
  console.log('\n== Game Narrator setup ==\n')
  if (!fs.existsSync(path.join(ROOT, 'node_modules', 'prismarine-viewer'))) {
    if (!sh('npm', ['install', '--no-audit', '--no-fund'])) process.exit(1)
  }
  if (!sh('npm', ['run', 'build-studio'])) process.exit(1)

  const py = findPython()
  if (!py) {
    console.log('\n!! Python 3.9+ was not found. Install it from https://www.python.org/downloads/ (tick "Add to PATH"), then run this again.')
    process.exit(1)
  }
  if (!sh(py, ['-m', 'pip', 'install', '-q', 'numpy', 'pillow', 'imageio-ffmpeg', 'pyyaml', 'soundfile', 'scipy', 'kokoro-onnx'])) process.exit(1)

  // A browser for rendering: use installed Chrome/Edge if present, otherwise download Playwright's Chromium.
  const hasBrowser = spawnSync(process.execPath, ['-e',
    "require('./engine/browser').launchBrowser().then(b => b.close()).then(() => process.exit(0), () => process.exit(1))"], { cwd: ROOT }).status === 0
  console.log(hasBrowser ? '> browser for rendering: found' : '> no Chrome/Edge found, downloading Chromium')
  if (!hasBrowser) sh('npx', ['playwright-core', 'install', 'chromium'])

  fs.mkdirSync(path.join(ROOT, 'models'), { recursive: true })
  const base = 'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/'
  for (const f of ['voices-v1.0.bin', 'kokoro-v1.0.onnx']) {
    const dest = path.join(ROOT, 'models', f)
    if (!fs.existsSync(dest)) await download(base + f, dest)
  }
  fs.writeFileSync(path.join(ROOT, 'app', '.setup-done'), new Date().toISOString())
  console.log('\n✔ Setup complete.\n')
})().catch((e) => { console.error('\nSetup failed:', e.message); process.exit(1) })
