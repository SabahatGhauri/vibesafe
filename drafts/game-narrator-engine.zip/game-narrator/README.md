# Game Narrator

Turns a script file into a finished Minecraft YouTube Short: a real Minecraft world, a scripted camera and actors, AI voice, music, sound effects, captions, thumbnail and upload text. There's no recording and no video editing.

## Quick start: the app

1. Install **Node.js** (https://nodejs.org, LTS) and **Python 3.10+** (https://python.org). On Windows, tick "Add python.exe to PATH".
2. Unzip this folder and double-click the start file:
   - **Windows:** `start.bat`
   - **Mac:** `start.command` (the first time, right-click it and choose Open)
   - **Linux:** `./start.sh`
3. The first start sets everything up (about 5 minutes; it downloads a ~350 MB voice model). After that it starts in seconds.
4. Your browser opens **http://localhost:4747**. Keep the black window open while you use the app.

### Using the app
1. **＋ New video**: give it a name and describe the story.
2. **✨ Write script with Claude** turns the story into shots. This needs your Anthropic API key, which you add once in Settings from https://console.anthropic.com. It costs a few cents per script. Without a key you can edit the script by hand.
3. **👀 Preview** takes about 15 seconds and shows 3 stills per shot. Fix anything that looks off.
4. **Voice:** pick the narrator and click **▶ Hear this voice**. Every spoken line is listed with **▶ Try voice**. You can also **🎙 Record** or **⬆ Upload** your own take for any line, which replaces the AI voice.
5. **YouTube details:** edit the title, description and tags, and use the copy buttons when you upload.
6. **🎬 Render video** takes about 6 minutes for a Short and about 30 minutes for a 3-minute video. When it's done, a green bar appears at the top of the page:
   - **⬇ Download video (MP4)**
   - **⬇ Thumbnail**
   - **⬇ Subtitles (.srt)**
   - **📂 Open folder**, which shows where the files are saved: `videos/<name>/` inside the app folder.
   - **Re-render shots** redoes only the shot numbers you type.
   - **Redo voice/music/captions** takes seconds and doesn't re-film anything.
   - Change the narrator voice in the dropdown.

The app only listens on your own computer (127.0.0.1). Nobody else on your network can open it.

## Command line (same engine)

```bash
node setup.js                                                # one-time setup
python3 make_video.py videos/haunted/script.yaml --preview   # ~15 s: 3 stills per shot -> preview.jpg
python3 make_video.py videos/haunted/script.yaml             # ~6 min: full video
```

Output in `videos/<name>/`:
- `<name>.mp4` is the 1080x1920 Short, 60 fps, at YouTube loudness.
- `thumbnail.jpg` is 1280x720 and `cover.jpg` is a vertical frame.
- `upload.txt` has the title, description and hashtags.

### Render speed
- On **Windows and Mac** the app uses your **graphics card** to draw frames (the black window prints `renderer: graphics card (GPU)`). That is many times faster than a computer without one.
- If the GPU doesn't work on your PC, it falls back to software automatically. To force software, set `RENDER_GPU=0`.
- `--fast` renders at 720p and upscales to 1080p: about 2x faster, and blocky Minecraft graphics still look sharp.

### Useful flags
| Flag | What it does |
|---|---|
| `--preview` | Only stills and a contact sheet, to check framing fast. |
| `--only 5,6` | Re-render only these shots and reuse the other frames. |
| `--no-render` | Keep all frames and redo only voice, music and captions (seconds). |
| `--fast` | Render at 720p and upscale to 1080p (about 2x faster). |
| `--voice gamer_hype` | Narrator voice: `gamer` (default: young, punchy Shorts voice), `gamer_hype` (loud, reactive), `gamer_chill` (relaxed), `storyteller` (warm, mystery), or any Kokoro voice (`am_michael`, `af_heart`…). |

To use **your own voice** for a line, drop `videos/<name>/my_voice/shot7.wav`. It replaces the AI line for that shot.

## Making a new video

1. Copy `videos/haunted/` to `videos/<new-name>/`.
2. Edit `script.yaml`. Or send Claude your story and it writes the file.
3. Run `--preview`, fix any framing, then run the full build.

## Script format (`script.yaml`)

Coordinates are `[x, z]` in blocks on flat ground, with north = -z. Angles: `yaw` 0 = north, 90 = east, 180 = south, 270 = west. `pitch` < 0 looks down.

```yaml
title: …            # video title (upload.txt)
description: …
tags: [minecraft, shorts]
voice: gamer        # gamer | gamer_hype | gamer_chill | storyteller | any Kokoro voice
thumbnail: {shot: 5, t: 6, text: "WHO IS THIS?"}
format: vertical    # vertical (1080x1920 Short, default) | landscape (1920x1080 long-form video, also writes an .srt)

world:
  time: dusk        # lighting preset: dusk | day | sunset | night | foggy | interior_night | cave_red | dark | cave_dark | cave_torch | glitch | void
  structures:       # ready-made set pieces
    - {type: camp, at: [0, 0]}          # campfire, barrels, crafting table, tent, log seats
    - {type: hut, at: [0, -20]}         # 5x5 hut, door at [x, z+2]; material: dirt (default) or any block
    - {type: cottage, at: [0, 0]}       # cozy 5x5 cottage, cobblestone back (north) wall, door at [x, z+3], furnace/table/bookshelf/lantern
    - {type: house, at: [26, 2]}        # small village house, door at [x, z+2]
    - {type: farm, at: [6, 6], size: [7, 5]}                  # wheat + water channel
    - {type: hill, at: [0, -13], radius: [18, 13], height: 12} # solid stone hill (dig tunnels into it with fills)
  fills:            # boxes [x0, y0, z0, x1, y1, z1, block, {props}]; use air to carve tunnels/rooms
    - [0, 64, -4, 0, 65, -6, air]
  blocks:           # single blocks: [x, y, z, block_name, {properties}]   (y 64 = first block above ground)
    - [3, 64, 5, oak_planks]
    - [0, 65, -5, redstone_wall_torch, {facing: east, lit: true}]
  paths: [[-1, -18, 2, -1]]   # rectangles [x0, z0, x1, z1] kept free of trees/flowers
  trees: 60
  plants: 500

props:                        # things that can appear/disappear
  trail: {type: items, item: dirt, block: true, points: [[0.2, -3.5], [0.8, -5.5]]}   # dropped items (bob and spin)
  sign:  {type: sign, at: [0.5, -18.9], face: 180, lines: ["line 1", "line 2"], hidden: true}   # y: optional
  bed:   {type: bed, at: [0.5, -1.0], face: 0, color: red}        # pillow end toward `face`
  chest: {type: chest, at: [1.5, -19.5], y: 61, face: 180}        # front toward `face`
  crops: {type: cubes, points: [[6, 64, 6], [7, 64, 6]], size: 0.8, style: missing}  # missing-texture blocks (style: black = void)

actors:                       # characters
  twin: {holds: wooden_shovel}                       # Steve
  ghost: {skin: alex, shade: 0.5}                    # other skin, darkened (shadow figure)
  villager1: {model: villager}                       # also: zombie, armor_stand, ... (move/turn only)
  glitch: {skin: glitch, still: true, float: 0.12, glow: 0.8}   # custom skins live in assets/skins (glitch, glitch_mouth, missing)
                                                     # still = no walk cycle, float = hover, glow = self-lit

shots:
  - note: what happens (shown on placeholder cards)
    duration: 5
    music: mystery            # mystery | tension | horror | silence | none | awkward | chase | calm | cozy | happy
                              # home (warm piano) | home_stutter (disc skips, cuts out) | warped | void (distortion)
    vo: Line the narrator says.
    vo_at: 0.6                # seconds into the shot
    vo_speed: 1.12            # optional (1.12 = the voice's normal pace)
    vo_style: shout           # optional: shout | excited | flat | quiet (CAPS + "!" lines shout automatically)
    caption: "On-screen text\n(second line)"
    caption_at: 0.6           # default = vo_at
    caption_style: big        # optional: huge red text (e.g. "WAIT.")
    light: cave_red           # optional per-shot lighting preset (or {preset, ambient, ambientColor, sun, fog: [near, far]})
    ambience: cave            # optional background sound: cave | night | clock
    camera:
      fov: 70
      floor: 64               # the y the camera stands on (tunnels, beds, hills); can also be set per key
      ease: smooth            # smooth (default) or linear between keys; a key can override with ease:
      keys:
        - {t: 0, pos: [0.5, -11.5], yaw: 0, pitch: -17}
        - {t: 4, pos: [0.5, -15.3], look: [0.5, -20]}      # or aim at a point instead of yaw/pitch
    actors:
      twin:
        keys: [{t: 0, at: [0.5, -20.3], face: 0}, {t: 4.6, at: [0.5, -20.3], face: 180}]
        # while moving, actors walk/run automatically and face where they're going
        # face: camera   -> always looks at the camera
        arm: [[0.6, 0], [0.8, 70], [1.0, 0]]   # [t, raise degrees] (placing/hitting)
        head: [[1.0, 0, 0], [1.8, 0, -23]]     # [t, yaw°, pitch°, tilt°]
        # a key can also set scale: 1.5 or [sx, sy, sz] (grows/stretches smoothly between keys)
    leash: {from: me, to: glitch, until: 2.6}  # lead rope (from: camera by default); snaps at `until`
    events:
      - {t: 0.4, door: [0, -18], open: true}   # door sound is automatic (sound: false to mute)
      - {t: 0.8, show: sign}                   # also: hide: sign
      - {t: 3.0, break: [[0, 65, -3]]}         # break blocks (break sound)
      - {t: 0.1, set: [[0, 61, -15, bedrock]]} # place blocks instantly
    hand: {item: diamond_pickaxe, swings: [1.8, 2.1]}   # first-person held item (blocks/torch works too) + swing times
    fx:
      fade: [[0, 0], [4.2, 0], [5.8, 1]]        # fade to black (1 = black)
      vignette: 0.8                              # dark edges; vignette_color: "rgba(40,0,0,1)" for red
      flicker: 0.5                               # lights flicker (0..1)
      glitch: [[4.4, 0], [5.2, 1]]               # screen glitch (0..1)
      checker: [[2.2, 0], [2.25, 0.6]]           # missing-texture checker over the screen
      grid: 0.8                                  # grey grid sky (above 1 it covers the whole screen)
      static: 0.3                                # TV static
      desktop: {text: "THANK YOU FOR THE HOME.", file: GLITCH.txt, keys: [[0, 0], [0.8, 0.26], [6.5, 0.9]]}  # fake desktop, text types itself
    sfx:                                          # extra sounds: thud, scrape, breath, sting, tick, break, swing, static, whoosh, blip (quick glitch)
      # fx.chat: [[t, "<Steve> hi"], ...] shows in-game chat lines (tick sound automatic)
      # fx.counter: [[0, 1], [4, 20]] (spins), counter_total: 20 (top level); fx.label: [[t, "Myth text"]]; fx.stamp: [[t, REAL | BUSTED]]
      - {t: 3.0, type: thud}
      - {t: 4.8, type: scrape, dur: 1.5}
    gui:                                        # container screen overlay (chest/barrel)
      title: Barrel
      items: [{slot: 0, icon: dirt, block: true, count: 23}, {slot: 10, icon: wooden_shovel}, {slot: 4, null: true}]   # null = broken item
      # highlight: "null" shows a red "null" name tooltip
      # type: trade + offers: [{cost: emerald, count: 5, result: iron_sword}, {cost: emerald, result: steve, head: steve, sold: true}]
      # highlight can step over time: [[1.4, 0], [2.2, 1]] (offer index)
      scale: [3.9, 4.9]       # zoom from -> to over `zoom` seconds
      highlight: wooden_shovel
      highlight_at: 0.6
```

Sound is automatic. Footsteps follow the camera's and actors' movement, doors and signs clack, and head-bob only happens while walking. Music sections follow each shot's `music` mood, and the video ends on a hard cut so Shorts loop.

## Folder layout

```
start.bat / start.command / start.sh   start the app (sets up on first run)
app/                 the local web app (server.js, writer.js = story -> script with Claude, public/index.html)
make_video.py        one-command pipeline
setup.js             one-time install (any OS)
engine/world.js      world + structures (add new set pieces here)
engine/render.js     camera/actor/prop animation, frame rendering, sound cues
studio/              the browser page that draws the world (three.js + prismarine-viewer)
tools/               voice (Kokoro), music, sfx, assemble (captions, mixing, loudness)
videos/<name>/       one folder per video: script.yaml (+ my_voice/)
```

## Limits

- It renders with a Minecraft world viewer, not the game client: simpler lighting and no HUD. Chests, beds and mobs aren't drawn, so use barrels and players.
- Characters use the Steve skin.
- The AI voice can't really shout. Record a line yourself when it matters.
- Minecraft textures are Mojang's. Mojang's usage guidelines allow monetized Minecraft videos, but don't imply the video is official.
