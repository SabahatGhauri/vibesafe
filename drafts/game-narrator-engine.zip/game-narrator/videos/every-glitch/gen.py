"""'Minecraft, But Every Glitch Is Real...' - ~8 min, kids style. Five real Minecraft glitches come to life, then a final boss.
Real facts used (checked): missing texture = magenta/black checkerboard the game shows when it can't find a texture;
ghost blocks = server/client desync, invisible blocks you can get stuck in; TNT duplication was patched several times and then
allowed to stay; the Nether roof (above the bedrock ceiling) is officially a glitch but players use it for farms and portal
networks; the Far Lands (12,550,821 blocks); Mojang's changelogs said "Removed Herobrine" as a running joke for years.
Run: python3 videos/every-glitch/gen.py
"""
import pathlib
import yaml

HERE = pathlib.Path(__file__).parent

NIGHT = {"preset": "night", "ambient": 0.65, "fog": [14, 60]}
DAY = "day"
ROOF = {"preset": "cave_red", "fog": [3, 26], "ambient": 0.95, "color": "#1a0606"}
RAVINE = {"preset": "day", "fog": [30, 80]}
DUSK = {"preset": "sunset", "fog": [50, 140]}


def S(t, kind, lv=0.8, **kw):
    return dict({"t": t, "type": kind, "level": lv}, **kw)


def P(t, text, c="#ffd21f"):
    return [t, text, c]


def cam(p0, l0, p1=None, l1=None, floor=None, fov=None):
    keys = [{"t": 0, "pos": p0, "look": l0}]
    if p1 is not None:
        keys.append({"t": 1, "pos": p1, "look": l1 or l0})
    if floor is not None:
        for k in keys:
            k["floor"] = floor
    c = {"keys": keys}
    if fov:
        c["fov"] = fov
    return c


def shot(vo, camera, light=DAY, music="tension", dur=0, fx=None, sfx=None, actors=None, events=None, hand=None, gui=None, style=None, note=None):
    words = len(vo.split()) if vo else 0
    d = round(max(dur + 0.4, words / 2.8 + 1.5), 1) if vo else dur
    s = {"note": note or (vo[:60] if vo else "beat"), "duration": d, "music": music, "light": light}
    if vo:
        s.update({"vo": vo, "vo_at": 0.2, "vo_speed": 1.2})
        if style:
            s["vo_style"] = style
    if fx:
        s["fx"] = fx
    s["sfx"] = [S(0, "whoosh", 0.4, dur=0.45)] + (sfx or [])
    for k, v in (("events", events), ("hand", hand), ("gui", gui)):
        if v:
            s[k] = v
    if len(camera["keys"]) > 1:
        camera["keys"][-1]["t"] = d
    s["camera"] = camera
    if actors:
        s["actors"] = actors
    return s


def level(n, name):
    return {"counter": [[0, n]], "counter_total": 5, "label": [[0, f"GLITCH {n}: {name}"]]}


def merge(*ds):
    out = {}
    for d in ds:
        out.update(d)
    return out


# ---------------------------------------------------------------- places
VILLAGE = [(14, 10), (22, 10), (21, 19)]                   # houses (door south)
CHECKER_1 = [[x, 64, z] for x in range(12, 17) for z in range(14, 17)]
CHECKER_2 = [[x, 64, z] for x in range(10, 26) for z in range(13, 22) if (x + z) % 2 == 0 or x < 18]
CHECKER_3 = [[x, y, z] for (hx, hz) in VILLAGE for x in range(hx - 2, hx + 3) for z in (hz - 2, hz + 2) for y in (64, 65, 66)]
RAV_X = (-19, -15)  # ravine floor x range (carved), crossing along x at z 0
TNT_A = [[x, 64, z] for x in (20, 22) for z in (-16, -14)]
TNT_B = [[x, 64, z] for x in range(18, 27, 2) for z in range(-19, -9, 2)]
TNT_C = [[x, 64, z] for x in range(14, 31) for z in range(-22, -6) if (x * 3 + z) % 4 == 0]
WATER = [[x, 63, z, "water", {"level": 0}] for x in range(12, 33) for z in range(-24, -4) if (x + z) % 1 == 0 and (x in (12, 32) or z in (-24, -5))]


def shots():
    L = []
    A = L.append
    # ===================== HOOK + RULES
    A(shot("Minecraft... but every glitch that ever existed is real. And they're all coming for me.",
           cam([18, 2.5], [18, 64.6, 15], [18, 3.5], [18, 64.6, 15]), dur=5.2, music="chase",
           fx={"pop": [P(0.4, "EVERY GLITCH?! 😱", "#ff3b3b")], "flash": [[0.3, "#f800f8"]], "checker": [[0, 0], [2.6, 0], [2.65, 0.5], [2.8, 0]]},
           events=[{"t": 0, "show": "mt2"}], sfx=[S(0.3, "boom", 1.0), S(2.6, "blip", 0.8)], note="HOOK - missing textures spreading"))
    A(shot("Invisible blocks. TNT that copies itself. The Nether roof. The Far Lands...",
           cam([22, 70, -2], [22, 64, -14], [24, 70, -3], [22, 64, -14]), dur=4.6, music="chase",
           events=[{"t": 0, "set": [[*p, "tnt"] for p in TNT_B]}], fx={"pop": [P(2.0, "TNT?! 💣", "#ff3b3b")]}, sfx=[S(1.9, "boom", 0.8)]))
    A(shot("And at the end... the one glitch Mojang says they removed.",
           cam([0, 9], [0, 65.6, 5.5], [0, 8.4], [0, 65.6, 5.5]), light=NIGHT, dur=4.6, music="horror",
           actors={"herobrine": {"face": "camera", "keys": [{"t": 0, "at": [0, 5.5]}]}},
           fx={"flash": [[2.4, "#ffffff"]], "pop": [P(2.5, "WHO?! 👀", "#ffffff")], "glitch": [[0, 0], [2.35, 0], [2.4, 0.6], [2.6, 0]]}, sfx=[S(2.4, "sting", 1.0)]))
    A(shot("The rules are simple. Survive five real glitches. If I beat all five, I win. Let's go!",
           cam([2.5, 7.5], [0, 65.4, 2.5], [3.5, 8.5], [0, 65.4, 2.5]), dur=5.4, music="happy",
           fx={"chat": [[0.6, "[Server] GLITCH MODE: ON"], [1.6, "[Server] Survive 5 glitches."]], "pop": [P(3.6, "LET'S GO! 🔥", "#39ff6a")]},
           sfx=[S(0.6, "tick", 0.7), S(1.6, "tick", 0.7), S(3.6, "ding", 0.6)]))

    # ===================== GLITCH 1: MISSING TEXTURE
    G1 = level(1, "MISSING TEXTURE")
    A(shot("Glitch number one: the missing texture. You've probably seen it. Pink and black squares.",
           cam([10, 13.5], [15, 64.3, 15.5], [10.6, 13.8], [15, 64.3, 15.5]), dur=5.5, music="tension",
           fx=merge(G1, {"pop": [P(3.4, "PINK + BLACK 🟪⬛", "#f800f8")]}), events=[{"t": 0, "hide": "mt2"}, {"t": 0.5, "show": "mt1"}], sfx=[S(0.5, "blip", 0.7), S(3.4, "pop", 0.6)]))
    A(shot("Real fact: when Minecraft can't find the picture for a block, it shows this pattern instead.",
           cam([15, 12.5], [14, 63.8, 15], [15.5, 12.8], [14, 63.8, 15]), dur=6, music="happy",
           fx=merge(G1, {"pop": [P(2.2, "REAL FACT 🤓", "#39ff6a")]}), events=[{"t": 0, "show": "mt1"}], sfx=[S(2.2, "ding", 0.6)]))
    A(shot("But in this world... it spreads. Like slime. Every block it touches loses its picture.",
           cam([18, 8], [18, 64, 16], [18, 7], [18, 64.5, 17]), dur=6, music="warped",
           fx=merge(G1, {"pop": [P(3.0, "IT'S SPREADING! 😨", "#ff3b3b")]}), events=[{"t": 0, "show": "mt1"}, {"t": 1.6, "show": "mt2"}],
           sfx=[S(1.6, "blip", 0.8), S(3.0, "boom", 0.8)]))
    A(shot("It swallowed the farm. Then the houses. Then the villagers!",
           cam([18, 1.5], [18, 65.3, 8], [18, 1.0], [18, 65.5, 8]), dur=5.4, music="warped",
           fx=merge(G1, {"pop": [P(3.6, "NOOO! 😭", "#ff8a00")], "checker": [[0, 0], [3.4, 0], [3.45, 0.4], [3.6, 0]]}),
           events=[{"t": 0, "show": "mt2"}, {"t": 1.0, "show": "mt3"}],
           actors={"vx1": {"face": "camera", "keys": [{"t": 0, "at": [16, 5.5]}]}, "vx2": {"face": "camera", "keys": [{"t": 0, "at": [20.5, 5.8]}]}},
           sfx=[S(1.0, "boom", 0.8), S(3.4, "blip", 0.8)]))
    A(shot("Those villagers had no faces. No skins. Just... missing.",
           cam([17.6, 3.0], [16, 65.6, 5.5], [17.4, 3.4], [16, 65.6, 5.5]), dur=5, music="horror",
           actors={"vx1": {"face": "camera", "keys": [{"t": 0, "at": [16, 5.5]}]}}, fx=merge(G1, {"vignette": 0.6}), events=[{"t": 0, "show": "mt3"}],
           sfx=[S(2.4, "sting", 0.7)]))
    A(shot("Then I noticed something. The glitch stopped every time it touched a real block I placed.",
           cam([13, 9], [13, 64.5, 13], [13.5, 9.4], [13, 64.5, 13]), dur=6, music="tension", hand={"item": "blocks/cobblestone", "swings": [3.0, 3.6]},
           events=[{"t": 0, "show": "mt2"}, {"t": 3.1, "set": [[12, 64, 12, "cobblestone"]]}, {"t": 3.7, "set": [[13, 64, 12, "cobblestone"]]}],
           fx=merge(G1, {"pop": [P(4.0, "IT STOPPED! 🤔", "#ffd21f")]}), sfx=[S(3.1, "thud", 0.6), S(3.7, "thud", 0.6)]))
    A(shot("So I built a wall. Cobblestone, wood, anything real! Faster, faster!",
           cam([14, 10.5], [18, 64.8, 12], [20, 10.5], [24, 64.8, 12]), dur=5.4, music="chase", hand={"item": "blocks/cobblestone", "swings": [0.6, 1.2, 1.8, 2.4, 3.0, 3.6, 4.2]},
           events=[{"t": 0.6 + 0.4 * i, "set": [[x, 64, 12, "cobblestone"], [x, 65, 12, "cobblestone"]]} for i, x in enumerate(range(12, 27))],
           fx=merge(G1, {"speed": 0.6, "pop": [P(1.0, "BUILD! 🧱", "#39ff6a")]}), sfx=[S(0.6, "thud", 0.5), S(1.8, "thud", 0.5), S(3.0, "thud", 0.5), S(4.2, "thud", 0.5)]))
    A(shot("And the whole thing... popped like a bubble. Glitch one: beaten!",
           cam([18, 8], [18, 65, 16]), dur=5, music="happy",
           events=[{"t": 1.0, "hide": "mt1"}, {"t": 1.0, "hide": "mt2"}, {"t": 1.0, "hide": "mt3"}],
           fx=merge(G1, {"flash": [[1.0, "#ffffff"]], "pop": [P(1.2, "BEATEN! ✅", "#39ff6a")]}), sfx=[S(1.0, "boom", 0.8), S(1.1, "sparkle", 0.8), S(2.4, "ding", 0.6)]))

    # ===================== GLITCH 2: GHOST BLOCKS
    G2 = level(2, "GHOST BLOCKS")
    A(shot("Glitch number two. I was walking home, and I hit... nothing. A wall that wasn't there!",
           cam([-6, 2], [-12, 65.6, 2], [-8.6, 2], [-12, 65.6, 2]), light=RAVINE, dur=6, music="tension",
           fx=merge(G2, {"pop": [P(3.0, "BONK! 🤕", "#ffd21f")], "flash": [[2.8, "#ffffff"]]}), sfx=[S(2.8, "thud", 1.0), S(2.9, "boing", 0.7)]))
    A(shot("Real fact: ghost blocks happen when your game and the server disagree about where a block is.",
           cam([-8.6, 2], [-12, 65.6, 2]), light=RAVINE, dur=6, music="happy",
           fx=merge(G2, {"pop": [P(2.6, "REAL FACT 🤓", "#39ff6a")]}), sfx=[S(2.6, "ding", 0.6)]))
    A(shot("Some you can see but walk through. Some you can't see... but they're solid.",
           cam([-9, 2], [-13, 65.6, 2]), light=RAVINE, dur=5.4, music="tension",
           events=[{"t": 0.8, "set": [[-11, 64, z, "glass"] for z in range(0, 5)] + [[-11, 65, z, "glass"] for z in range(0, 5)]}, {"t": 2.6, "set": [[-11, 64, z, "air"] for z in range(0, 5)] + [[-11, 65, z, "air"] for z in range(0, 5)]}],
           fx=merge(G2, {"glitch": [[0, 0], [0.8, 0.3], [1.0, 0], [2.6, 0.3], [2.8, 0]]}), sfx=[S(0.8, "blip", 0.7), S(2.6, "blip", 0.7)]))
    A(shot("Then I reached the canyon. My bridge was gone. Just a huge drop.",
           cam([-12, 0], [-17, 60, 0], [-13, 0], [-17, 57, 0]), light=RAVINE, dur=5.4, music="tension",
           fx=merge(G2, {"pop": [P(3.0, "SO DEEP 😵", "#ffffff")]}), sfx=[S(3.0, "whoosh", 0.6, dur=1.0)]))
    A(shot("Or was it? What if the bridge was still there, just invisible?",
           cam([-13, 0], [-17, 63.5, 0]), light=RAVINE, dur=4.8, music="tension", fx=merge(G2, {"pop": [P(2.4, "HMM 🤔", "#ffd21f")]}), sfx=[S(2.4, "pop", 0.5)]))
    A(shot("I had an idea. Gravel falls until it lands on something. So I dropped gravel into the canyon.",
           cam([-13, 0.6], [-16, 63.5, 0], [-13.4, 0.6], [-17, 63.5, 0]), light=RAVINE, dur=6.4, music="happy", hand={"item": "blocks/gravel", "swings": [3.6, 4.2, 4.8]},
           events=[{"t": 3.7, "set": [[-15, 64, 0, "gravel"]]}, {"t": 4.3, "set": [[-16, 64, 0, "gravel"]]}, {"t": 4.9, "set": [[-17, 64, 0, "gravel"]]}],
           sfx=[S(3.7, "thud", 0.5), S(4.3, "thud", 0.5), S(4.9, "thud", 0.5)], fx=G2))
    A(shot("And it stopped in mid air! The gravel was sitting on the invisible bridge!",
           cam([-14, 3], [-17, 63.8, 0], [-14.5, 3.5], [-17, 63.8, 0]), light=RAVINE, dur=5.4, music="happy",
           events=[{"t": 0, "set": [[x, 64, 0, "gravel"] for x in range(-19, -14)]}],
           fx=merge(G2, {"pop": [P(1.6, "GENIUS! 🧠", "#39ff6a")], "flash": [[1.5, "#ffffff"]]}), sfx=[S(1.5, "sparkle", 0.8)]))
    A(shot("I walked across, one step at a time, right on top of the gravel. Don't look down. Don't look down!",
           cam([-14, 0], [-21, 65.5, 0], [-20, 0], [-25, 65.5, 0]), light=RAVINE, dur=6, music="tension",
           fx=merge(G2, {"pop": [P(3.6, "DON'T LOOK DOWN 😬", "#ffffff")]}), sfx=[S(1.0, "step", 0.6), S(2.0, "step", 0.6), S(3.0, "step", 0.6), S(4.0, "step", 0.6)]))
    A(shot("Made it! Glitch two: beaten!",
           cam([-22, 1], [-17, 64, 0]), light=RAVINE, dur=3.4, music="happy",
           fx=merge(G2, {"pop": [P(0.8, "BEATEN! ✅", "#39ff6a")]}), sfx=[S(0.8, "ding", 0.7), S(0.9, "sparkle", 0.6)]))

    # ===================== GLITCH 3: TNT DUPLICATION
    G3 = level(3, "TNT DUPLICATION")
    A(shot("Glitch number three. I found one block of TNT in a field. Just one. Totally normal...",
           cam([18, -8], [21, 64.2, -15], [18.5, -8.5], [21, 64.2, -15]), dur=5.4, music="tension",
           events=[{"t": 0, "set": [[21, 64, -15, "tnt"]] + [[*p, "air"] for p in TNT_B]}], fx=G3))
    A(shot("Then it copied itself. Two. Four. Eight!",
           cam([18.5, -8.5], [21, 64.2, -15], [17, -7], [22, 64.2, -15]), dur=4.6, music="chase",
           events=[{"t": 0.6, "set": [[*p, "tnt"] for p in TNT_A]}, {"t": 1.6, "set": [[*p, "tnt"] for p in TNT_B]}],
           fx=merge(G3, {"pop": [P(1.7, "x8?! 💣", "#ff3b3b")]}), sfx=[S(0.6, "pop", 0.7), S(1.6, "pop", 0.8), S(1.7, "boing", 0.6)]))
    A(shot("Real fact: TNT duplication is a real glitch. Mojang fixed it again and again, and finally just let it stay.",
           cam([16, -4], [22, 64.5, -14]), dur=6.5, music="happy", events=[{"t": 0, "set": [[*p, "tnt"] for p in TNT_B]}],
           fx=merge(G3, {"pop": [P(3.4, "REAL FACT 🤓", "#39ff6a")]}), sfx=[S(3.4, "ding", 0.6)]))
    A(shot("But here, it didn't stop. The whole field filled with TNT. And then... it lit.",
           cam([22, 72, -2], [22, 64, -14], [24, 74, -2], [22, 64, -14]), dur=6, music="chase",
           events=[{"t": 0, "set": [[*p, "tnt"] for p in TNT_B]}, {"t": 1.4, "set": [[*p, "tnt"] for p in TNT_C]}],
           fx=merge(G3, {"pop": [P(4.2, "IT'S LIT! 🔥", "#ff3b3b")], "flash": [[4.0, "#ffffff"]]}), sfx=[S(1.4, "pop", 0.7), S(3.0, "riser", 0.8, dur=1.0), S(4.0, "sting", 0.7)]))
    A(shot("I remembered one thing. TNT that explodes in water doesn't break any blocks!",
           cam([14, -5], [20, 64, -12], [13.5, -4.5], [20, 64, -12]), dur=5.4, music="chase", hand={"item": "water_bucket", "swings": [3.2]},
           fx=merge(G3, {"pop": [P(2.4, "WATER! 💧", "#4ee6ff")], "speed": 0.6}), sfx=[S(2.4, "ding", 0.6)]))
    A(shot("I poured water everywhere I could!",
           cam([13.5, -4.5], [20, 63.6, -12]), dur=4, music="chase", hand={"item": "water_bucket", "swings": [0.5, 1.3, 2.1]},
           events=[{"t": 0.6, "set": [[x, 64, z, "water", {"level": 0}] for x in range(14, 31, 2) for z in range(-21, -7, 3)]}],
           fx=merge(G3, {"speed": 0.8}), sfx=[S(0.6, "whoosh", 0.6, dur=0.6), S(1.4, "whoosh", 0.6, dur=0.6)]))
    A(shot("BOOM!",
           cam([10, 68, 2], [22, 64, -14]), dur=3.4, music="none",
           events=[{"t": 0.6, "set": [[*p, "air"] for p in TNT_C + TNT_B + TNT_A]}],
           fx=merge(G3, {"flash": [[0.6, "#ffffff"], [0.9, "#ff8a00"], [1.2, "#ffffff"]], "pop": [P(0.8, "BOOOM!! 💥", "#ff8a00")]}),
           sfx=[S(0.6, "boom", 1.0), S(0.9, "boom", 1.0), S(1.2, "boom", 1.0), S(0.6, "rumble", 1.0, dur=2.0)],
           note="BOOM - camera jolts on the stings"))
    A(shot("Smoke. Water everywhere. But the ground? Not a single hole. Glitch three: beaten!",
           cam([16, -4], [22, 64, -14], [18, -5], [22, 64, -14]), dur=5.4, music="happy",
           fx=merge(G3, {"pop": [P(3.4, "BEATEN! ✅", "#39ff6a")]}), sfx=[S(3.4, "ding", 0.7), S(3.5, "sparkle", 0.6)]))

    # ===================== GLITCH 4: NETHER ROOF
    G4 = level(4, "THE NETHER ROOF")
    A(shot("Glitch number four. I blinked... and I was standing on bedrock. Red fog. Nothing else.",
           cam([-46, -46], [-40, 64.6, -52], [-46.5, -46.5], [-40, 64.6, -53]), light=ROOF, dur=6, music="horror",
           fx=merge(G4, {"flash": [[0, "#000000"]], "pop": [P(3.6, "WHERE AM I?! 😨", "#ffffff")]}), sfx=[S(0.1, "static", 0.7, dur=0.6), S(3.6, "sting", 0.6)]))
    A(shot("The Nether roof. Real fact: it's the space above the Nether's bedrock ceiling. You're not supposed to get up there.",
           cam([-44, -44], [-50, 64.4, -54], [-43, -45], [-50, 64.4, -55]), light=ROOF, dur=7, music="tension",
           fx=merge(G4, {"pop": [P(4.4, "REAL FACT 🤓", "#39ff6a")]}), sfx=[S(4.4, "ding", 0.6)]))
    A(shot("Mojang calls it a glitch. But so many players build farms up here, they never removed it.",
           cam([-46, -48], [-36, 64.4, -56]), light=ROOF, dur=6, music="tension", fx=G4))
    A(shot("It was so quiet. No mobs. No sound. Just flat bedrock, forever.",
           cam([-48, -48], [-58, 64.6, -48], [-50, -48], [-60, 64.6, -48]), light=ROOF, dur=5.4, music="none", style="quiet", fx=merge(G4, {"vignette": 0.6})))
    A(shot("Then I heard footsteps. Behind me.",
           cam([-50, -48], [-60, 64.6, -48]), light=ROOF, dur=4.6, music="none", style="quiet",
           fx=merge(G4, {"vignette": 0.75}), sfx=[S(1.6, "step", 0.8), S(2.4, "step", 0.85), S(3.2, "step", 0.9)]))
    A(shot("I turned around...",
           cam([-50, -48], [-60, 64.6, -48], [-50, -48], [-40, 65.6, -48]), light=ROOF, dur=3.6, music="horror",
           actors={"copy": {"face": "camera", "keys": [{"t": 0, "at": [-44, -48]}]}},
           fx=merge(G4, {"flash": [[2.4, "#ff2b2b"]], "pop": [P(2.5, "AAAH! 😱", "#ff3b3b")]}), sfx=[S(2.4, "sting", 1.0)]))
    A(shot("It was... me? My skin, my name. But no eyes. Just like the copies from Shadow Village!",
           cam([-48, -48], [-44, 65.6, -48]), light=ROOF, dur=6, music="horror",
           actors={"copy": {"face": "camera", "keys": [{"t": 0, "at": [-44, -48]}]}}, fx=merge(G4, {"pop": [P(3.8, "A COPY?! 👀", "#b066ff")]}),
           sfx=[S(3.8, "dundun", 0.8)]))
    A(shot("It pointed behind me. A portal! The only way off the roof!",
           cam([-48, -48], [-58, 65.6, -50.5], [-49, -48.5], [-58, 65.6, -50.5]), light=ROOF, dur=5.4, music="chase",
           fx=merge(G4, {"pop": [P(2.4, "A PORTAL! 🌀", "#b066ff")], "speed": 0.6}), sfx=[S(2.4, "sparkle", 0.7)]))
    A(shot("I ran and jumped in. Glitch four: beaten!",
           cam([-52, -50.5], [-58, 66, -50.5], [-57, -50.5], [-58.5, 66, -50.5]), light=ROOF, dur=4.4, music="chase",
           fx=merge(G4, {"speed": 1.0, "flash": [[3.2, "#b066ff"]], "pop": [P(3.3, "BEATEN! ✅", "#39ff6a")]}), sfx=[S(0.3, "riser", 0.7, dur=2.8), S(3.2, "boom", 0.8)]))

    # ===================== GLITCH 5: THE FAR LANDS
    G5 = level(5, "THE FAR LANDS")
    A(shot("The portal took me somewhere I'd been before. Glitch number five. The Far Lands.",
           cam([30, 66, 2], [52, 92, 0], [34, 66, 2], [52, 94, 0]), light=DUSK, dur=6, music="tension",
           fx=merge(G5, {"pop": [P(3.6, "NOT AGAIN! 😩", "#ff8a00")], "coords": [[0, 12550800]], "coords_yz": [70, 4]}), sfx=[S(3.6, "boing", 0.6)]))
    A(shot("If you watched my last video, you know what lives here.",
           cam([34, 2], [50, 66.5, 0]), light=DUSK, dur=4.6, music="horror",
           actors={"stretched": {"face": "camera", "scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": [49, 0]}]}},
           fx=merge(G5, {"pop": [P(2.6, "THE STRETCHED 😨", "#b066ff")]}), sfx=[S(2.6, "sting", 0.8)]))
    A(shot("But this time... it waved at me. And pointed at the sky.",
           cam([36, 2], [49, 67.5, 0], [36, 2], [49, 72, 0]), light=DUSK, dur=5.4, music="tension",
           actors={"stretched": {"face": "camera", "scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": [49, 0]}], "arm": [[0.8, 0], [1.2, 150], [1.6, 110], [2.0, 150], [2.4, 110], [3.4, 170]]}},
           fx=merge(G5, {"pop": [P(1.4, "HI?! 👋", "#ffd21f")]}), sfx=[S(1.4, "pop", 0.6)]))
    A(shot("In chat it said: the last glitch isn't here. It's at your house.",
           cam([36, 2], [49, 69, 0]), light=DUSK, dur=5.4, music="horror",
           actors={"stretched": {"face": "camera", "scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": [49, 0]}]}},
           fx=merge(G5, {"chat": [[1.2, "<Wanderer> the last glitch isn't here."], [2.8, "<Wanderer> it's at your house."]]}), sfx=[S(1.2, "tick", 0.7), S(2.8, "tick", 0.8)]))
    A(shot("The wall started glowing. Glitch five: beaten. But I had a really bad feeling.",
           cam([30, 66, 2], [52, 92, 0]), light=DUSK, dur=5.4, music="tension",
           fx=merge(G5, {"flash": [[1.0, "#ffffff"]], "pop": [P(1.3, "BEATEN?! ✅", "#39ff6a")]}), sfx=[S(1.0, "boom", 0.7), S(1.1, "sparkle", 0.7)]))

    # ===================== FINAL BOSS: "REMOVED HEROBRINE"
    A(shot("Five glitches. All beaten. I went home to celebrate.",
           cam([3, 10], [0, 65.4, 3], [2, 8], [0, 65.4, 3]), light=NIGHT, dur=4.6, music="happy",
           fx={"counter": [[0, 5]], "counter_total": 5, "pop": [P(1.8, "5 / 5 🏆", "#ffd21f")]}, sfx=[S(1.8, "ding", 0.7), S(1.9, "sparkle", 0.7)]))
    A(shot("Then chat said: Bonus glitch unlocked.",
           cam([2, 8], [0, 65.4, 3]), light=NIGHT, dur=4.6, music="tension",
           fx={"chat": [[1.0, "[Server] BONUS GLITCH UNLOCKED."]], "pop": [P(2.4, "BONUS?! 😳", "#ff3b3b")]}, sfx=[S(1.0, "tick", 0.8), S(2.3, "scratch", 0.8)]))
    A(shot("Real fact: for years, Mojang wrote removed Herobrine in their update notes. As a joke. Herobrine was never real.",
           {"keys": [{"t": 0, "pos": [2, 8], "look": [0, 65.4, 3]}]}, light=NIGHT, dur=7.6, music="none",
           fx={"fade": [[0, 1], [0.6, 1], [0.61, 0]], "desktop": {"text": "- Bug fixes\n- Removed Herobrine", "file": "changelog.txt", "keys": [[0, 0], [0.6, 0], [0.61, 0.26], [1.6, 0.3], [1.61, 0.4], [6.0, 0.9], [7.6, 0.9]]}},
           sfx=[S(1.2, "clack", 0.4), S(2.0, "tick", 0.8), S(6.2, "ding", 0.5)], note="Desktop - changelog: Removed Herobrine"))
    A(shot("So in a world where every glitch is real... what happens to the one they removed?",
           cam([1.5, 9], [0, 65.6, 4.5], [1.0, 8.2], [0, 65.6, 4.5]), light=NIGHT, dur=5.4, music="horror", fx={"vignette": 0.7}, sfx=[S(3.0, "breath", 0.6, dur=2.0)]))
    A(shot("The door opened.",
           cam([0, 9], [0, 65.6, 3]), light=NIGHT, dur=3.6, music="none", style="quiet",
           events=[{"t": 1.2, "door": [0, 3], "open": True}], sfx=[S(1.2, "scrape", 0.7, dur=0.8)], fx={"vignette": 0.75}))
    A(shot("They never removed me.",
           cam([0, 8.4], [0, 65.6, 4.4], [0, 7.8], [0, 65.6, 4.4]), light=NIGHT, dur=4.6, music="none", style="quiet",
           events=[{"t": 0, "door": [0, 3], "open": True}],
           actors={"herobrine": {"face": "camera", "glow": 0.0, "keys": [{"t": 0, "at": [0, 4.4]}]}},
           fx={"chat": [[0.4, "<Herobrine> they never removed me."]], "flash": [[2.8, "#ffffff"]], "pop": [P(2.9, "HEROBRINE?! 😱", "#ff3b3b")],
               "glitch": [[0, 0], [2.75, 0], [2.8, 0.8], [3.2, 0.25]]},
           sfx=[S(0.4, "tick", 0.8), S(2.8, "sting", 1.0), S(2.8, "boom", 1.0)]))
    A({"note": "End card", "duration": 7.0, "music": "none", "light": NIGHT,
       "vo": "Which glitch was the scariest? Comment below! And subscribe, because Herobrine... is just getting started.",
       "vo_at": 0.3, "vo_speed": 1.22,
       "caption": "WHICH GLITCH WAS THE SCARIEST?\nComment below 👇 and subscribe", "caption_at": 1.0,
       "sfx": [S(0.8, "boom", 0.7), S(1.0, "sparkle", 0.6)],
       "fx": {"flash": [[0.8, "#b066ff"]], "vignette": 0.6, "label": [[1.0, "SHADOW BLOCK TALES"]], "pop": [P(1.2, "1, 2, 3, 4 OR 5? 🤔", "#ffd21f")]},
       "camera": cam([0, 7.8], [0, 65.6, 4.4], [0, 7.2], [0, 65.6, 4.4]),
       "actors": {"herobrine": {"face": "camera", "keys": [{"t": 0, "at": [0, 4.4]}]}}})
    L[-1]["camera"]["keys"][-1]["t"] = 7.0
    return L


def main():
    houses = [{"type": "house", "at": list(v)} for v in VILLAGE]
    doc = {
        "title": "Minecraft, But Every Glitch Is Real… 😱",
        "description": ("Minecraft, but every famous glitch comes to life! Missing textures, ghost blocks, TNT duplication, the Nether roof, the Far Lands... "
                        "and the one glitch Mojang says they removed.\n\n"
                        "Real facts in this video: the pink-and-black missing texture, ghost blocks from server desync, TNT duplication "
                        "(Mojang patched it many times and then let it stay), the Nether roof (officially a glitch!), the Far Lands at 12,550,821 blocks, "
                        "and Mojang's old changelog joke \"Removed Herobrine\". The story is fiction!\n\n"
                        "Which glitch was the scariest? Comment below!\n\n#minecraft #minecrafthorror #minecraftglitch\n"),
        "tags": ["minecraft but", "minecraft glitches", "minecraft horror", "herobrine", "minecraft far lands", "nether roof", "ghost blocks", "missing texture"],
        "format": "landscape",
        "voice": "gamer",
        "grade": "vivid",
        "camera_shake": 0.3,
        "counter_total": 5,
        "thumbnail": {"shot": 1, "t": 2.0, "text": "EVERY GLITCH IS REAL", "color": "#ff3b30"},
        "world": {
            "time": "day", "seed": 21, "area": [-4, -4, 4, 2],
            "structures": [{"type": "cottage", "at": [0, 0]}] + houses + [{"type": "farm", "at": [12, 14], "size": [7, 4]},
                                                                           {"type": "farlands", "at": [50, 0], "depth": 20, "half": 40, "height": 60}],
            "fills": [
                [-22, 50, -12, -12, 62, 12, "stone"], [-19, 51, -12, -15, 63, 12, "air"],          # the canyon
                [-62, 63, -62, -30, 63, -34, "bedrock"], [-62, 64, -62, -30, 70, -34, "air"],      # the Nether roof
                [-62, 62, -62, -30, 62, -34, "bedrock"],
                [48, 64, -1, 60, 69, 1, "air"],
            ],
            "blocks": [[-58, 64, -52, "obsidian"], [-58, 64, -51, "obsidian"], [-58, 64, -50, "obsidian"], [-58, 64, -49, "obsidian"],
                       [-58, 68, -52, "obsidian"], [-58, 68, -51, "obsidian"], [-58, 68, -50, "obsidian"], [-58, 68, -49, "obsidian"]]
                      + [[-58, y, z, "obsidian"] for y in (65, 66, 67) for z in (-52, -49)]
                      + [[-58, y, z, "nether_portal", {"axis": "z"}] for y in (65, 66, 67) for z in (-51, -50)],
            "keep_clear": [[-62, -62, -30, -34], [-22, -12, -12, 12], [12, -24, 32, -4], [6, 2, 30, 26], [-4, -4, 6, 12]],
            "trees": 25, "plants": 260,
        },
        "props": {
            "mt1": {"type": "cubes", "points": CHECKER_1, "size": 0.98, "hidden": True},
            "mt2": {"type": "cubes", "points": CHECKER_2, "size": 0.98, "hidden": True},
            "mt3": {"type": "cubes", "points": CHECKER_3, "size": 1.02, "hidden": True},
        },
        "actors": {
            "herobrine": {"skin": "white_eyes"},
            "copy": {"skin": "steve_hollow", "shade": 0.1},
            "stretched": {"skin": "steve_hollow", "shade": 0.1, "still": True},
            "vx1": {"model": "villager", "skin": "missing"},
            "vx2": {"model": "villager", "skin": "missing"},
        },
        "shots": shots(),
    }
    (HERE / "script.yaml").write_text("# Minecraft, But Every Glitch Is Real (generated by gen.py)\n" + yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=200), encoding="utf-8")
    total = sum(s["duration"] for s in doc["shots"])
    print(len(doc["shots"]), "shots,", round(total, 1), "s =", f"{int(total // 60)}:{int(total % 60):02d}")


if __name__ == "__main__":
    main()
