"""Kids-style vertical Short for 'Minecraft, But Every Glitch Is Real' (~28 s, ends on FULL VIDEO LINKED BELOW)."""
import pathlib
import sys
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "shadow-village-5"))
import shorts  # noqa: E402

src = yaml.safe_load((ROOT / "every-glitch" / "script.yaml").read_text())
S = src["shots"]
take, endcard, B = shorts.take, shorts.endcard, shorts.B
P = lambda t, text, c="#ffd21f": [t, text, c]
TNT_B = [[x, 64, z, "tnt"] for x in range(18, 27, 2) for z in range(-19, -9, 2)]
TNT_C = [[x, 64, z, "tnt"] for x in range(14, 31) for z in range(-22, -6) if (x * 3 + z) % 4 == 0]
sh = [
    take(S, 0, 3.0, "Minecraft... but every glitch is real!", pops=[P(0.3, "EVERY GLITCH?! 😱", "#ff3b3b")], flashes=[[0.2, "#f800f8"]], sfx=[B(0.2)]),
    take(S, 7, 3.0, "Missing textures ate the whole village!", shift=0.9, pops=[P(1.6, "NOOO! 😭", "#ff8a00")], sfx=[{"t": 0.1, "type": "blip", "level": 0.8}]),
    take(S, 18, 3.0, "Gravel showed me an invisible bridge!", pops=[P(1.0, "GENIUS! 🧠", "#39ff6a")], flashes=[[0.9, "#ffffff"]], sfx=[{"t": 0.9, "type": "sparkle", "level": 0.8}]),
    take(S, 22, 3.0, "TNT started copying itself!", pops=[P(1.7, "x8?! 💣", "#ff3b3b")], sfx=[{"t": 1.6, "type": "pop", "level": 0.8}]),
    take(S, 27, 2.8, "BOOM!", pops=[P(0.8, "BOOOM!! 💥", "#ff8a00")], flashes=[[0.6, "#ffffff"], [0.9, "#ff8a00"]], sfx=[B(0.6), B(0.9)]),
    take(S, 34, 3.2, "On the Nether roof... I wasn't alone.", shift=0.4, pops=[P(2.1, "AAAH! 😱", "#ff3b3b")], flashes=[[2.0, "#ff2b2b"]], sfx=[B(2.0)]),
    take(S, 39, 3.0, "The Stretched was back!", pops=[P(1.2, "HIM AGAIN?! 😨", "#b066ff")], sfx=[{"t": 1.1, "type": "sting", "level": 0.8}]),
    take(S, 48, 3.6, "And the glitch Mojang said they removed...", pops=[P(2.9, "HEROBRINE?! 😱", "#ff3b3b")], flashes=[[2.8, "#ffffff"]], sfx=[B(2.8)]),
    endcard(S, 49, "MINECRAFT, BUT…"),
]
sh[0]["events"] = [{"t": 0, "show": "mt2"}]
sh[1]["events"] = [{"t": 0, "show": "mt2"}, {"t": 0.1, "show": "mt3"}]
sh[3]["events"] = [{"t": 0, "set": [[21, 64, -15, "tnt"]]}] + sh[3].get("events", [])
sh[4]["events"] = [{"t": 0, "set": TNT_B + TNT_C}] + sh[4].get("events", [])
sh[7]["events"] = [{"t": 0, "door": [0, 3], "open": True}]
sh[8]["events"] = [{"t": 0, "door": [0, 3], "open": True}]
shorts.write("every-glitch-short", src, sh, "Minecraft, But Every Glitch Is Real… 😱",
             "Minecraft, but every famous glitch comes to life... and then Herobrine shows up. The full video is linked below 👇\n\n#minecraft #minecrafthorror #minecraftglitch\n",
             {"shot": 8, "t": 3.0, "text": "EVERY GLITCH IS REAL", "color": "#ff3b30"},
             ["minecraft but", "minecraft glitches", "herobrine", "minecraft horror", "shorts"])
