"""Stills for the full-video thumbnail: a sunny day-1 island and the haunted day-100 island with the stranger."""
import sys, yaml
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from gen import *  # noqa

def doc(part, shots):
    return {"title": "thumb", "format": "landscape", "voice": "gamer", "world": world(part), "props": PROPS, "actors": ACTORS, "shots": shots}

day1 = [
    shot(None, None, still([-14, 76, 16], [0, 63, 0]), light=DAY, music="none", dur=2, actors={"me": act([1, 4], face=135)}),
    shot(None, None, still([-10, 70, 13], [0, 64, -1]), light=DAY, music="none", dur=2, actors={"me": act([1, 4], face=135)}),
]
day100 = [
    shot(None, None, still([2.2, 65.75, 8.7], [3.25, 65.55, 6.6]), light=NIGHT, music="none", dur=2,
         actors={"stranger": dict(act([3.4, 6.6], face="camera"), glow=0.25)}),
    shot(None, None, still([2.0, 65.5, 9.6], [3.0, 65.9, 6.6]), light=NIGHT, music="none", dur=2,
         actors={"stranger": dict(act([1.5, 8.2], face="camera"), glow=0.25)}),
    shot(None, None, still([-2, 66.5, 14], [2, 66, 4]), light=NIGHT, music="none", dur=2,
         actors={"stranger": dict(act([3, 9.6], face="camera"), glow=0.25)}),
]
for name, part, shots in (("thumb-day1", 1, day1), ("thumb-day100", 5, day100)):
    out = ROOT / name / "script.yaml"
    out.parent.mkdir(exist_ok=True)
    out.write_text(yaml.safe_dump(doc(part, shots), sort_keys=False), encoding="utf-8")
