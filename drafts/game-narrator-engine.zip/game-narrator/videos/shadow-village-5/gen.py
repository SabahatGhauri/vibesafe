"""SHADOW VILLAGE, Part 5 (finale): "I Escaped Shadow Village..." - first video in the kids style
(vivid grade, a sound or visual hit every ~3 s, pop text, flashes, speed lines, fast excited voice).
Run: python3 videos/shadow-village-5/gen.py  ->  videos/shadow-village-5/script.yaml
"""
import pathlib
import yaml

HERE = pathlib.Path(__file__).parent
NIGHT = {"preset": "night", "ambient": 0.75, "fog": [12, 48]}


def box(x0, y0, z0, x1, y1, z1):
    return [[x, y, z] for x in range(x0, x1 + 1) for y in range(y0, y1 + 1) for z in range(z0, z1 + 1)]


FARM = [[x, z] for x in range(4, 11) if x != 7 for z in range(7, 11)]
HOLE_A = box(9, 63, 1, 11, 63, 3)
HOLE_B = box(5, 63, -1, 7, 63, 0)
HOLE_C = box(14, 63, 3, 15, 63, 5)
HOLE_D = box(-1, 63, -8, 1, 63, -7)


def shot(vo, cam, light="day", music="chase", dur=0, sfx=None, fx=None, actors=None, events=None, note=None, gui=None, speed=1.22):
    words = len(vo.split()) if vo else 0
    d = max(dur, round(words / 3.1 + 0.7, 1)) if vo else dur
    s = {"note": note or (vo[:60] if vo else "beat"), "duration": d, "music": music, "light": light}
    if vo:
        s.update({"vo": vo, "vo_at": 0.15, "vo_speed": speed})
    if fx:
        s["fx"] = fx
    s["sfx"] = [{"t": 0, "type": "whoosh", "level": 0.45, "dur": 0.5}] + (sfx or [])
    if events:
        s["events"] = events
    if gui:
        s["gui"] = gui
    s["camera"] = cam
    if actors:
        s["actors"] = actors
    return s


def cam(*keys, fov=None):
    c = {"keys": [dict({"t": k[0], "pos": k[1], "look": k[2]}, **(k[3] if len(k) > 3 else {})) for k in keys]}
    if fov:
        c["fov"] = fov
    return c


S = lambda t, kind, lv=0.8, **kw: dict({"t": t, "type": kind, "level": lv}, **kw)
GLITCHY = {"grid": 0.8, "grade": "cold"}


def falling(at, t_fall, start_y=64.0):
    return {"face": "camera", "keys": [{"t": 0, "at": at, "y": start_y}, {"t": t_fall, "at": at, "y": start_y},
                                       {"t": t_fall + 0.5, "at": at, "y": start_y - 6}, {"t": t_fall + 0.51, "at": at, "y": -100}]}


def shots():
    L = []
    # 1 HOOK
    L.append(shot("This is the end of Shadow Village. And I have to escape... right now!",
                  cam((0, [10.5, 6.6], [10.5, 64.9, 9.0]), (3, [10.5, 6.2], [10.5, 64.9, 9.0])), light=NIGHT, music="chase", dur=3.6,
                  fx=dict(GLITCHY, pop=[[0.4, "FINALE! 😱", "#ff3b3b"]], flash=[[0.35, "#ffffff"]], speed=0.8, label=[[0, "SHADOW VILLAGE · FINALE"]]),
                  sfx=[S(0.35, "boom", 1.0)], actors={"glitchm": {"face": "camera", "keys": [{"t": 0, "at": [10.5, 7.9], "y": 64.1}]}},
                  events=[{"t": 0, "set": [[x, 64, z, "air"] for x, z in FARM], "show": "farm_x"}], note="HOOK - Glitch in my face, FINALE"))
    # 2 recap, short
    L.append(shot("Last time, Glitch woke up, and the whole village glitched!",
                  cam((0, [10.5, 8.5], [10.5, 65.0, 1.5]), (3, [10.5, 7.8], [10.5, 65.0, 1.5])), light="glitch", music="tension", dur=3.2,
                  fx=dict(GLITCHY, label=[[0, "PREVIOUSLY…"]]), sfx=[S(1.2, "blip", 0.7)],
                  actors={k: {"face": "camera", "keys": [{"t": 0, "at": a}]} for k, a in (("g1", [9.5, 1.5]), ("g2", [11.4, 2.6]), ("g3", [6.5, -0.4]), ("g4", [14.5, 3.8]))}))
    # 3 holes open
    L.append(shot("Then black holes started opening in the ground!",
                  cam((0, [10.5, 9.0], [10.5, 63.6, 2.0]), (3.5, [10.5, 8.0], [10.5, 63.4, 2.0])), light="glitch", music="chase", dur=3.6,
                  fx=dict(GLITCHY, pop=[[1.3, "VOID HOLES?! 🕳️", "#b066ff"]], flash=[[0.6, "#000000"]]),
                  sfx=[S(0.6, "boom", 1.0), S(2.3, "rumble", 0.6, dur=1.0)],
                  events=[{"t": 0.6, "show": "hole_a"}, {"t": 0.9, "show": "hole_b"}, {"t": 1.2, "show": "hole_c"}],
                  actors={k: {"face": "camera", "keys": [{"t": 0, "at": a}]} for k, a in (("g1", [9.2, 0.6]), ("g2", [12.0, 1.0]), ("g3", [6.5, 1.0]), ("g4", [14.5, 2.4]))}))
    # 4 copies fall in
    L.append(shot("And one by one... the copies fell in!",
                  cam((0, [10.5, 7.5], [10.5, 63.8, 2.0]), (3.6, [10.5, 7.2], [10.5, 63.6, 2.0])), light="glitch", music="chase", dur=3.8,
                  fx=dict(GLITCHY, pop=[[2.6, "BYE BYE! 👋", "#ffd21f"]]),
                  sfx=[S(0.8, "whoosh", 0.7, dur=0.6), S(1.5, "whoosh", 0.7, dur=0.6), S(2.2, "whoosh", 0.7, dur=0.6), S(2.9, "boing", 0.6)],
                  actors={"g1": falling([10.0, 2.0], 0.8), "g2": falling([11.0, 2.6], 1.5), "g3": falling([6.0, -0.5], 2.2), "g4": falling([14.5, 4.0], 2.9)}))
    # 5 the Seer too
    L.append(shot("Even the Seer! The villager who started all of this!",
                  cam((0, [8.0, 3.8], [10.5, 64.6, 2.0]), (3.4, [8.4, 3.6], [10.5, 64.4, 2.0])), light="glitch", music="chase", dur=3.6,
                  fx=dict(GLITCHY, pop=[[1.6, "NOOO! 😭", "#ff8a00"]]), sfx=[S(1.4, "whoosh", 0.8, dur=0.7), S(2.0, "sting", 0.7)],
                  actors={"seerx": {"keys": [{"t": 0, "at": [10.4, 2.0], "y": 64, "face": 270}, {"t": 1.3, "at": [10.4, 2.0], "y": 64, "face": 270},
                                             {"t": 1.9, "at": [10.4, 2.0], "y": 58, "face": 270}, {"t": 1.91, "at": [10.4, 2.0], "y": -100}]}}))
    # 6 run
    L.append(shot("So I ran! As fast as I could, to the hill!",
                  cam((0, [6.5, 2.0], [3, 65.6, -8]), (3.4, [4.0, -6.5], [0.5, 65.6, -11])), light="glitch", music="chase", dur=3.5,
                  fx=dict(GLITCHY, speed=[[0, 0.5], [1.0, 1.0], [3.5, 1.0]], pop=[[0.9, "RUN!! 🏃", "#ff4040"]]),
                  sfx=[S(0.2, "riser", 0.6, dur=2.0)]))
    # 7 hole in front
    L.append(shot("But the void was faster than me!",
                  cam((0, [1.0, -3.5], [0.5, 63.6, -7.5]), (2.8, [0.8, -4.6], [0.5, 63.4, -7.5])), light="glitch", music="chase", dur=3.2,
                  fx=dict(GLITCHY, flash=[[0.5, "#ff2b2b"]], speed=0.6, pop=[[0.6, "WATCH OUT! ⚠️", "#ff2b2b"]]),
                  sfx=[S(0.5, "boom", 1.0), S(0.5, "sting", 0.8)], events=[{"t": 0.5, "show": "hole_d"}]))
    # 8 Glitch blocks the hill
    L.append(shot("And standing in front of the hill... was Glitch.",
                  cam((0, [0.5, -5.2], [0.5, 65.4, -10.5]), (3.5, [0.5, -5.6], [0.5, 65.4, -10.5])), light="glitch", music="none", dur=3.8,
                  fx=dict(GLITCHY, vignette=0.6), sfx=[S(0.4, "dundun", 0.9)],
                  actors={"glitchm": {"face": "camera", "keys": [{"t": 0, "at": [0.5, -10.5], "y": 64.2}]}}))
    # 9 he types
    L.append(shot("I thought it was over. But he didn't attack. He typed something.",
                  cam((0, [0.5, -6.6], [0.5, 65.6, -10.5]), (4, [0.5, -7.2], [0.5, 65.6, -10.5])), light="glitch", music="music_box", dur=4.4,
                  fx=dict(GLITCHY, chat=[[2.6, "<null> you gave me a home."]]), sfx=[S(1.4, "blip", 0.6)],
                  actors={"glitchm": {"face": "camera", "keys": [{"t": 0, "at": [0.5, -10.5], "y": 64.2}]}}))
    # 10 now i give you one
    L.append(shot("Then...",
                  cam((0, [0.5, -7.2], [0.5, 65.6, -10.5]), (3, [0.5, -7.6], [0.5, 65.7, -10.5])), light="glitch", music="music_box", dur=3.2,
                  fx=dict(GLITCHY, chat=[[0.3, "<null> you gave me a home."], [0.8, "<null> now i give you yours."]], pop=[[1.6, "WHAT?! 🤯", "#ffd21f"]]),
                  sfx=[S(0.8, "tick", 0.8), S(1.5, "scratch", 0.8)],
                  actors={"glitchm": {"face": "camera", "keys": [{"t": 0, "at": [0.5, -10.5], "y": 64.2}]}}))
    # 11 fixed
    L.append(shot("The holes closed. The farm grew back. The colours came back!",
                  cam((0, [10.5, 13.0], [8.0, 64.2, 6.0]), (4.2, [11.5, 12.0], [8.0, 64.4, 5.0])), light="day", music="happy", dur=4.4,
                  fx={"pop": [[1.4, "IT'S FIXED! ✨", "#39ff6a"]], "flash": [[0.4, "#ffffff"]]},
                  sfx=[S(0.4, "sparkle", 0.8), S(1.4, "ding", 0.6), S(2.6, "sparkle", 0.7)],
                  events=[{"t": 0.4, "hide": "hole_a"}, {"t": 0.4, "hide": "hole_b"}, {"t": 0.4, "hide": "hole_c"}, {"t": 0.4, "hide": "hole_d"},
                          {"t": 0.4, "hide": "farm_x", "set": [[x, 64, z, "wheat", {"age": 7}] for x, z in FARM]}]))
    # 12 villagers back
    L.append(shot("Real villagers walked out of their houses, like nothing ever happened.",
                  cam((0, [10.5, 5.5], [14, 65.0, -1]), (4.5, [11.5, 5.0], [16, 65.0, -1])), light="day", music="happy", dur=4.6,
                  fx={"pop": [[2.2, "YAY! 🎉", "#ffd21f"]]}, sfx=[S(1.0, "pop", 0.6), S(2.2, "ding", 0.5)],
                  actors={"v1": {"keys": [{"t": 0, "at": [11.0, -2.8], "face": 180}, {"t": 4.5, "at": [12.5, 0.5], "face": 160}]},
                          "v2": {"keys": [{"t": 0, "at": [17.0, 1.2], "face": 270}, {"t": 4.5, "at": [15.0, 0.5], "face": 270}]}}))
    # 13 Glitch floats away
    L.append(shot("And Glitch? He just smiled, and floated up into the sky.",
                  cam((0, [0.5, -4.5], [0.5, 66.0, -10.5]), (4.4, [0.5, -4.8], [0.5, 70.5, -10.5])), light="sunset", music="happy", dur=4.6,
                  fx={"pop": [[2.8, "BYE GLITCH 🥲", "#ffffff"]]}, sfx=[S(0.6, "sparkle", 0.7), S(2.8, "pop", 0.5)],
                  actors={"glitchm": {"face": "camera", "keys": [{"t": 0, "at": [0.5, -10.5], "y": 64.2}, {"t": 4.6, "at": [0.5, -10.5], "y": 71.0}]}}))
    # 14 desktop
    L.append(shot("Then my game closed by itself. And there was a new file on my desktop.",
                  {"keys": [{"t": 0, "pos": [0.5, -4.8], "look": [0.5, 70.5, -10.5]}]}, light="sunset", music="none", dur=7.0,
                  fx={"fade": [[0, 1], [0.8, 1], [0.81, 0]],
                      "desktop": {"text": "YOU'RE WELCOME.", "file": "GLITCH.txt", "keys": [[0, 0], [0.8, 0], [0.81, 0.26], [1.9, 0.3], [1.91, 0.4], [5.6, 0.9], [7, 0.9]]}},
                  sfx=[S(1.3, "clack", 0.4), S(2.25, "tick", 0.9), S(5.8, "ding", 0.6)], note="Desktop - GLITCH.txt types YOU'RE WELCOME."))
    # 15 escaped
    L.append(shot("I opened Minecraft again. Sunshine. Birds. Everything normal. I escaped!",
                  cam((0, [2.5, 10.0], [0, 65.5, 3.0]), (4.5, [1.8, 8.0], [0, 65.5, 3.0])), light="day", music="happy", dur=4.8,
                  fx={"pop": [[2.6, "I ESCAPED!! 🥳", "#39ff6a"]], "flash": [[2.5, "#ffd21f"]]}, sfx=[S(2.5, "boom", 0.7), S(2.6, "sparkle", 0.8)]))
    # 16 wait...
    L.append(shot("Wait...",
                  cam((0, [1.8, 8.0], [0, 65.5, 3.0]), (2.6, [1.8, 8.0], [1.4, 65.5, 5.4])), light="day", music="none", dur=2.8,
                  fx={"pop": [[0.5, "WAIT... 😨", "#ffffff"]], "grade": "cold"}, sfx=[S(0.1, "scratch", 0.9)],
                  actors={"seer": {"keys": [{"t": 0, "at": [1.4, 5.4], "face": 160}]}}))
    # 17 the trade
    L.append(shot("The Seer was standing at my spawn. With one last trade. One emerald... for me.",
                  {"keys": [{"t": 0, "pos": [1.6, 7.2], "look": [1.4, 65.5, 5.4]}]}, light="day", music="horror", dur=5.6,
                  gui={"type": "trade", "title": "Villager", "offers": [{"cost": "emerald", "count": 1, "result": "steve", "head": "steve"}],
                       "highlight": 0, "highlight_at": 0.4, "scale": [4.2, 4.8], "top": 160},
                  fx={"pop": [[3.6, "ME?! 😱", "#ff3b3b"]]}, sfx=[S(3.5, "dundun", 0.9)],
                  actors={"seer": {"keys": [{"t": 0, "at": [1.4, 5.4], "face": 160}]}}))
    # 18 not over
    L.append(shot("Shadow Village... isn't over.",
                  cam((0, [1.6, 6.9], [1.4, 65.6, 5.4]), (3, [1.55, 6.6], [1.4, 65.6, 5.4])), light="day", music="none", dur=3.4,
                  fx={"grade": "cold", "vignette": 0.6, "glitch": [[0, 0], [2.0, 0], [2.05, 0.7], [2.3, 0]]},
                  sfx=[S(2.0, "sting", 1.0), S(2.0, "blip", 0.9)],
                  actors={"seer": {"face": "camera", "keys": [{"t": 0, "at": [1.4, 5.4]}]}}))
    # 19 end card
    L.append({"note": "End card - Season 2?", "duration": 6.0, "music": "none", "light": "day",
              "vo": "Should I go back for season two? Comment YES below!", "vo_at": 0.3, "vo_speed": 1.2,
              "caption": "SEASON 2?!\nComment YES 👇 and subscribe", "caption_at": 1.0,
              "sfx": [S(0.8, "boom", 0.8), S(1.0, "sparkle", 0.6)],
              "fx": {"flash": [[0.8, "#b066ff"]], "vignette": 0.5, "pop": [[1.0, "SEASON 2?! 🔥", "#ffd21f"]], "label": [[1.0, "SHADOW VILLAGE · FINALE"]]},
              "camera": cam((0, [1.6, 6.9], [1.4, 65.6, 5.4]), (6, [1.7, 7.4], [1.4, 65.6, 5.4])),
              "actors": {"seer": {"face": "camera", "keys": [{"t": 0, "at": [1.4, 5.4]}]}}})
    return L


def main():
    doc = {
        "title": "I Escaped Shadow Village in Minecraft… (FINALE) | Minecraft Horror",
        "description": ("Minecraft horror story finale: black void holes swallowed the whole village, and Glitch was waiting for me at the hill... "
                        "but this time he didn't attack. Did I really escape Shadow Village?\n"
                        "Shadow Village is a Minecraft creepypasta series. Watch Parts 1–4 first! Should I make Season 2? Comment YES!\n\n"
                        "#minecraft #minecrafthorror #minecraftcreepypasta\n"),
        "tags": ["minecraft horror", "minecraft creepypasta", "scary minecraft", "minecraft glitch", "shadow village", "minecraft finale"],
        "format": "landscape",
        "voice": "gamer",
        "grade": "vivid",
        "thumbnail": {"shot": 17, "t": 4.0, "text": "1 EMERALD = ME?!", "color": "#ff3b30"},
        "world": {
            "time": "sunset", "seed": 5,
            "structures": [{"type": "hill", "at": [0, -24], "radius": [16, 12], "height": 12}, {"type": "cottage", "at": [0, 0]},
                           {"type": "house", "at": [11, -6]}, {"type": "house", "at": [17, 3]}, {"type": "house", "at": [24, -5]},
                           {"type": "farm", "at": [4, 7], "size": [7, 4]}],
            "fills": [[-1, 64, -11, 1, 66, -24, "air"], [-4, 64, -24, 4, 68, -30, "air"]],
            "blocks": [[8, 64, -2, "oak_fence"], [8, 65, -2, "lantern"], [23, 64, -6, "lantern"]],
            "paths": [[-4, -12, 28, 14]], "trees": 40,
        },
        "props": {
            "farm_x": {"type": "cubes", "points": [[x, 64, z] for x, z in FARM], "size": 0.8, "hidden": True},
            "hole_a": {"type": "cubes", "style": "black", "points": [[x, y + 0.04, z] for x, y, z in HOLE_A], "size": 1.0, "hidden": True},
            "hole_b": {"type": "cubes", "style": "black", "points": [[x, y + 0.04, z] for x, y, z in HOLE_B], "size": 1.0, "hidden": True},
            "hole_c": {"type": "cubes", "style": "black", "points": [[x, y + 0.04, z] for x, y, z in HOLE_C], "size": 1.0, "hidden": True},
            "hole_d": {"type": "cubes", "style": "black", "points": [[x, y + 0.04, z] for x, y, z in HOLE_D], "size": 1.0, "hidden": True},
        },
        "actors": {
            "seer": {"model": "villager", "skin": "villager_hollow"},
            "seerx": {"model": "villager", "skin": "missing"},
            "v1": {"model": "villager"}, "v2": {"model": "villager"},
            "glitchm": {"skin": "glitch_mouth", "still": True, "float": 0.08, "glow": 0.8},
            "g1": {"skin": "glitch", "still": True, "glow": 0.5}, "g2": {"skin": "glitch", "still": True, "glow": 0.5},
            "g3": {"skin": "glitch", "still": True, "glow": 0.5}, "g4": {"skin": "glitch", "still": True, "glow": 0.5},
        },
        "shots": shots(),
    }
    (HERE / "script.yaml").write_text("# SHADOW VILLAGE, Part 5 (finale). Generated by gen.py; edit that file, not this one.\n"
                                      + yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=200), encoding="utf-8")
    print(len(doc["shots"]), "shots,", round(sum(s["duration"] for s in doc["shots"]), 1), "s")


if __name__ == "__main__":
    main()
