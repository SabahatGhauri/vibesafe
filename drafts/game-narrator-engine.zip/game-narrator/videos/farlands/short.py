"""Kids-style vertical Short for the Far Lands video (~30 s, ends on FULL VIDEO LINKED BELOW)."""
import pathlib
import sys
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "shadow-village-5"))
from shorts import take, endcard, write, B  # noqa: E402

src = yaml.safe_load((ROOT / "farlands" / "script.yaml").read_text())
S = src["shots"]
P = lambda t, text, c="#ffd21f": [t, text, c]
shots = [
    take(S, 0, 3.4, "This place was deleted from Minecraft. So why is it in MY world?", pops=[P(0.4, "THE FAR LANDS?! 😱", "#ff3b3b")], flashes=[[0.2, "#ffffff"]], sfx=[B(0.2)]),
    take(S, 15, 3.0, "A sign by my bed said: come to the edge.", pops=[P(1.4, "WHO DID THIS?! 🤔")], sfx=[{"t": 1.3, "type": "scratch", "level": 0.8}]),
    take(S, 34, 3.0, "So I went. And it was REAL!", shift=1.5, pops=[P(1.1, "IT'S REAL! 😱", "#ff3b3b")], flashes=[[1.0, "#ffffff"]], sfx=[B(1.0)]),
    take(S, 55, 3.4, "Inside, a journal. I think I'm getting taller.", pops=[P(2.4, "TALLER?! 😨", "#ff3b3b")], sfx=[{"t": 2.3, "type": "dundun", "level": 0.8}]),
    take(S, 59, 3.0, "Then THIS came around the corner!", pops=[P(0.8, "AAAH! 😱", "#ff3b3b")], flashes=[[0.6, "#ff2b2b"]], sfx=[B(0.6)]),
    take(S, 62, 3.0, "Every time I blinked, it got closer!", shift=0.6, pops=[P(2.4, "RUN!! 🏃", "#ff4040")]),
    take(S, 81, 3.0, "I fixed my portal just in time!", pops=[P(1.2, "YES!! 🌀", "#b066ff")], flashes=[[1.0, "#b066ff"]], sfx=[B(1.0, 0.8)]),
    take(S, 87, 3.4, "But at home... my coordinates were still twelve million.", pops=[P(2.4, "WAIT... 😨", "#ffffff")], sfx=[{"t": 0.1, "type": "scratch", "level": 0.8}]),
    take(S, 88, 3.0, "And something tall was outside.", shift=2.6, sfx=[{"t": 1.2, "type": "sting", "level": 1.0}]),
    endcard(S, 93, "THE FAR LANDS"),
]
shots[1]["events"] = [{"t": 0, "show": "edge_sign"}]
shots[3]["events"] = [{"t": 0, "show": "camp_bed"}, {"t": 0, "show": "camp_chest"}]
write("farlands-short", src, shots, "I Found the Far Lands in Minecraft… 😱",
      "Minecraft horror: the Far Lands were deleted in 2011... so why are they in my world? The full video is linked below 👇\n\n#minecraft #minecrafthorror #farlands\n",
      {"shot": 5, "t": 1.5, "text": "THE FAR LANDS", "color": "#ff3b30"},
      ["minecraft far lands", "minecraft horror", "minecraft glitch", "scary minecraft", "shorts"])
