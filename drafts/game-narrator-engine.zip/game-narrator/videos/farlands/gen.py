"""'I Found the Far Lands in Minecraft... Something Lives There' - ~10 min glitch horror, kids style.
Real facts used: the Far Lands appeared 12,550,821 blocks from spawn because of math (floating-point) errors in the
terrain generator; Mojang removed them in Beta 1.8 (2011); 1 block in the Nether = 8 blocks in the Overworld;
sprinting 12.5 million blocks would take about 620 hours. The story itself is fiction.
Run: python3 videos/farlands/gen.py  ->  videos/farlands/script.yaml
"""
import pathlib
import yaml

HERE = pathlib.Path(__file__).parent
FAR = 12550821

# ---------------------------------------------------------------- places
HOME = (-20, 10)            # cottage, door at (-20, 13)
HOME_PORTAL_X = -28         # obsidian frame at x -28, z 6..9
FL_PORTAL_X = 30            # arrival portal frame at x 30, z 8..11
NETHER = (-62, -40)         # nether room x -62..-36, z -40..-20


def frame(x, z0, broken=False, base=64):
    """Obsidian frame 4 wide (z0..z0+3) x 5 tall (y 64..68) in the plane x = const; interior z0+1..z0+2, y 65..67."""
    b = []
    for z in range(z0, z0 + 4):
        b += [[x, base, z, "obsidian"], [x, base + 4, z, "obsidian"]]
    for y in range(base + 1, base + 4):
        b += [[x, y, z0, "obsidian"], [x, y, z0 + 3, "obsidian"]]
    if broken:
        b = [p for p in b if not (p[2] == z0 + 3 and p[1] in (base + 2, base + 3)) and not (p[1] == base + 4 and p[2] >= z0 + 2)]
    return b


def portal(x, z0, base=64):
    return [[x, y, z, "nether_portal", {"axis": "z"}] for z in (z0 + 1, z0 + 2) for y in range(base + 1, base + 4)]


def air(blocks):
    return [[b[0], b[1], b[2], "air"] for b in blocks]


HOME_FRAME = frame(HOME_PORTAL_X, 6)
FL_FRAME = frame(FL_PORTAL_X, 8)
FL_BROKEN_MISSING = [p for p in FL_FRAME if p not in frame(FL_PORTAL_X, 8, broken=True)]
NF = 31  # nether floor surface (the room is underground)
NE_IN = frame(-58, -33, base=NF)
NE_OUT = frame(-40, -33, base=NF)

# ---------------------------------------------------------------- shot helpers
DUSK = {"preset": "sunset", "fog": [50, 140]}
FLDAY = {"preset": "day", "fog": [60, 150]}
NIGHT = {"preset": "night", "ambient": 0.6, "fog": [14, 60]}
TUNNEL = {"preset": "cave_dark", "ambient": 0.8, "fog": [3, 24]}
NETHERL = {"preset": "cave_red", "fog": [4, 28], "ambient": 0.85}
CAMP = {"preset": "cave_torch", "ambient": 0.75, "fog": [3, 20]}


def S(t, kind, lv=0.8, **kw):
    return dict({"t": t, "type": kind, "level": lv}, **kw)


def cam(p0, l0, p1=None, l1=None, dur=6, fov=None, floor=None):
    k0 = {"t": 0, "pos": p0, "look": l0}
    keys = [k0]
    if p1 is not None:
        keys.append({"t": dur, "pos": p1, "look": l1 or l0})
    if floor is not None:
        for k in keys:
            k["floor"] = floor
    c = {"keys": keys}
    if fov:
        c["fov"] = fov
    return c


def shot(vo, camera, light="day", music="tension", dur=0, fx=None, sfx=None, actors=None, events=None, hand=None, note=None, gui=None, speed=1.2, style=None):
    words = len(vo.split()) if vo else 0
    d = round(max(dur + 0.5, words / 2.8 + 1.6), 1) if vo else dur
    s = {"note": note or (vo[:60] if vo else "beat"), "duration": d, "music": music, "light": light}
    if vo:
        s.update({"vo": vo, "vo_at": 0.2, "vo_speed": speed})
        if style:
            s["vo_style"] = style
    if fx:
        s["fx"] = fx
    s["sfx"] = [S(0, "whoosh", 0.4, dur=0.45)] + (sfx or [])
    if events:
        s["events"] = events
    if hand:
        s["hand"] = hand
    if gui:
        s["gui"] = gui
    # keep the last camera key at the shot's end
    if len(camera["keys"]) > 1:
        camera["keys"][-1]["t"] = d
    s["camera"] = camera
    if actors:
        s["actors"] = actors
    return s


def pop(t, text, color="#ffd21f"):
    return [t, text, color]


def coords(x0, x1=None, g=0):
    f = {"coords": [[0, x0]] + ([[6, x1]] if x1 is not None else []), "coords_yz": [70, 4]}
    if g:
        f["coords_glitch"] = g
    return f


STRETCH = lambda at, face="camera", **kw: dict({"face": face, "scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": at}]}, **kw) if face == "camera" else dict({"scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": at, "face": face}]}, **kw)
WALL_WIDE = ([4, 72, 0], [40, 96, 0])


# ---------------------------------------------------------------- the story
def shots():
    L = []
    A = L.append
    # ===== HOOK
    A(shot("This place was deleted from Minecraft fifteen years ago. So why... is it in my world?",
           cam([6, 70, 2], [40, 95, 0], [10, 69, 1], [40, 95, 0]), light=FLDAY, music="tension", dur=6,
           fx=dict(coords(FAR, FAR + 4, 0.0), pop=[pop(3.6, "THE FAR LANDS?! 😱", "#ff3b3b")], label=[[0, "THE FAR LANDS"]]),
           sfx=[S(3.5, "boom", 1.0)], note="HOOK - the Far Lands wall, F3 at 12,550,821"))
    A(shot("And what is that... inside the wall?",
           cam([40, 0], [56, 65.8, 0], [41, 0], [56, 65.8, 0]), light=TUNNEL, music="horror", dur=4.4,
           fx={"flash": [[2.6, "#ffffff"]], "pop": [pop(2.7, "WHAT?! 👀", "#ffffff")], "glitch": [[0, 0], [2.55, 0], [2.6, 0.6], [2.8, 0]]},
           sfx=[S(2.6, "sting", 0.9)], actors={"stretched": STRETCH([55, 0])}))
    A(shot("Stay to the end, because the ending of this video is the scariest thing I've ever seen in Minecraft.",
           cam(*WALL_WIDE), light=DUSK, music="tension", dur=5.5, fx={"pop": [pop(1.2, "WATCH TILL THE END 👇", "#39ff6a")]}, sfx=[S(1.1, "ding", 0.5)]))
    # ===== FACTS
    A(shot("Okay. First, what are the Far Lands? Back in old Minecraft, the world wasn't really endless.",
           cam([-14, 16], [-20, 66, 10], [-11, 18], [-20, 66, 10]), light="day", music="happy", dur=5.5,
           fx={"pop": [pop(1.0, "STORY TIME 📖", "#ffd21f")]}, sfx=[S(1.0, "pop", 0.5)]))
    A(shot("If you walked twelve million, five hundred fifty thousand, eight hundred twenty-one blocks from spawn...",
           cam([20, 30], [60, 64, 30], [26, 30], [66, 64, 30]), light="day", music="happy", dur=6,
           fx=dict(coords(0, FAR), speed=0.6), sfx=[S(0.3, "riser", 0.5, dur=4)]))
    A(shot("...the game's math broke. The numbers got so big, the terrain generator couldn't handle them.",
           cam(*WALL_WIDE), light=FLDAY, music="tension", dur=6,
           fx=dict(coords(FAR, g=0.3), pop=[pop(1.6, "MATH ERROR 🤯", "#b066ff")]), sfx=[S(1.5, "blip", 0.8), S(1.6, "boom", 0.8)]))
    A(shot("And the world turned into this. Giant walls. Stretched layers. Tunnels that go on forever.",
           cam([30, 76, -20], [48, 90, 6], [30, 80, 20], [48, 94, -6]), light=FLDAY, music="tension", dur=6.5,
           fx={"pop": [pop(2.0, "WOW 😮", "#ffffff")]}, sfx=[S(2.0, "sparkle", 0.6)]))
    A(shot("And if you went to the corner, where both X and Z were that big, it got even weirder. The ground turned into giant pillars.",
           cam([2, 67, -24], [22, 76, -38], [5, 67, -26], [24, 78, -38]), light=FLDAY, music="tension", dur=7,
           events=[{"t": 0, "set": [[x, y, z, "stone"] for x in range(14, 30, 3) for z in range(-44, -31, 3) for y in range(64, 64 + 10 + (x * 7 + z * 3) % 22)]}],
           fx={"pop": [pop(3.6, "PILLARS?! 🗼", "#4ee6ff")]}, sfx=[S(3.5, "boom", 0.7)]))
    A(shot("The game ran slow. Lights flickered. Mobs shook in place. Players said it felt like the world was dying.",
           cam([6, 66, -27], [22, 72, -38]), light=FLDAY, music="warped", dur=6.5,
           fx={"glitch": [[0, 0], [2.0, 0.3], [2.2, 0], [4.4, 0.35], [4.6, 0]], "pop": [pop(4.5, "CREEPY 😬", "#ffffff")]}, sfx=[S(2.0, "blip", 0.7), S(4.4, "blip", 0.8)]))
    A(shot("Players called it the Far Lands. Mojang fixed it in Beta 1.8, back in 2011. It was gone forever.",
           cam([18, 66, -30], [44, 82, 0], [20, 66, -18], [44, 82, 0]), light=DUSK, music="tension", dur=6.5,
           fx={"pop": [pop(3.6, "DELETED ❌", "#ff3b3b")], "flash": [[3.5, "#ff2b2b"]]}, sfx=[S(3.5, "boom", 0.8)]))
    A(shot("Walking there would take over six hundred hours of sprinting. One YouTuber spent years trying.",
           cam([0, 25], [40, 65, 25], [12, 25], [52, 65, 25]), light="day", music="happy", dur=6,
           fx=dict(coords(250000, 260000), speed=0.8, pop=[pop(1.5, "600 HOURS?! ⏰", "#ffd21f")]), sfx=[S(1.5, "boing", 0.6)]))
    A(shot("So why am I telling you this? Because last night... my world changed.",
           cam([-20, 22], [-20, 66, 12], [-20, 18], [-20, 65.5, 12]), light=NIGHT, music="horror", dur=5,
           fx={"pop": [pop(3.4, "UH OH 😨", "#ffffff")]}, sfx=[S(3.3, "scratch", 0.8)]))
    # ===== MY WORLD
    A(shot("I woke up in my house, and something felt wrong. I pressed F3 to check my coordinates.",
           cam([-21, 9.5], [-19, 65, 12.5], [-20.6, 9.5], [-19, 65.3, 12.5]), light="interior_night", music="tension", dur=6,
           fx={"vignette": 0.5}, sfx=[S(2.5, "tick", 0.7)]))
    A(shot("Minecraft Beta 1.7.3. But I'm playing the newest version! That version is fifteen years old!",
           cam([-21, 9.5], [-19, 65.3, 12.5]), light="interior_night", music="tension", dur=6,
           fx=dict(coords(-20, g=0.0), coords_yz=[64, 10], pop=[pop(1.8, "BETA 1.7.3?! 🤔", "#ffd21f")]), sfx=[S(1.7, "boom", 0.7)]))
    A(shot("Then I saw a sign next to my bed. I didn't put it there.",
           cam([-19.5, 11.6], [-21.0, 64.6, 8.8], [-19.8, 11.0], [-21.0, 64.6, 8.8]), light="interior_night", music="horror", dur=5.4,
           events=[{"t": 0, "show": "edge_sign"}], sfx=[S(2.8, "sting", 0.6)]))
    A(shot("Come to the edge. Twelve, five, five, zero, eight, two, one.",
           cam([-20.6, 10.4], [-21.0, 64.7, 8.8], [-20.8, 10.0], [-21.0, 64.7, 8.8]), light="interior_night", music="horror", dur=5.4,
           fx={"pop": [pop(2.4, "THE FAR LANDS?! 😱", "#ff3b3b")], "flash": [[2.3, "#ffffff"]]}, sfx=[S(2.3, "boom", 0.9)]))
    A(shot("And in chat, a message from a player I'd never heard of.",
           cam([-20, 16], [-20, 65.6, 13], [-20, 15.4], [-20, 65.6, 13]), light=NIGHT, music="horror", dur=5.4,
           fx={"chat": [[2.8, "<Wanderer> come see the edge."]], "vignette": 0.6}, sfx=[S(2.8, "tick", 0.8)]))
    # ===== THE PLAN
    A(shot("Six hundred hours of walking? No way. But I know a trick. The Nether!",
           cam([-24, 12], [-28, 66, 7.5], [-23, 11], [-28, 66, 7.5]), light="day", music="happy", dur=5.4,
           fx={"pop": [pop(2.6, "THE NETHER! 🔥", "#ff8a00")]}, sfx=[S(2.5, "ding", 0.6)]))
    A(shot("Every block you walk in the Nether counts as eight blocks in the normal world.",
           cam([-24, 12], [-28, 66, 7.5]), light="day", music="happy", dur=5.4,
           fx={"pop": [pop(1.6, "1 = 8 🤓", "#39ff6a")]}, sfx=[S(1.5, "pop", 0.6), S(3.0, "sparkle", 0.5)]))
    # ===== PREPARATION
    A(shot("But a trip like this needs a plan. Step one: a diamond pickaxe. Nothing else can mine obsidian.",
           cam([-6, -20], [0, 54.5, -24], [-5, -21], [0, 54.5, -24], floor=53), light={"preset": "cave_torch", "ambient": 0.95, "fog": [4, 22]}, music="happy", dur=6,
           hand={"item": "iron_pickaxe", "swings": [2.4, 3.0, 3.6]}, events=[{"t": 3.7, "set": [[0, 54, -24, "air"]]}],
           fx={"pop": [pop(4.0, "DIAMONDS! 💎", "#4ee6ff")]}, sfx=[S(3.7, "break", 0.7), S(4.0, "sparkle", 0.8)]))
    A(shot("Step two: obsidian. The trick? Pour water on lava, and it turns into obsidian. Ten blocks for one portal.",
           cam([-12, 14], [-14, 64, 18], [-11, 13.5], [-14, 64, 18]), light="day", music="happy", dur=7,
           events=[{"t": 0, "set": [[x, 63, z, "lava", {"level": 0}] for x in (-15, -14, -13) for z in (17, 18, 19)]},
                   {"t": 3.2, "set": [[x, 63, z, "obsidian"] for x in (-15, -14, -13) for z in (17, 18, 19)]}],
           hand={"item": "water_bucket", "swings": [3.0]}, fx={"pop": [pop(3.4, "SSSS! 🌋💧", "#ff8a00")], "flash": [[3.2, "#ffffff"]]}, sfx=[S(3.2, "static", 0.5, dur=0.8)]))
    A(shot("Step three: supplies. Food, torches, a compass, a bed... and a flint and steel to light the portal.",
           cam([-21, 9.5], [-19, 64.4, 9.0]), light="interior_night", music="happy", dur=6.5,
           gui={"title": "Inventory", "items": [{"slot": 0, "icon": "diamond_pickaxe"}, {"slot": 1, "icon": "flint_and_steel"}, {"slot": 2, "icon": "bread", "count": 32},
                {"slot": 3, "icon": "compass"}, {"slot": 4, "icon": "torch", "count": 64, "block": True}, {"slot": 5, "icon": "obsidian", "count": 23, "block": True},
                {"slot": 6, "icon": "red_bed"}, {"slot": 7, "icon": "iron_sword"}], "scale": [4.2, 4.8], "top": 160},
           fx={"pop": [pop(4.8, "READY! 😎", "#39ff6a")]}, sfx=[S(1.0, "pop", 0.5), S(2.0, "pop", 0.5), S(3.0, "pop", 0.5), S(4.8, "ding", 0.6)]))
    A(shot("So instead of twelve million blocks, I only need about one and a half million. Let's build a portal!",
           cam([-23.5, 10.5], [-28, 65.5, 7.5], [-24.5, 9.5], [-28, 65.5, 7.5]), light="day", music="happy", dur=6.5,
           hand={"item": "blocks/obsidian", "swings": [3.0, 3.4, 3.8, 4.2, 4.6, 5.0]},
           events=[{"t": 3.0 + 0.15 * i, "set": [b]} for i, b in enumerate(HOME_FRAME)], sfx=[S(3.0, "thud", 0.5), S(4.0, "thud", 0.5), S(5.0, "thud", 0.5)]))
    A(shot("One click with flint and steel...",
           cam([-24.5, 9.5], [-28, 66, 7.5]), light="day", music="none", dur=3.6, hand={"item": "flint_and_steel", "swings": [1.4]},
           events=[{"t": 1.5, "set": portal(HOME_PORTAL_X, 6)}], fx={"flash": [[1.5, "#b066ff"]], "pop": [pop(1.6, "WOOSH! 🌀", "#b066ff")]},
           sfx=[S(1.5, "boom", 0.7), S(1.6, "sparkle", 0.7)]))
    A(shot("And I jumped in.",
           cam([-25.5, 7.5], [-28, 66, 7.5], [-27.6, 7.5], [-28.5, 66, 7.5]), light="day", music="none", dur=2.8,
           fx={"flash": [[2.2, "#b066ff"]], "speed": [[0, 0], [1.6, 1]]}, sfx=[S(0.5, "riser", 0.6, dur=1.8)]))
    # ===== NETHER TRIP
    A(shot("The Nether. Lava everywhere. Super hot. Super dangerous.",
           cam([-56, -31.5], [-46, 32.0, -30], [-53, -31], [-44, 32.0, -29], floor=NF), light=NETHERL, music="chase", dur=5.2,
           events=[{"t": 0, "set": NE_IN + portal(-58, -33, base=NF) + NE_OUT}], fx={"pop": [pop(1.0, "SO HOT 🥵", "#ff8a00")]}, sfx=[S(1.0, "pop", 0.6)]))
    A(shot("I ran. And ran. And ran. Watch my coordinates!",
           cam([-56, -26], [-40, 32.5, -26], [-42, -26], [-30, 32.5, -26], floor=NF), light=NETHERL, music="chase", dur=5.4,
           fx=dict(coords(312, 900000), speed=1.0, pop=[pop(2.5, "ZOOM! 🏃💨", "#ffd21f")]), sfx=[S(0.2, "riser", 0.6, dur=4.5)]))
    A(shot("Then the ground just ended. One more step and I would have fallen straight into lava!",
           cam([-48, -27], [-46, 29.0, -27], [-47.4, -27], [-46, 28.5, -27], floor=NF), light=NETHERL, music="chase", dur=6,
           fx={"pop": [pop(2.4, "WHOA!! 😱", "#ff3b3b")], "flash": [[2.3, "#ff8a00"]]}, sfx=[S(2.3, "boom", 0.9), S(2.4, "scratch", 0.7)]))
    A(shot("I bridged across with cobblestone, block by block, not looking down.",
           cam([-47.5, -27], [-45, 30.6, -27], [-45.5, -27], [-43, 30.6, -27], floor=NF), light=NETHERL, music="chase", dur=5.4,
           hand={"item": "blocks/cobblestone", "swings": [1.2, 2.0, 2.8, 3.6]}, sfx=[S(1.2, "thud", 0.5), S(2.0, "thud", 0.5), S(2.8, "thud", 0.5), S(3.6, "thud", 0.5)]))
    A(shot("Every hundred thousand blocks, I placed a torch, so I'd know the way back.",
           cam([-50, -22.5], [-44, 31.5, -22.5], floor=NF), light=NETHERL, music="chase", dur=5.4, hand={"item": "blocks/torch", "swings": [2.2]},
           events=[{"t": 2.3, "set": [[-47, NF, -22, "torch"]]}], fx=dict(coords(400000, 420000), pop=[pop(2.6, "CHECKPOINT ✅", "#39ff6a")]), sfx=[S(2.6, "ding", 0.6)]))
    A(shot("Every step in here was eight steps out there. Nine hundred thousand... one million... one point five million!",
           cam([-52, -36], [-40, 32.5, -36], [-41, -36], [-30, 32.5, -36], floor=NF), light=NETHERL, music="chase", dur=6.5,
           fx=dict(coords(900000, FAR // 8), speed=1.0), sfx=[S(5.6, "ding", 0.7)]))
    A(shot("I built another portal, right at the end.",
           cam([-43, -29.5], [-40, 32.6, -31.5], floor=NF), light=NETHERL, music="tension", dur=4.2, hand={"item": "flint_and_steel", "swings": [2.4]},
           events=[{"t": 2.5, "set": portal(-40, -33, base=NF)}], fx={"flash": [[2.5, "#b066ff"]]}, sfx=[S(2.5, "sparkle", 0.6)]))
    A(shot("Took a deep breath... and stepped through.",
           cam([-42.5, -31.5], [-40, 33.0, -31.5], [-40.6, -31.5], [-39.5, 33.0, -31.5], floor=NF), light=NETHERL, music="none", dur=3.4,
           fx={"flash": [[2.8, "#ffffff"]], "speed": [[0, 0], [2, 1]]}, sfx=[S(0.4, "riser", 0.7, dur=2.4)]))
    # ===== ARRIVAL
    A(shot("I came out of the portal... and I just stood there.",
           cam([31.5, 9.8], [40, 70, 6], [33, 9.4], [40, 74, 4]), light=DUSK, music="none", dur=4.6,
           events=[{"t": 0, "set": FL_FRAME + portal(FL_PORTAL_X, 8)}], fx=coords(FAR - 12)))
    A(shot("It was real. The Far Lands. A wall of broken world, taller than anything I've ever seen.",
           cam([16, 70, 8], [44, 100, 0], [10, 68, 8], [44, 104, 0]), light=DUSK, music="tension", dur=6.5,
           fx=dict(coords(FAR - 30, FAR - 20), pop=[pop(2.6, "IT'S REAL! 😱", "#ff3b3b")], flash=[[2.5, "#ffffff"]]), sfx=[S(2.5, "boom", 1.0)]))
    A(shot("Layers of dirt and stone, stretched like someone pulled the world apart.",
           cam([36, 72, -16], [46, 76, -6], [36, 72, 16], [46, 76, 6]), light=DUSK, music="tension", dur=6, fx={"speed": 0.2}))
    A(shot("And everything here was shaking. My hands. The ground. Even the sky.",
           cam([26, 6], [42, 72, 0], [27, 5], [42, 72, 0]), light=DUSK, music="warped", dur=5.4,
           fx=dict(coords(FAR - 18, g=0.25), glitch=[[0, 0], [1.4, 0.2], [1.6, 0], [3.0, 0.25], [3.2, 0]]), sfx=[S(1.4, "blip", 0.6), S(3.0, "blip", 0.7)],
           hand={"item": "iron_sword"}))
    A(shot("That's the math breaking. The farther you go, the more everything wobbles. Real Far Lands do this too.",
           cam([26, 5], [42, 70, 0]), light=DUSK, music="warped", dur=6.5, fx=dict(coords(FAR - 18, g=0.4), pop=[pop(2.0, "WOBBLE 🌀", "#b066ff")]),
           sfx=[S(2.0, "boing", 0.6)]))
    A(shot("I wanted to see the whole thing, so I climbed. Higher and higher, up the stretched layers.",
           cam([38, 70, 10], [44, 82, 4], [40, 96, 10], [48, 104, 2]), light=DUSK, music="tension", dur=6.5, fx={"speed": 0.3}, sfx=[S(1.0, "step", 0.5), S(2.0, "step", 0.5), S(3.0, "step", 0.5)]))
    A(shot("From the top, I could see my portal, tiny, far below. And behind the wall... nothing. Just more broken world.",
           cam([46, 120, 6], [26, 64, 9], [47, 121, 4], [60, 100, -8]), light=DUSK, music="tension", dur=7,
           fx={"pop": [pop(2.2, "SO HIGH 😵", "#ffd21f")]}, sfx=[S(2.2, "whoosh", 0.6, dur=1.0)]))
    A(shot("Then I found a sign, stuck in the wall. Somebody else had been here.",
           cam([35, 3.6], [37.5, 65.4, 2.4], [35.6, 3.2], [37.5, 65.4, 2.4]), light=DUSK, music="horror", dur=5.4,
           events=[{"t": 0, "show": "sign_turn"}], sfx=[S(3.0, "sting", 0.6)]))
    A(shot("Turn back. The wall is hungry.",
           cam([36.2, 3.0], [37.5, 65.4, 2.4]), light=DUSK, music="horror", dur=4.4, style="quiet",
           events=[{"t": 0, "show": "sign_turn"}], fx={"pop": [pop(2.4, "HUNGRY?! 😨", "#ff3b3b")]}, sfx=[S(2.3, "boom", 0.8)]))
    A(shot("Then I noticed a dark tunnel, right in the middle of the wall. And torches inside.",
           cam([30, 2], [42, 65.5, 0], [34, 1], [42, 65.5, 0]), light=DUSK, music="tension", dur=6,
           fx={"pop": [pop(3.6, "SOMEONE WAS HERE 👀", "#ffd21f")]}, sfx=[S(3.5, "sting", 0.6)]))
    # ===== INSIDE / THE CAMP
    A(shot("I walked in. It was so quiet, I could hear my own footsteps.",
           cam([37, 0], [50, 65.5, 0], [44, 0], [56, 65.5, 0]), light=TUNNEL, music="none", dur=5.4, fx={"vignette": 0.6}))
    A(shot("The tunnel went deeper and deeper. My torch was the only light.",
           cam([42, 0], [56, 65.5, 0], [47, 0], [60, 65.5, 0]), light={"preset": "cave_torch", "ambient": 0.7, "fog": [3, 18]}, music="tension", dur=5.4,
           hand={"item": "blocks/torch"}, sfx=[S(1.0, "step", 0.5), S(2.0, "step", 0.5), S(3.0, "step", 0.5), S(4.0, "step", 0.5)]))
    A(shot("Then my foot hit something. An old iron sword, just lying on the ground.",
           cam([47.5, 0], [48.6, 64.1, 0.2]), light=TUNNEL, music="tension", dur=5.4,
           events=[{"t": 0, "show": "old_sword"}], fx={"pop": [pop(3.0, "WHOSE SWORD? 🗡️", "#ffd21f")]}, sfx=[S(3.0, "pop", 0.6)]))
    A(shot("And there, in the middle of the tunnel... a camp.",
           cam([47, 0.5], [53, 64.8, -4], [48.5, -0.5], [53, 64.8, -4.5]), light=CAMP, music="tension", dur=4.6,
           events=[{"t": 0, "show": "camp_bed"}, {"t": 0, "show": "camp_chest"}], sfx=[S(2.4, "ding", 0.4)]))
    A(shot("Wait. Did something just walk past the entrance?",
           cam([48.5, -0.5], [38, 66, 0], [48.5, -0.5], [38, 66.4, 0]), light=TUNNEL, music="horror", dur=4.6,
           actors={"stretched": {"scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": [37.5, -4], "face": 0}, {"t": 2.4, "at": [37.5, -4], "face": 0}, {"t": 3.2, "at": [37.5, 4], "face": 0}, {"t": 3.21, "at": [37.5, 40], "face": 0}]}},
           fx={"pop": [pop(3.2, "DID YOU SEE THAT?! 👀", "#ffffff")]}, sfx=[S(2.6, "step", 0.8), S(3.0, "step", 0.8), S(3.2, "blip", 0.7)]))
    A(shot("Nothing there. Probably just my imagination. Right?",
           cam([48.5, -0.5], [38, 66, 0]), light=TUNNEL, music="tension", dur=4.4, fx={"chat": [[3.0, "<Wanderer> you came."]]}, sfx=[S(3.0, "tick", 0.8)]))
    A(shot("Another sign, carved into the tunnel wall. He is tall now. Don't let him see you.",
           cam([49.5, 0.2], [51.5, 65.4, -1.4], [49.8, 0.1], [51.5, 65.4, -1.4]), light=CAMP, music="horror", dur=6,
           events=[{"t": 0, "show": "sign_tall"}], fx={"pop": [pop(3.8, "WHO IS TALL?! 😱", "#ff3b3b")]}, sfx=[S(3.7, "dundun", 0.8)]))
    A(shot("A bed. A chest. A crafting table. Someone lived here. For a long, long time.",
           cam([50.5, -2.6], [53.5, 64.4, -5.5], [51.5, -3.0], [54.5, 64.4, -6.0]), light=CAMP, music="tension", dur=6,
           events=[{"t": 0, "show": "camp_bed"}, {"t": 0, "show": "camp_chest"}], fx={"pop": [pop(3.8, "WHO?! 🤔", "#ffd21f")]}))
    A(shot("Inside the chest, there was a book.",
           cam([54, -3.6], [55.5, 64.2, -6.5]), light=CAMP, music="tension", dur=6,
           gui={"title": "Chest", "items": [{"slot": 13, "icon": "written_book"}, {"slot": 3, "icon": "bread", "count": 3}, {"slot": 22, "icon": "compass"}],
                "scale": [4.2, 4.8], "highlight": "written_book", "highlight_at": 2.4, "top": 160},
           events=[{"t": 0, "show": "camp_bed"}, {"t": 0, "show": "camp_chest"}]))
    A(shot("It was a journal. Day one. I walked here from spawn. I made it! The Far Lands are real!",
           cam([54, -3.6], [55.5, 64.2, -6.5]), light=CAMP, music="music_box", dur=7,
           fx={"book": [[0.6, "Day 1:\nI walked here from\nspawn. I made it!\nThe Far Lands are\nREAL!"]]}))
    A(shot("Day three hundred. The wall makes noises at night. Like breathing.",
           cam([54, -3.6], [55.5, 64.2, -6.5]), light=CAMP, music="music_box", dur=6,
           fx={"book": [[0.3, "Day 300:\nThe wall makes\nnoises at night.\nLike breathing."]]}, sfx=[S(3.5, "breath", 0.5, dur=2.0)]))
    A(shot("Day nine hundred. I tried to go home. The compass just spins.",
           cam([54, -3.6], [55.5, 64.2, -6.5]), light=CAMP, music="music_box", dur=6,
           fx={"book": [[0.3, "Day 900:\nI tried to go home.\nThe compass just\nspins."]]}))
    A(shot("Day two thousand, nine hundred eighty-four. I think I'm getting taller.",
           cam([54, -3.6], [55.5, 64.2, -6.5]), light=CAMP, music="none", dur=6.4, style="quiet",
           fx={"book": [[0.3, "Day 2984:\nI think I'm getting\ntaller."]], "pop": [pop(4.6, "TALLER?! 😨", "#ff3b3b")]}, sfx=[S(4.5, "dundun", 0.9)]))
    A(shot("Taller? What does that even mean?",
           cam([53, -3.5], [53, 65.4, -1.0], [53, -3.6], [53, 66.5, 0.0]), light=CAMP, music="tension", dur=4.2,
           events=[{"t": 0, "show": "camp_bed"}, {"t": 0, "show": "camp_chest"}], sfx=[S(2.8, "breath", 0.6, dur=1.6)]))
    # ===== THE STRETCHED
    A(shot("Then I heard footsteps. Slow, heavy footsteps. Coming from deeper in the tunnel.",
           cam([52.5, 0], [62, 65.6, 0], [52, 0], [62, 65.6, 0]), light=TUNNEL, music="horror", dur=6,
           sfx=[S(1.4, "step", 0.8), S(2.4, "step", 0.85), S(3.4, "step", 0.9), S(4.4, "step", 0.95)], fx={"vignette": 0.7}))
    A(shot("And something came around the corner.",
           cam([52, 0], [60, 66.5, 0], [51.8, 0], [60, 67.2, 0]), light=TUNNEL, music="horror", dur=4.4,
           fx={"flash": [[2.4, "#ffffff"]], "pop": [pop(2.5, "AAAH! 😱", "#ff3b3b")]}, sfx=[S(2.4, "sting", 1.0)],
           actors={"stretched": STRETCH([60, 0])}))
    A(shot("It looked like a player. But stretched. So tall its head scraped the ceiling.",
           cam([53, 0.6], [59.5, 67.4, 0], [53.5, 0.6], [59.5, 67.6, 0]), light=TUNNEL, music="horror", dur=6,
           actors={"stretched": STRETCH([59.5, 0])}, fx={"pop": [pop(3.4, "THE STRETCHED 😨", "#b066ff")]}, sfx=[S(3.3, "boom", 0.8)]))
    A(shot("It was the Wanderer. The player who wrote the journal. The Far Lands had stretched him.",
           cam([53.5, 0.6], [59.5, 67.6, 0]), light=TUNNEL, music="horror", dur=6.5,
           actors={"stretched": STRETCH([59.5, 0])}, fx={"chat": [[4.4, "<Wanderer> stay."]], "vignette": 0.7}, sfx=[S(4.4, "tick", 0.8)]))
    A(shot("Stay? No way! I turned around and ran!",
           cam([52, 0], [38, 65.6, 0], [44, 0], [34, 65.6, 0]), light=TUNNEL, music="chase", dur=4.4,
           fx={"speed": 1.0, "pop": [pop(1.4, "RUN!! 🏃", "#ff3b3b")]}, sfx=[S(0.2, "riser", 0.6, dur=3)]))
    A(shot("Every time I looked back, it was closer!",
           cam([46, 0], [56, 66.5, 0]), light=TUNNEL, music="chase", dur=5,
           fx={"fade": [[0, 0], [1.3, 0], [1.34, 1], [1.46, 1], [1.5, 0], [2.8, 0], [2.84, 1], [2.96, 1], [3.0, 0]]},
           sfx=[S(1.4, "blip", 0.8), S(2.9, "blip", 0.9), S(2.9, "thud", 0.7)],
           actors={"stretched": {"face": "camera", "scale": [0.9, 2.5, 0.9], "keys": [{"t": 0, "at": [56, 0]}, {"t": 1.39, "at": [56, 0]}, {"t": 1.4, "at": [52.5, 0]}, {"t": 2.89, "at": [52.5, 0]}, {"t": 2.9, "at": [49, 0]}]}}))
    A(shot("But what I saw next was so much worse.",
           cam([45, 0], [38, 66, 0]), light=TUNNEL, music="chase", dur=3.4, fx={"flash": [[0.4, "#ff2b2b"]], "speed": 0.8}, sfx=[S(0.4, "boom", 0.8)]))
    A(shot("I jumped out of the tunnel and dove behind a rock.",
           cam([39, 2], [32, 65, 6], [33, 5], [26, 64.6, 9]), light=NIGHT, music="chase", dur=4.4, fx={"speed": 0.8}, sfx=[S(3.4, "thud", 0.7)]))
    A(shot("I held my breath. It stood at the tunnel. Looking for me.",
           cam([27, 9], [40, 66, 0], [27.2, 9], [40, 66.2, 0]), light=NIGHT, music="horror", dur=6,
           actors={"stretched": STRETCH([40.5, 0], face=270)}, sfx=[S(2.0, "breath", 0.6, dur=2.5)], fx={"vignette": 0.8}))
    A(shot("I could hear it breathing. Long, slow breaths. Like the wall itself was breathing.",
           cam([27, 9], [27, 66, 6]), light=NIGHT, music="none", dur=5.4, style="quiet", sfx=[S(0.6, "breath", 0.7, dur=2.4), S(3.2, "breath", 0.7, dur=2.0)], fx={"vignette": 0.85}))
    A(shot("Its long shadow moved right over my hiding spot. I didn't move a single pixel.",
           cam([27, 9], [32, 70, 4], [27, 9], [32, 71, 4]), light=NIGHT, music="horror", dur=5.4,
           actors={"stretched": STRETCH([31.5, 5.5], face=200)}, fx={"vignette": 0.85, "pop": [pop(3.6, "DON'T MOVE 🤫", "#ffffff")]}, sfx=[S(2.4, "step", 0.9)]))
    A(shot("Then it typed again.",
           cam([27.2, 9], [40, 66.2, 0]), light=NIGHT, music="none", dur=4.4, style="quiet",
           actors={"stretched": STRETCH([40.5, 0], face=270)}, fx={"chat": [[0.4, "<Wanderer> stay."], [1.8, "<Wanderer> everyone stays."]], "vignette": 0.8},
           sfx=[S(1.8, "tick", 0.8)]))
    # ===== THE RULE / ESCAPE
    A(shot("I typed back. Who are you?",
           cam([27.2, 9], [27, 64.6, 9.6]), light=NIGHT, music="tension", dur=4.4, fx={"chat": [[0.4, "<Wanderer> everyone stays."], [1.6, "<Steve> who are you??"]]}, sfx=[S(1.6, "tick", 0.6)]))
    A(shot("I was like you. I walked to the edge. I stayed one night. Now I can't stop growing.",
           cam([27.2, 9], [40, 66.2, 0]), light=NIGHT, music="horror", dur=7, style="quiet",
           actors={"stretched": STRETCH([40.5, 0], face=270)},
           fx={"chat": [[0.4, "<Steve> who are you??"], [1.2, "<Wanderer> i was like you."], [3.0, "<Wanderer> i stayed one night."], [5.0, "<Wanderer> now i can't stop growing."]]},
           sfx=[S(1.2, "tick", 0.6), S(3.0, "tick", 0.6), S(5.0, "tick", 0.7)]))
    A(shot("Everyone stays? Then I remembered the last page of the journal.",
           cam([27, 9.2], [26, 64.4, 9.6]), light=NIGHT, music="tension", dur=5.4,
           fx={"book": [[2.6, "If you find this,\nleave BEFORE dark.\nThe Far Lands\nstretch anyone who\nstays the night."]]}))
    A(shot("Before dark?! I looked up. The sun was already gone.",
           cam([27, 9], [27, 80, -10], [27, 9], [20, 90, -20]), light=NIGHT, music="tension", dur=5,
           fx={"pop": [pop(2.4, "IT'S NIGHT! 🌙", "#ffd21f")], "flash": [[2.3, "#000000"]]}, sfx=[S(2.3, "boom", 0.8)]))
    A(shot("And my hands... my hands looked longer.",
           cam([27, 9], [26, 64.6, 9.6]), light=NIGHT, music="warped", dur=4.6, hand={"item": "iron_sword"},
           fx=dict(coords(FAR - 7, g=0.6), glitch=[[0, 0], [2.0, 0.4], [2.3, 0]]), sfx=[S(2.0, "blip", 0.8)]))
    A(shot("I had to get to my portal. Now!",
           cam([27, 9], [30, 66, 9.5], [28.5, 9.5], [30, 66, 9.5]), light=NIGHT, music="chase", dur=3.4, fx={"speed": 0.8, "pop": [pop(1.0, "GO GO GO! 🏃", "#39ff6a")]}))
    A(shot("But the portal was broken. Half the obsidian was gone!",
           cam([28.5, 10.5], [30, 66.2, 9.5]), light=NIGHT, music="chase", dur=5,
           events=[{"t": 0, "set": air(portal(FL_PORTAL_X, 8)) + air(FL_BROKEN_MISSING)}],
           fx={"pop": [pop(2.2, "NOOO! 💔", "#ff3b3b")], "flash": [[2.1, "#ff2b2b"]]}, sfx=[S(2.1, "boom", 1.0)]))
    A(shot("It broke it. On purpose. So I would stay.",
           cam([28.5, 10.5], [30, 66.2, 9.5], [28.4, 10.7], [30, 66.2, 9.5]), light=NIGHT, music="horror", dur=4.4,
           events=[{"t": 0, "set": air(portal(FL_PORTAL_X, 8)) + air(FL_BROKEN_MISSING)}], sfx=[S(3.0, "step", 0.9)]))
    A(shot("I had three obsidian left in my inventory. I needed three. Exactly three.",
           cam([28.5, 10.5], [30, 66.2, 9.5]), light=NIGHT, music="chase", dur=5.6,
           fx={"hud": {"hearts": 10, "food": 9, "items": ["blocks/obsidian", "flint_and_steel", "iron_sword", "bread"], "slot": 0},
               "pop": [pop(3.0, "3 LEFT! 😬", "#ffd21f")]}, sfx=[S(3.0, "pop", 0.7)]))
    A(shot("One...",
           cam([28.5, 10.5], [30, 67.5, 11]), light=NIGHT, music="chase", dur=2.4, hand={"item": "blocks/obsidian", "swings": [0.6]},
           events=[{"t": 0.7, "set": [FL_BROKEN_MISSING[0]]}], sfx=[S(0.7, "thud", 0.7), S(1.6, "step", 0.9)]))
    A(shot("Two...",
           cam([28.5, 10.5], [30, 67.2, 10.5]), light=NIGHT, music="chase", dur=2.4, hand={"item": "blocks/obsidian", "swings": [0.6]},
           events=[{"t": 0.7, "set": FL_BROKEN_MISSING[1:2]}], sfx=[S(0.7, "thud", 0.7), S(1.6, "step", 1.0)]))
    A(shot("It was right behind me!",
           cam([28.5, 10.5], [36, 67, 6], [28.5, 10.5], [36, 67.5, 6]), light=NIGHT, music="chase", dur=3.2,
           actors={"stretched": STRETCH([34, 7.5])}, fx={"flash": [[0.5, "#ff2b2b"]], "pop": [pop(0.6, "BEHIND YOU! 😱", "#ff3b3b")]},
           sfx=[S(0.5, "sting", 1.0)]))
    A(shot("Three! Flint and steel!",
           cam([28.5, 10.5], [30, 66.4, 9.5]), light=NIGHT, music="chase", dur=3.4, hand={"item": "flint_and_steel", "swings": [0.5, 1.5]},
           events=[{"t": 0.6, "set": FL_BROKEN_MISSING[2:]}, {"t": 1.6, "set": portal(FL_PORTAL_X, 8)}],
           fx={"flash": [[1.6, "#b066ff"]], "pop": [pop(1.7, "YES!! 🌀", "#b066ff")]}, sfx=[S(0.6, "thud", 0.7), S(1.6, "boom", 0.8)]))
    A(shot("I jumped in just as its long arm reached for me.",
           cam([29.2, 9.5], [30.5, 66, 9.5], [29.9, 9.5], [31, 66, 9.5]), light=NIGHT, music="chase", dur=4,
           actors={"stretched": STRETCH([28.2, 11.4])}, fx={"flash": [[2.8, "#b066ff"]], "speed": 1.0}, sfx=[S(0.3, "riser", 0.8, dur=2.4), S(2.8, "boom", 1.0)]))
    # ===== HOME
    A(shot("I ran through the whole Nether without stopping.",
           cam([-41, -36], [-55, 32.5, -36], [-54, -36], [-62, 32.5, -36], floor=NF), light=NETHERL, music="chase", dur=4.4,
           fx=dict(coords(FAR // 8, 400), speed=1.0), sfx=[S(0.2, "riser", 0.5, dur=3.5)]))
    A(shot("And came out at home. Sunshine. My house. My bed. I made it.",
           cam([-26.5, 7.5], [-20, 66, 12], [-24, 9], [-20, 65.8, 12]), light="day", music="happy", dur=5.6,
           events=[{"t": 0, "set": HOME_FRAME + portal(HOME_PORTAL_X, 6)}],
           fx={"pop": [pop(2.6, "I ESCAPED!! 🥳", "#39ff6a")], "flash": [[2.5, "#ffd21f"]]}, sfx=[S(2.5, "sparkle", 0.8), S(2.6, "ding", 0.6)]))
    A(shot("I broke the portal so nothing could follow me. Done. Never going back.",
           cam([-24.5, 9.5], [-28, 66, 7.5]), light="day", music="happy", dur=5.4, hand={"item": "diamond_pickaxe", "swings": [1.0, 1.6, 2.2]},
           events=[{"t": 1.1, "set": air(portal(HOME_PORTAL_X, 6))}, {"t": 2.3, "set": air(HOME_FRAME[:6])}], sfx=[S(1.1, "break", 0.7), S(2.3, "break", 0.7)]))
    A(shot("Then I pressed F3 one more time. Just to be safe.",
           cam([-21, 9.5], [-19, 65.3, 12.5]), light="interior_night", music="tension", dur=4.4, sfx=[S(2.6, "tick", 0.7)]))
    A(shot("X... twelve million, five hundred fifty thousand, eight hundred twenty-one.",
           cam([-21, 9.5], [-19, 65.3, 12.5]), light="interior_night", music="none", dur=5.4, style="quiet",
           fx=dict(coords(FAR, g=0.15), coords_yz=[64, 10], pop=[pop(3.6, "WAIT... WHAT?! 😨", "#ffffff")]), sfx=[S(0.2, "scratch", 0.9), S(3.5, "dundun", 0.9)]))
    A(shot("And outside my window, something very, very tall was standing behind my house.",
           cam([-18.9, 8.3], [-14, 66.2, 8.1], [-18.5, 8.3], [-14, 66.6, 8.1]), light=NIGHT, music="horror", dur=6.4,
           actors={"stretched": STRETCH([-13.6, 8.2])}, fx={"vignette": 0.75}, sfx=[S(4.2, "sting", 0.9)]))
    A(shot("You brought me home.",
           cam([-18.5, 8.3], [-14, 66.6, 8.1]), light=NIGHT, music="none", dur=4.4, style="quiet",
           actors={"stretched": STRETCH([-13.6, 8.2])},
           fx={"chat": [[0.6, "<Wanderer> you brought me home."]], "vignette": 0.85, "glitch": [[0, 0], [3.0, 0], [3.05, 0.8], [3.4, 0.2]]},
           sfx=[S(0.6, "tick", 0.8), S(3.0, "sting", 1.0), S(3.0, "static", 0.8, dur=0.6)]))
    # ===== END
    A(shot("The next morning, I went outside. And the trees... the trees were taller.",
           cam([-2, 18], [-6, 73, 1], [-1, 17], [-6, 77, 1]), light="day", music="warped", dur=6.4,
           events=[{"t": 0, "set": [[x, y, z, "oak_log", {"axis": "y"}] for x, z in ((-8, 2), (-4, 6), (-10, -4), (-2, -2)) for y in range(64, 64 + 14 + (x * x) % 6)]}],
           fx={"pop": [pop(3.8, "STRETCHED?! 😨", "#ff3b3b")], "glitch": [[0, 0], [3.6, 0], [3.7, 0.4], [3.9, 0]]}, sfx=[S(3.6, "dundun", 0.9)]))
    A(shot("He didn't stay in the Far Lands. He came with me. And the Far Lands are coming too.",
           cam([-1, 17], [-6, 77, 1]), light="day", music="horror", dur=6.4, fx=dict(coords(FAR, g=0.3), coords_yz=[64, 17]), sfx=[S(4.0, "sting", 0.9)]))
    A(shot("And here's the real part: the Far Lands really existed. You can still visit them in old versions of Minecraft. But if you do... leave before dark.",
           cam(*WALL_WIDE), light=DUSK, music="tension", dur=8, fx={"pop": [pop(6.2, "LEAVE BEFORE DARK 🌙", "#ffd21f")]}, sfx=[S(6.1, "ding", 0.6)]))
    A({"note": "End card", "duration": 8.0, "music": "none", "light": DUSK,
       "vo": "If you ever see a giant broken wall in your Minecraft world... don't walk there. Would you go to the Far Lands? Comment below, and subscribe!",
       "vo_at": 0.3, "vo_speed": 1.22,
       "caption": "WOULD YOU GO TO THE FAR LANDS?\nComment below 👇 and subscribe", "caption_at": 1.0,
       "sfx": [S(0.8, "boom", 0.7), S(1.0, "sparkle", 0.6)],
       "fx": {"flash": [[0.8, "#b066ff"]], "vignette": 0.5, "label": [[1.0, "SHADOW BLOCK TALES"]], "pop": [pop(1.2, "YES OR NO? 🤔", "#ffd21f")]},
       "camera": cam([10, 69, 1], [40, 95, 0], [14, 68, 1], [40, 95, 0], dur=8.0),
       "actors": {"stretched": STRETCH([41, 0], face=270)}})
    return L


def main():
    doc = {
        "title": "I Found the Far Lands in Minecraft… Something Lives There 😱",
        "description": ("Minecraft horror: the Far Lands were deleted from Minecraft in 2011... so why did they show up in my world? "
                        "A sign by my bed said COME TO THE EDGE. I used the Nether trick to get there, and found a journal from a player "
                        "who stayed too long.\n\n"
                        "Real facts in this video: the Far Lands appeared 12,550,821 blocks from spawn because the game's math broke, "
                        "Mojang removed them in Beta 1.8, and 1 block in the Nether = 8 blocks in the Overworld. The story is fiction!\n\n"
                        "Would you go to the Far Lands? Comment below!\n\n#minecraft #minecrafthorror #farlands\n"),
        "tags": ["minecraft far lands", "far lands", "minecraft horror", "minecraft glitch", "minecraft creepypasta", "scary minecraft", "minecraft beta 1.7.3"],
        "format": "landscape",
        "voice": "gamer",
        "grade": "vivid",
        "camera_shake": 0.3,
        "thumbnail": {"shot": 45, "t": 3.0, "text": "THE FAR LANDS", "color": "#ff3b30"},
        "world": {
            "time": "day", "seed": 12, "area": [-4, -4, 4, 2],
            "structures": [{"type": "farlands", "at": [40, 0], "depth": 24, "half": 44, "height": 70},
                           {"type": "nether", "at": list(NETHER), "y": NF - 1},
                           {"type": "cottage", "at": list(HOME)}],
            "fills": [[38, 64, -1, 60, 69, 1, "air"], [50, 64, -7, 56, 69, -2, "air"], [-10, 52, -28, 4, 62, -16, "stone"], [-9, 53, -27, 3, 56, -17, "air"], [-9, 52, -27, 3, 52, -17, "stone"], [44, 63, -1, 60, 63, 1, "stone"]],
            "blocks": [[50, 65, -7, "torch"], [56, 65, -7, "torch"], [44, 65, 1, "torch"], [56, 64, -2, "crafting_table"],
                       [-28, 63, 6, "grass_block"], [0, 54, -24, "diamond_ore"], [1, 54, -25, "diamond_ore"], [-8, 53, -26, "torch"], [2, 53, -18, "torch"]],
            "trees": 30, "plants": 300,
        },
        "props": {
            "edge_sign": {"type": "sign", "at": [-21.0, 8.6], "face": 180, "lines": ["COME TO", "THE EDGE", "12550821"], "hidden": True},
            "sign_turn": {"type": "sign", "at": [37.5, 2.4], "face": 90, "lines": ["TURN BACK", "THE WALL", "IS HUNGRY"], "hidden": True},
            "sign_tall": {"type": "sign", "at": [51.5, -1.4], "face": 180, "lines": ["HE IS TALL", "NOW. DON'T", "LET HIM", "SEE YOU"], "hidden": True},
            "old_sword": {"type": "items", "item": "iron_sword", "points": [[48.6, 0.2]], "hidden": True},
            "home_bed": {"type": "bed", "at": [-20.5, 9.5], "face": 0, "color": "blue"},
            "camp_bed": {"type": "bed", "at": [52.5, -5.0], "face": 0, "color": "red", "hidden": True},
            "camp_chest": {"type": "chest", "at": [55.5, -6.5], "face": 180, "hidden": True},
        },
        "actors": {"stretched": {"skin": "steve_hollow", "shade": 0.1, "still": True}},
        "shots": shots(),
    }
    (HERE / "script.yaml").write_text("# The Far Lands (10-min glitch video). Generated by gen.py; edit that file.\n"
                                      + yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=200), encoding="utf-8")
    total = sum(s["duration"] for s in doc["shots"])
    print(len(doc["shots"]), "shots,", round(total, 1), "s =", f"{int(total // 60)}:{int(total % 60):02d}")


if __name__ == "__main__":
    main()
