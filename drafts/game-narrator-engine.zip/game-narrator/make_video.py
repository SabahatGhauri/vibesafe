"""One command: script.yaml -> finished YouTube Short (+ thumbnail and upload text).

    python make_video.py videos/haunted/script.yaml              # full video
    python make_video.py videos/haunted/script.yaml --preview    # 3 stills per shot -> preview.jpg (fast check)
    python make_video.py videos/haunted/script.yaml --only 5,6   # re-render only these shots, reuse the rest
    python make_video.py videos/haunted/script.yaml --no-render  # keep frames, redo voice/music/captions only

Your own voice recordings: put them in videos/<name>/my_voice/shot3.wav etc.; they replace the AI voice.
"""
import argparse
import json
import pathlib
import shutil
import subprocess
import sys

import yaml
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = pathlib.Path(__file__).parent
PY = sys.executable


def ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def run(cmd, **kw):
    print("$", " ".join(str(c) for c in cmd[:4]), "...")
    subprocess.run([str(c) for c in cmd], check=True, **kw)


def font(size):
    for name in ("DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                 "C:/Windows/Fonts/arialbd.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def load_script(path):
    script = yaml.safe_load(path.read_text(encoding="utf-8"))
    for i, s in enumerate(script["shots"], 1):
        s["id"] = i
        if "duration" not in s or "camera" not in s:
            sys.exit(f"shot {i}: needs 'duration' and 'camera'")
    return script


def write_build_files(script, build, video_dir):
    build.mkdir(parents=True, exist_ok=True)
    (build / "script.json").write_text(json.dumps(script, indent=1), encoding="utf-8")
    keep = ("id", "duration", "vo", "vo_at", "vo_speed", "vo_style", "voice", "caption", "caption_at", "caption_style", "caption_size", "music", "shot")
    shots = []
    for s in script["shots"]:
        d = {k: s[k] for k in keep if k in s}
        d.setdefault("shot", s.get("note", ""))
        mine = next(iter(sorted((video_dir / "my_voice").glob(f"shot{s['id']}.*"))), None) if (video_dir / "my_voice").exists() else None
        if mine:
            (build / "vo").mkdir(exist_ok=True)
            # Your own recording (any format) replaces the AI line; convert it to wav for mixing.
            subprocess.run([ffmpeg(), "-y", "-loglevel", "error", "-i", str(mine), "-ac", "1", "-ar", "48000",
                            str(build / "vo" / f"shot{s['id']}.wav")], check=True)
            d["vo_file"] = str(mine)
        shots.append(d)
    (build / "shots.json").write_text(json.dumps({"title": script.get("title", ""), "format": script.get("format", "vertical"), "shots": shots}, indent=1, ensure_ascii=False), encoding="utf-8")


def preview_sheet(script, build, out):
    tw, th = (384, 216) if script.get("format") == "landscape" else (216, 384)
    rows = [sorted((build / "frames" / f"shot{s['id']}").glob("*.jpg")) for s in script["shots"]]
    cols = max(len(r) for r in rows)
    sheet = Image.new("RGB", (cols * (tw + 6) + 60, len(rows) * (th + 6)), "white")
    d = ImageDraw.Draw(sheet)
    for r, files in enumerate(rows):
        d.text((8, r * (th + 6) + 8), str(r + 1), fill="black", font=font(36))
        for c, f in enumerate(files):
            sheet.paste(Image.open(f).resize((tw, th)), (60 + c * (tw + 6), r * (th + 6)))
    sheet.save(out, quality=88)
    print("preview:", out)


def mux_clips(script, build):
    ff = ffmpeg()
    (build / "clips").mkdir(exist_ok=True)
    for s in script["shots"]:
        n = s["id"]
        run([ff, "-y", "-loglevel", "error", "-framerate", "30", "-i", build / "frames" / f"shot{n}" / "%04d.jpg",
             "-i", build / "sfx" / f"shot{n}.wav", "-c:v", "libx264", "-crf", "14", "-preset", "medium",
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest", build / "clips" / f"shot{n}.mp4"])


def thumbnail(script, build, video_dir):
    th = script.get("thumbnail", {})
    shot = th.get("shot", 1)
    frames = sorted((build / "frames" / f"shot{shot}").glob("*.jpg"))
    frame = Image.open(frames[min(len(frames) - 1, int(th.get("t", 0) * 30))]).convert("RGB")
    if frame.width > frame.height:
        bg = frame.resize((1280, 720))  # already 16:9
    else:
        # 16:9 thumbnail: blurred background + the vertical frame in the middle + big text.
        bg = frame.resize((1280, int(1280 * frame.height / frame.width))).crop((0, 300, 1280, 1020)).filter(ImageFilter.GaussianBlur(18))
        fg = frame.resize((405, 720))
        bg.paste(fg, (437, 0))
    text = th.get("text", script.get("title", ""))
    if text:
        d = ImageDraw.Draw(bg)
        f = font(110)
        w = d.textlength(text, font=f)
        d.text(((1280 - w) / 2, 560), text, font=f, fill=th.get("color", "#ffdd33"), stroke_width=10, stroke_fill="black")
    bg.save(video_dir / "thumbnail.jpg", quality=92)
    # Vertical cover frame for Shorts.
    frame.save(video_dir / "cover.jpg", quality=92)


def subtitles(script, build, video_dir, slug):
    """Write <name>.srt from the voice lines (upload it to YouTube as captions)."""
    import wave
    def ts(t):
        ms = int(round(t * 1000))
        return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"
    start, n, out = 0.0, 1, []
    for s in script["shots"]:
        wav = build / "vo" / f"shot{s['id']}.wav"
        if s.get("vo") and wav.exists():
            with wave.open(str(wav)) as w:
                dur = w.getnframes() / w.getframerate()
            a = start + s.get("vo_at", 0)
            out.append(f"{n}\n{ts(a)} --> {ts(a + dur + 0.2)}\n{s['vo']}\n")
            n += 1
        start += s["duration"]
    (video_dir / f"{slug}.srt").write_text("\n".join(out), encoding="utf-8")


def metadata(script, video_dir, out_name):
    title = script.get("title", "")
    desc = script.get("description", "")
    tags = script.get("tags", ["minecraft", "shorts"])
    hashtags = "" if "#" in desc else "\n" + " ".join("#" + t for t in tags)  # don't repeat hashtags already in the description
    text = f"TITLE:\n{title}\n\nDESCRIPTION:\n{desc.rstrip()}{hashtags}\n\nFILE: {out_name}\n"
    (video_dir / "upload.txt").write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script")
    ap.add_argument("--preview", action="store_true", help="render 3 stills per shot and a contact sheet only")
    ap.add_argument("--only", help="comma-separated shot numbers to re-render")
    ap.add_argument("--no-render", action="store_true", help="reuse existing frames")
    ap.add_argument("--fast", action="store_true", help="render at 720p and upscale (about 2x faster)")
    ap.add_argument("--voice", default=None, help="voice preset (gamer, gamer_hype, gamer_chill, storyteller) or a Kokoro voice")
    args = ap.parse_args()

    script_path = pathlib.Path(args.script).resolve()
    video_dir = script_path.parent
    build = video_dir / "build"
    script = load_script(script_path)
    write_build_files(script, build, video_dir)

    if args.preview:
        run(["node", ROOT / "engine" / "render.js", build / "script.json", "--stills=0.05,0.5,0.95"])
        preview_sheet(script, build, video_dir / "preview.jpg")
        return
    if not args.no_render:
        cmd = ["node", ROOT / "engine" / "render.js", build / "script.json"] + (["--scale=0.667"] if args.fast else [])
        if args.only:
            cmd.append(f"--only={args.only}")
        run(cmd)
    run([PY, ROOT / "tools" / "make_sfx.py", build])
    run([PY, ROOT / "tools" / "voice.py", build, args.voice or script.get("voice", "gamer"), ROOT / "models"])
    run([PY, ROOT / "tools" / "make_music.py", build])
    mux_clips(script, build)
    slug = video_dir.name
    out = video_dir / f"{slug}.mp4"
    run([PY, ROOT / "tools" / "assemble.py", build, out])
    thumbnail(script, build, video_dir)
    try:
        subtitles(script, build, video_dir, slug)
    except Exception as e:  # subtitles are a bonus; never fail the render for them
        print("subtitles skipped:", e)
    metadata(script, video_dir, out.name)
    print(f"\nDONE → {out}\n       {video_dir / 'thumbnail.jpg'}\n       {video_dir / 'upload.txt'}")


if __name__ == "__main__":
    main()
