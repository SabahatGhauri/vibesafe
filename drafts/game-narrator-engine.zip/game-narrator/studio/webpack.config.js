// Bundles the studio page (three.js + prismarine-viewer) into studio/dist.
const webpack = require('webpack')
const path = require('path')
module.exports = {
  entry: path.join(__dirname, 'client.js'),
  mode: 'production',
  output: { path: path.join(__dirname, 'dist'), filename: 'studio.js' },
  resolve: {
    fallback: { zlib: false, fs: false, path: false },
    alias: { canvas: path.join(__dirname, 'canvas-shim.js') }
  },
  plugins: [
    new webpack.ProvidePlugin({ process: 'process/browser' }),
    new webpack.ProvidePlugin({ Buffer: ['buffer', 'Buffer'] })
  ],
  performance: { hints: false },
  stats: 'errors-warnings'
}
