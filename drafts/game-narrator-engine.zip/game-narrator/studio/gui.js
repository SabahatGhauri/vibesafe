// Builds a 3-row container screen (chest/barrel) + player inventory as HTML, using Minecraft's generic_54 texture.
// items: [{slot, icon, block?, count}] shown in the same slot of the container and the inventory.
window.buildContainerGUI = function (scale, items, highlight, title, invItems) {
  const T = '/textures/1.16.4/'
  const px = (v) => v * scale + 'px'
  const slot = (x, y, it, hl) => {
    if (!it) return ''
    const icon = it.null
      ? `<div style="position:absolute;left:${px(x + 1)};top:${px(y + 1)};width:${px(16)};height:${px(16)};background:repeating-conic-gradient(#f800f8 0 25%, #000 0 50%) 0 0/${px(8)} ${px(8)}"></div>`
      : it.head
      ? `<div style="position:absolute;left:${px(x + 2)};top:${px(y + 2)};width:${px(14)};height:${px(14)};background:url(${T}entity/${it.head}.png) ${px(-14)} ${px(-14)}/${px(112)} ${px(112)};image-rendering:pixelated;box-shadow:inset ${px(-2)} ${px(-2)} 0 rgba(0,0,0,.35)"></div>`
      : it.block
      ? `<div style="position:absolute;left:${px(x + 1)};top:${px(y + 1)};width:${px(16)};height:${px(16)};">
           <div style="position:absolute;left:${px(2)};top:${px(2)};width:${px(12)};height:${px(12)};background:url(${T}blocks/${it.icon}.png);background-size:100% 100%;image-rendering:pixelated;box-shadow:inset ${px(-3)} ${px(-3)} 0 rgba(0,0,0,.35)"></div></div>`
      : `<img src="${T}items/${it.icon}.png" style="position:absolute;left:${px(x + 1)};top:${px(y + 1)};width:${px(16)};height:${px(16)};image-rendering:pixelated">`
    const count = it.count > 1 ? `<div style="position:absolute;left:${px(x)};top:${px(y + 9)};width:${px(17)};text-align:right;font:bold ${px(7)} monospace;color:#fff;text-shadow:${px(1)} ${px(1)} 0 #3f3f3f">${it.count}</div>` : ''
    const ring = hl ? `<div style="position:absolute;left:${px(x - 3)};top:${px(y - 3)};width:${px(22)};height:${px(22)};border:${px(2)} solid #ff3030;border-radius:50%;box-shadow:0 0 ${px(4)} #ff3030"></div>` : ''
    // Hover tooltip, like Minecraft's item name box (red "null" for broken items).
    const tip = hl && it.null ? `<div style="position:absolute;left:${px(x + 14)};top:${px(y - 14)};padding:${px(2)} ${px(4)};background:#100010f0;border:${px(1)} solid #2d0a63;font:${px(9)} monospace;color:#ff3b3b;white-space:nowrap;z-index:2">null</div>` : ''
    return icon + count + ring + tip
  }
  let html = `<div style="position:relative;width:${px(176)};height:${px(168)}">
    <div style="position:absolute;left:0;top:0;width:${px(176)};height:${px(71)};background:url(${T}gui/container/generic_54.png) 0 0/${px(256)} ${px(256)};image-rendering:pixelated"></div>
    <div style="position:absolute;left:0;top:${px(71)};width:${px(176)};height:${px(97)};background:url(${T}gui/container/generic_54.png) 0 ${px(-125)}/${px(256)} ${px(256)};image-rendering:pixelated"></div>
    <div style="position:absolute;left:${px(8)};top:${px(5)};font:${px(8)} monospace;color:#404040">${title || 'Chest'}</div>
    <div style="position:absolute;left:${px(8)};top:${px(73)};font:${px(8)} monospace;color:#404040">Inventory</div>`
  let tipDone = false
  const hl = (it) => {
    if (highlight === 'null') { if (it.null && !tipDone) { tipDone = true; return true } return false }
    return highlight && (it.icon === highlight || it.head === highlight)
  }
  // Container slots (top); the player's inventory mirrors them unless invItems is given.
  for (const it of items) html += slot(8 + (it.slot % 9) * 18, 18 + Math.floor(it.slot / 9) * 18, it, hl(it))
  for (const it of invItems || items) {
    // slots 0-26 = main inventory rows, 27-35 = hotbar
    const y = it.slot >= 27 ? 143 : 85 + Math.floor(it.slot / 9) * 18
    html += slot(8 + (it.slot % 9) * 18, y, it, hl(it))
  }
  return html + '</div>'
}

// Villager trading screen (villager2 texture): offers [{cost, count, cost2, count2, result, rcount, head, sold}].
// Icons are item names, or a texture path containing "/" (e.g. "blocks/torch"); head: a player skin for a head result.
window.buildTradeGUI = function (scale, offers, highlight, title) {
  const T = '/textures/1.16.4/'
  const px = (v) => v * scale + 'px'
  const icon = (x, y, name, count, head) => {
    const img = head
      ? `<div style="position:absolute;left:${px(x + 1)};top:${px(y + 1)};width:${px(14)};height:${px(14)};background:url(${T}entity/${head}.png) ${px(-14)} ${px(-14)}/${px(112)} ${px(112)};image-rendering:pixelated"></div>`
      : `<img src="${T}${name.includes('/') ? name : 'items/' + name}.png" style="position:absolute;left:${px(x)};top:${px(y)};width:${px(16)};height:${px(16)};image-rendering:pixelated">`
    const c = count > 1 ? `<div style="position:absolute;left:${px(x - 1)};top:${px(y + 8)};width:${px(17)};text-align:right;font:bold ${px(7)} monospace;color:#fff;text-shadow:${px(1)} ${px(1)} 0 #3f3f3f">${count}</div>` : ''
    return img + c
  }
  let html = `<div style="position:relative;width:${px(276)};height:${px(166)}">
    <div style="position:absolute;inset:0;background:url(${T}gui/container/villager2.png) 0 0/${px(512)} ${px(256)};image-rendering:pixelated"></div>
    <div style="position:absolute;left:${px(107)};top:${px(6)};width:${px(169)};text-align:center;font:${px(8)} monospace;color:#404040">${title || 'Villager'}</div>
    <div style="position:absolute;left:${px(5)};top:${px(6)};font:${px(8)} monospace;color:#404040">Trades</div>`
  offers.forEach((o, i) => {
    const y = 18 + i * 20
    const hl = highlight !== null && highlight !== undefined && highlight === i
    html += `<div style="position:absolute;left:${px(5)};top:${px(y)};width:${px(88)};height:${px(20)};background:${hl ? 'rgba(255,255,255,.35)' : 'rgba(198,198,198,.9)'};border:${px(1)} solid ${hl ? '#fff' : '#8b8b8b'};box-sizing:border-box"></div>`
    html += icon(9, y + 2, o.cost, o.count)
    if (o.cost2) html += icon(33, y + 2, o.cost2, o.count2)
    html += `<div style="position:absolute;left:${px(52)};top:${px(y + 3)};font:bold ${px(11)} monospace;color:${o.sold ? '#e02020' : '#404040'}">${o.sold ? '✕' : '→'}</div>`
    html += icon(70, y + 2, o.result, o.rcount, o.head)
  })
  // Right panel mirrors the highlighted offer in the trade slots.
  const sel = offers[highlight]
  if (sel) {
    html += icon(136, 37, sel.cost, sel.count)
    if (sel.cost2) html += icon(162, 37, sel.cost2, sel.count2)
    html += icon(220, 37, sel.result, sel.rcount, sel.head)
    if (sel.sold) html += `<div style="position:absolute;left:${px(180)};top:${px(33)};font:bold ${px(20)} monospace;color:#e02020">✕</div>`
  }
  return html + '</div>'
}
