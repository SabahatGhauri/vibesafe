/* Custom studio client: deterministic rendering + scriptable camera and animated players. */
global.THREE = require('three')
const { Viewer } = require('prismarine-viewer/viewer')
const Entity = require('prismarine-viewer/viewer/lib/entity/Entity')
const io = require('socket.io-client')

const BONES = ['root', 'body', 'waist', 'head', 'cape', 'hat', 'leftArm', 'leftSleeve', 'leftItem', 'rightArm',
  'rightSleeve', 'rightItem', 'leftLeg', 'leftPants', 'rightLeg', 'rightPants', 'jacket']

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true })
renderer.setPixelRatio(1)
renderer.setSize(window.innerWidth, window.innerHeight)
document.body.appendChild(renderer.domElement)
const viewer = new Viewer(renderer)
viewer.camera.fov = 70
viewer.camera.updateProjectionMatrix()

const players = {}
let chunksReceived = 0

const PLAYER_BONES = require('prismarine-viewer/viewer/lib/entity/entities.json').player.geometry.default.bones

// Some models (e.g. villager) only list profession textures, so the base mesh would be skipped. Give them a default.
const ENTITY_DEFS = require('prismarine-viewer/viewer/lib/entity/entities.json')
ENTITY_DEFS.villager.textures.default = 'textures/entity/villager/villager'
for (const def of Object.values(ENTITY_DEFS)) {
  if (def.textures && !def.textures.default && def.geometry && def.geometry.default) def.textures.default = Object.values(def.textures)[0]
}

// The stock model stores absolute pivots on nested bones, so limbs rotate around the wrong point.
// Re-express each bone relative to its parent and re-bind, so arms and legs swing from the shoulder/hip.
function fixSkeleton (skinned) {
  const bones = skinned.skeleton.bones
  PLAYER_BONES.forEach((jb, i) => {
    const piv = jb.pivot || [0, 0, 0]
    const parent = jb.parent ? PLAYER_BONES.find((b) => b.name === jb.parent) : null
    const pp = parent && parent.pivot ? parent.pivot : [0, 0, 0]
    bones[i].position.set(piv[0] - pp[0], piv[1] - pp[1], piv[2] - pp[2])
  })
  const scale = skinned.scale.clone()
  skinned.scale.set(1, 1, 1)
  skinned.updateMatrixWorld(true)
  skinned.bind(skinned.skeleton)
  skinned.scale.copy(scale)
}

function bonesOf (obj) {
  fixSkeleton(obj.children[0])
  const sk = obj.children[0].skeleton
  const out = {}
  BONES.forEach((n, i) => { out[n] = sk.bones[i] })
  for (const b of Object.values(out)) b.userData.base = b.rotation.clone()
  return out
}

const socket = io()
socket.on('version', (version) => {
  viewer.setVersion(version)
  viewer.listen(socket)
  socket.on('loadChunk', () => { chunksReceived++ })
})

window.studio = {
  THREE,
  viewer,
  chunks: () => chunksReceived,
  async waitRender () { await viewer.waitForChunksToRender() },
  setSky (color, ambient = 0.8, sun = 0.5) {
    viewer.scene.background = new THREE.Color(color)
    viewer.ambientLight.intensity = ambient
    viewer.directionalLight.intensity = sun
  },
  fog (color, near, far) { viewer.scene.fog = new THREE.Fog(color, near, far) },
  // Full lighting setup: {sky, ambient, ambientColor, sun, fog: [near, far], fogColor}
  setLight (l) {
    viewer.scene.background = new THREE.Color(l.sky)
    viewer.ambientLight.intensity = l.ambient
    viewer.ambientLight.color = new THREE.Color(l.ambientColor || '#cccccc')
    viewer.directionalLight.intensity = l.sun
    viewer.scene.fog = new THREE.Fog(l.fogColor || l.sky, l.fog[0], l.fog[1])
  },
  // opts: {model: player|villager|zombie|armor_stand|…, skin: 'alex' (player skins in textures/entity), shade: 0..1 darkness, glow: 0..1 self-lit}
  addPlayer (id, opts = {}) {
    const model = opts.model || 'player'
    const e = new Entity('1.16.4', model, viewer.scene)
    viewer.scene.add(e.mesh)
    const skinned = e.mesh.children[0]
    if (opts.skin && skinned) {
      const t = pixelTex(TEX + 'entity/' + opts.skin + '.png')
      t.flipY = false
      t.wrapS = t.wrapT = THREE.RepeatWrapping
      skinned.material.map = t
      skinned.material.needsUpdate = true
    }
    if (opts.shade !== undefined && skinned) skinned.material.color.setScalar(1 - opts.shade)
    // glow 0..1: the skin lights itself (stays white in dark caves and coloured light)
    if (opts.glow && skinned) {
      skinned.material.emissive = new THREE.Color(1, 1, 1)
      skinned.material.emissiveMap = skinned.material.map
      skinned.material.emissiveIntensity = opts.glow
      skinned.material.needsUpdate = true
    }
    players[id] = { mesh: e.mesh, bones: model === 'player' ? bonesOf(e.mesh) : null }
  },
  players () { return players },
  removePlayer (id) { if (players[id]) { viewer.scene.remove(players[id].mesh); delete players[id] } },
  // p: {x,y,z,yaw (radians, Minecraft-style), walk (phase, radians), walkAmp, headYaw, headPitch, armRaise}
  setPlayer (id, p) {
    const pl = players[id]
    if (!pl) return
    pl.mesh.visible = p.visible !== false
    pl.mesh.position.set(p.x, p.y, p.z)
    pl.mesh.rotation.y = p.yaw || 0
    if (p.scale) pl.mesh.scale.set(p.scale[0], p.scale[1], p.scale[2])
    const b = pl.bones
    if (!b) return // non-player models: position/rotation only
    const swing = p.still ? 0 : Math.sin(p.walk || 0) * (p.walkAmp ?? 0.7)
    const set = (n, x = 0, y = 0, z = 0) => { const base = b[n].userData.base; b[n].rotation.set(base.x + x, base.y + y, base.z + z) }
    set('leftLeg', swing); set('rightLeg', -swing)
    set('leftArm', -swing * 0.8 - (p.leftArmRaise || 0)); set('rightArm', swing * 0.8 - (p.armRaise || 0))
    set('head', -(p.headPitch || 0), p.headYaw || 0, p.headRoll || 0)
  },
  setCamera (x, y, z, yaw, pitch, fov) {
    viewer.camera.position.set(x, y, z)
    viewer.camera.rotation.set(pitch, yaw, 0, 'ZYX')
    if (fov && fov !== viewer.camera.fov) { viewer.camera.fov = fov; viewer.camera.updateProjectionMatrix() }
  },
  render () { renderer.render(viewer.scene, viewer.camera) }
}

// ---------- props: dropped items, sign ----------
const TEX = '/textures/1.16.4/'
const loader = new THREE.TextureLoader()
function pixelTex (url) {
  const t = loader.load(url)
  t.magFilter = THREE.NearestFilter
  t.minFilter = THREE.NearestFilter
  return t
}
const props = {}
window.studio.addItem = (id, texture, isBlock) => {
  let mesh
  if (isBlock) {
    const m = new THREE.MeshLambertMaterial({ map: pixelTex(TEX + 'blocks/' + texture + '.png') })
    mesh = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 0.25), m)
  } else {
    const m = new THREE.MeshLambertMaterial({ map: pixelTex(TEX + 'items/' + texture + '.png'), transparent: true, alphaTest: 0.1, side: THREE.DoubleSide })
    mesh = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.4), m)
  }
  viewer.scene.add(mesh)
  props[id] = mesh
}
// Dropped items bob and spin like in Minecraft.
window.studio.setItem = (id, x, y, z, t, visible = true) => {
  const m = props[id]
  if (!m) return
  m.visible = visible
  m.position.set(x, y + 0.2 + Math.sin(t * 2.5 + x) * 0.07, z)
  m.rotation.y = t * 1.2 + z
}
window.studio.addSign = (id, x, y, z, yaw, lines) => {
  const group = new THREE.Group()
  const planks = pixelTex(TEX + 'blocks/oak_planks.png')
  const wood = new THREE.MeshLambertMaterial({ map: planks })
  // Front face: planks + text drawn on a canvas.
  const c = document.createElement('canvas')
  c.width = 384; c.height = 192
  const ctx = c.getContext('2d')
  const img = new window.Image()
  img.src = TEX + 'blocks/oak_planks.png'
  const front = new THREE.CanvasTexture(c)
  front.magFilter = THREE.NearestFilter
  img.onload = () => {
    ctx.imageSmoothingEnabled = false
    for (let i = 0; i < 4; i++) for (let j = 0; j < 2; j++) ctx.drawImage(img, i * 96, j * 96, 96, 96)
    ctx.fillStyle = '#000'
    ctx.font = 'bold 30px monospace'
    ctx.textAlign = 'center'
    lines.forEach((l, k) => ctx.fillText(l, 192, 44 + k * 38))
    front.needsUpdate = true
  }
  const frontMat = new THREE.MeshLambertMaterial({ map: front })
  const board = new THREE.Mesh(new THREE.BoxGeometry(1, 0.5, 0.08), [wood, wood, wood, wood, frontMat, wood])
  board.position.y = 0.85
  const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.6, 0.08), new THREE.MeshLambertMaterial({ map: pixelTex(TEX + 'blocks/oak_log.png') }))
  post.position.y = 0.3
  group.add(board, post)
  group.position.set(x, y, z)
  group.rotation.y = yaw
  viewer.scene.add(group)
  props[id] = group
}
window.studio.showProp = (id, v) => { if (props[id]) props[id].visible = v }

// Cubes: missing-texture blocks (magenta/black checker), or pure black void blocks. points: [[x, y, z], ...] block coords.
window.studio.addCubes = (id, points, style = 'missing', size = 1) => {
  let mat
  if (style === 'black') mat = new THREE.MeshBasicMaterial({ color: 0x000000 })
  else {
    const t = canvasTex(16, 16, (ctx, done) => {
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { ctx.fillStyle = (i + j) % 2 ? '#000000' : '#f800f8'; ctx.fillRect(i * 8, j * 8, 8, 8) }
      done()
    })
    mat = new THREE.MeshBasicMaterial({ map: t })
  }
  const g = new THREE.Group()
  const geo = new THREE.BoxGeometry(size, size, size)
  for (const [x, y, z] of points) {
    const m = new THREE.Mesh(geo, mat)
    m.position.set(x + 0.5, y + size / 2, z + 0.5)
    g.add(m)
  }
  viewer.scene.add(g)
  props[id] = g
}

// Lead rope from the camera's hand to an actor: {from: [x,y,z], to: [x,y,z]} or null.
let leash = null
window.studio.setLeash = (l) => {
  if (!leash) {
    const tex = canvasTex(4, 16, (ctx, done) => { for (let y = 0; y < 16; y++) { ctx.fillStyle = y % 4 < 2 ? '#7a5634' : '#5a3d22'; ctx.fillRect(0, y, 4, 1) } done() })
    leash = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1, 6), new THREE.MeshLambertMaterial({ map: tex }))
    viewer.scene.add(leash)
  }
  if (!l) { leash.visible = false; return }
  const a = new THREE.Vector3(...l.from)
  const b = new THREE.Vector3(...l.to)
  const d = a.distanceTo(b)
  leash.visible = true
  leash.scale.set(1, d, 1)
  leash.position.copy(a).add(b).multiplyScalar(0.5)
  leash.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize())
}

// ---------- 2D overlays (container GUI, highlight rings) ----------
const overlay = document.createElement('div')
overlay.style.cssText = 'position:fixed;inset:0;pointer-events:none;display:flex;align-items:center;justify-content:center'
document.body.appendChild(overlay)
window.studio.overlayHTML = (html) => { overlay.innerHTML = html }
window.studio.overlayStyle = (css) => { overlay.style.cssText = 'position:fixed;inset:0;pointer-events:none;display:flex;align-items:center;justify-content:center;' + css }

// Put an item in a player's right hand (attached to the rightItem bone, which lives in 1/16 scale).
window.studio.holdItem = (id, texture) => {
  const pl = players[id]
  if (!pl) return
  const m = new THREE.MeshLambertMaterial({ map: pixelTex(TEX + 'items/' + texture + '.png'), transparent: true, alphaTest: 0.1, side: THREE.DoubleSide })
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), m)
  mesh.position.set(0, -1, 3)
  mesh.rotation.set(0, Math.PI / 2, -Math.PI / 4)
  pl.bones.rightItem.add(mesh)
}


// ---------- blocks drawn as props (the viewer skips block-entity models like beds and chests) ----------
function canvasTex (w, h, draw) {
  const c = document.createElement('canvas')
  c.width = w; c.height = h
  const t = new THREE.CanvasTexture(c)
  t.magFilter = THREE.NearestFilter
  t.minFilter = THREE.NearestFilter
  const ctx = c.getContext('2d')
  ctx.imageSmoothingEnabled = false
  draw(ctx, () => { t.needsUpdate = true })
  return t
}
function loadImg (src, cb) { const i = new window.Image(); i.onload = () => cb(i); i.src = src }

// Bed: 1 x 0.56 x 2 blocks, head end toward `face` compass direction (the pillow side).
window.studio.addBed = (id, x, y, z, faceDeg, color = 'red') => {
  const top = canvasTex(16, 32, (ctx, done) => loadImg(TEX + 'blocks/' + color + '_wool.png', (wool) => {
    ctx.drawImage(wool, 0, 0, 16, 16); ctx.drawImage(wool, 0, 16, 16, 16)
    ctx.fillStyle = '#e9e6de'; ctx.fillRect(0, 0, 16, 9) // pillow + sheet at the head
    ctx.fillStyle = '#cfcac0'; ctx.fillRect(2, 2, 12, 5)
    done()
  }))
  const side = canvasTex(32, 9, (ctx, done) => loadImg(TEX + 'blocks/' + color + '_wool.png', (wool) => loadImg(TEX + 'blocks/oak_planks.png', (planks) => {
    ctx.drawImage(planks, 0, 0, 16, 9, 0, 0, 32, 9)
    ctx.drawImage(wool, 0, 0, 16, 6, 9, 0, 23, 6)
    ctx.fillStyle = '#e9e6de'; ctx.fillRect(0, 0, 9, 6)
    done()
  })))
  const end = canvasTex(16, 9, (ctx, done) => loadImg(TEX + 'blocks/oak_planks.png', (planks) => { ctx.drawImage(planks, 0, 0, 16, 9, 0, 0, 16, 9); done() }))
  const m = (map) => new THREE.MeshLambertMaterial({ map })
  // Box faces: +x, -x, +y, -y, +z, -z. Built with the head toward -z, then rotated.
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 0.5625, 2), [m(side), m(side), m(top), m(end), m(end), m(end)])
  const g = new THREE.Group()
  mesh.position.y = 0.28
  g.add(mesh)
  g.position.set(x, y, z)
  g.rotation.y = -faceDeg * Math.PI / 180
  viewer.scene.add(g)
  props[id] = g
}

// Chest (single), front facing `face` compass direction, textures from entity/chest/normal.png.
window.studio.addChest = (id, x, y, z, faceDeg) => {
  const face = (sx) => canvasTex(14, 15, (ctx, done) => loadImg(TEX + 'entity/chest/normal.png', (img) => {
    ctx.drawImage(img, sx, 14, 14, 5, 0, 0, 14, 5)
    ctx.drawImage(img, sx, 33, 14, 10, 0, 5, 14, 10)
    done()
  }))
  const front = canvasTex(14, 15, (ctx, done) => loadImg(TEX + 'entity/chest/normal.png', (img) => {
    ctx.drawImage(img, 42, 14, 14, 5, 0, 0, 14, 5)
    ctx.drawImage(img, 42, 33, 14, 10, 0, 5, 14, 10)
    ctx.drawImage(img, 1, 1, 2, 4, 6, 3, 2, 4) // latch
    done()
  }))
  const topT = canvasTex(14, 14, (ctx, done) => loadImg(TEX + 'entity/chest/normal.png', (img) => { ctx.drawImage(img, 14, 0, 14, 14, 0, 0, 14, 14); done() }))
  const m = (map) => new THREE.MeshLambertMaterial({ map })
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.875, 0.875, 0.875), [m(face(0)), m(face(28)), m(topT), m(topT), m(front), m(face(14))])
  const g = new THREE.Group()
  mesh.position.y = 0.4375
  g.add(mesh)
  g.position.set(x, y, z)
  g.rotation.y = Math.PI - faceDeg * Math.PI / 180
  viewer.scene.add(g)
  props[id] = g
}

// ---------- first-person hand item + screen effects ----------
const hand = document.createElement('img')
hand.style.cssText = 'position:fixed;pointer-events:none;image-rendering:pixelated;display:none;z-index:3'
document.body.appendChild(hand)
// item: texture path under textures (e.g. 'items/diamond_pickaxe'), swing 0..1 (0 = rest), bob in px
window.studio.setHand = (item, swing = 0, bob = 0) => {
  if (!item) { hand.style.display = 'none'; return }
  const h = window.innerHeight
  const size = Math.round(h * 0.42)
  if (hand.dataset.item !== item) { hand.src = TEX + item + '.png'; hand.dataset.item = item }
  const s = Math.sin(swing * Math.PI)
  hand.style.display = 'block'
  hand.style.width = hand.style.height = size + 'px'
  hand.style.right = Math.round(window.innerWidth * 0.08 + s * size * 0.25) + 'px'
  hand.style.bottom = Math.round(-size * 0.12 - bob + s * size * 0.15) + 'px'
  hand.style.transform = `rotate(${-20 - s * 55}deg)`
}

const fx = document.createElement('div')
fx.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:4'
document.body.appendChild(fx)
// f: {black 0..1, vignette 0..1, vignetteColor, glitch 0..1, seed}
window.studio.setFx = (f = {}) => {
  const layers = []
  if (f.vignette) layers.push(`radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, ${f.vignetteColor || 'rgba(0,0,0,1)'} 100%)`)
  fx.style.background = layers.join(',')
  fx.style.opacity = f.vignette ? String(Math.min(1, f.vignette)) : '1'
  const canvas = renderer.domElement
  if (f.glitch) {
    const r = (n) => { const x = Math.sin((f.seed || 1) * 12.9898 + n * 78.233) * 43758.5453; return x - Math.floor(x) }
    canvas.style.transform = `translate(${(r(1) - 0.5) * 60 * f.glitch}px, ${(r(2) - 0.5) * 20 * f.glitch}px)`
    canvas.style.filter = `hue-rotate(${Math.round(r(3) * 180 * f.glitch)}deg) contrast(${1 + f.glitch}) saturate(${1 + 2 * f.glitch})`
    fx.style.background = `repeating-linear-gradient(0deg, rgba(255,0,60,${0.25 * f.glitch}) 0 ${2 + Math.round(r(4) * 6)}px, rgba(0,255,255,${0.15 * f.glitch}) 0 ${6 + Math.round(r(5) * 20)}px, transparent 0 ${30 + Math.round(r(6) * 80)}px)` + (layers.length ? ',' + layers.join(',') : '')
    fx.style.opacity = '1'
  } else {
    canvas.style.transform = ''
    // Colour grade: 'vivid' (bright, saturated, kid-friendly), 'warm', 'cold', or none.
    canvas.style.filter = f.grade === 'vivid' ? 'saturate(1.45) contrast(1.12) brightness(1.1)' : f.grade === 'warm' ? 'saturate(1.25) sepia(.15) brightness(1.06)' : f.grade === 'cold' ? 'saturate(.9) hue-rotate(-12deg) brightness(.95)' : ''
  }
  // Kids pack overlays: flash, speed lines, bouncy reaction text.
  {
    const U = Math.min(window.innerHeight, window.innerWidth) / 1080
    const lay = (id, z) => { let el = document.getElementById(id); if (!el) { el = document.createElement('div'); el.id = id; el.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:' + z; document.body.appendChild(el) } return el }
    const fl = lay('fxflash', 7)
    fl.style.background = f.flash ? f.flash.color : 'transparent'
    fl.style.opacity = f.flash ? String(Math.max(0, f.flash.a) * 0.85) : '0'
    const sp = lay('fxspeed', 5)
    if (f.speed) {
      const rr = (n) => { const x = Math.sin((f.seed || 1) * 3.1 + n * 91.7) * 43758.5453; return x - Math.floor(x) }
      sp.style.background = `repeating-conic-gradient(from ${Math.round(rr(1) * 360)}deg at 50% 50%, rgba(255,255,255,${0.55 * f.speed}) 0deg 0.6deg, transparent 0.6deg ${4 + Math.round(rr(2) * 5)}deg)`
      sp.style.webkitMaskImage = sp.style.maskImage = 'radial-gradient(ellipse at center, transparent 38%, #000 75%)'
      sp.style.opacity = '1'
    } else sp.style.opacity = '0'
    const pp = lay('fxpops', 8)
    pp.innerHTML = (f.pops || []).map((p) => {
      const k = Math.min(1, p.age / 0.16)
      const sc = p.age < 0.16 ? 0.2 + 1.0 * k : 1 + 0.1 * Math.exp(-(p.age - 0.16) * 6) * Math.cos((p.age - 0.16) * 30)
      const out = p.age > 1.2 ? 1 - (p.age - 1.2) / 0.3 : 1
      const rot = [-9, 7, -5, 10, -7][p.i % 5]
      const top = [16, 30, 22, 34, 18][p.i % 5]
      const left = [50, 46, 54, 50, 48][p.i % 5]
      return `<div style="position:absolute;left:${left}%;top:${top}%;transform:translate(-50%,-50%) rotate(${rot}deg) scale(${sc});opacity:${out};font:900 ${Math.min(140, 820 / Math.max(4, [...String(p.text)].length)) * Math.min(window.innerWidth, window.innerHeight * 1.2) / 1080}px Impact,'Arial Black','DejaVu Sans',sans-serif,'Noto Color Emoji';color:${p.color || '#ffd21f'};-webkit-text-stroke:${10 * U}px #000;paint-order:stroke fill;text-shadow:0 ${10 * U}px 0 #000;white-space:nowrap">${String(p.text).replace(/(\p{Extended_Pictographic}\uFE0F?)/gu, '<span style="font-family:\'Noto Color Emoji\';-webkit-text-stroke:0">$1</span>')}</div>`
    }).join('')
  }
  // F3-style coordinates readout (top-left, like Minecraft's debug screen).
  {
    const U = Math.min(window.innerHeight, window.innerWidth) / 1080
    let el = document.getElementById('fxcoords')
    if (!el) { el = document.createElement('div'); el.id = 'fxcoords'; document.body.appendChild(el) }
    if (f.coords) {
      const fmt = (n) => Math.round(n).toLocaleString('en-US')
      let xs = fmt(f.coords.x)
      if (f.coords.g) {
        const r = (n) => { const v = Math.sin((f.seed || 1) * 7.7 + n * 13.1) * 43758.5453; return v - Math.floor(v) }
        xs = xs.split('').map((c, i) => (/\d/.test(c) && r(i) < f.coords.g ? '#%&?!$'[Math.floor(r(i + 40) * 6)] : c)).join('')
      }
      el.style.cssText = `position:fixed;left:${24 * U}px;top:${110 * U}px;pointer-events:none;z-index:6;font:${40 * U}px 'DejaVu Sans Mono',monospace;color:#fff;line-height:1.35;text-shadow:${3 * U}px ${3 * U}px 0 #3f3f3f`
      el.innerHTML = `<div style="background:rgba(80,80,80,.55);display:inline-block;padding:0 ${8 * U}px">Minecraft Beta 1.7.3</div><br><div style="background:rgba(80,80,80,.55);display:inline-block;padding:0 ${8 * U}px">X: ${xs}  Y: ${f.coords.yz[0]}  Z: ${f.coords.yz[1]}</div>`
    } else el.style.cssText = 'display:none'
  }
  // Missing-texture checker over the whole screen, a grey grid in the sky, TV static.
  const layer = (id, z, css) => { let el = document.getElementById(id); if (!el) { el = document.createElement('div'); el.id = id; el.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:' + z + ';' + css; document.body.appendChild(el) } return el }
  const unit = Math.round(window.innerHeight / 9)
  layer('fxchecker', 4, `background:repeating-conic-gradient(#f800f8 0 25%, #000 0 50%) 0 0/${unit}px ${unit}px;mix-blend-mode:hard-light`).style.opacity = String(f.checker || 0)
  layer('fxgrid', 2, `background:linear-gradient(#1e1e22 2px, transparent 2px) 0 0/${unit}px ${unit}px, linear-gradient(90deg, #1e1e22 2px, transparent 2px) 0 0/${unit}px ${unit}px;`)
  // grid 0..1 = opacity over the top (sky) part of the screen; above 1 the grid spreads down the whole screen.
  const gEl = document.getElementById('fxgrid')
  const reach = 30 + Math.max(0, (f.grid || 0) - 1) * 140
  gEl.style.opacity = String(Math.min(1, f.grid || 0))
  gEl.style.webkitMaskImage = gEl.style.maskImage = `linear-gradient(to bottom, #000 0 ${reach}%, transparent ${reach + 18}%)`
  const st = layer('fxstatic', 6, 'background-size:100% 100%;image-rendering:pixelated')
  st.style.opacity = String(f.static || 0)
  if (f.static) {
    const c = document.createElement('canvas'); c.width = 240; c.height = 135
    const ctx = c.getContext('2d'); const img = ctx.createImageData(240, 135)
    let seed = (f.seed || 1) * 9301 + 49297
    for (let i = 0; i < img.data.length; i += 4) {
      seed = (seed * 16807) % 2147483647
      const v = seed % 256
      img.data[i] = v * 0.8 + (i % 7 === 0 ? 60 : 0); img.data[i + 1] = v * 0.55; img.data[i + 2] = v; img.data[i + 3] = 255
    }
    ctx.putImageData(img, 0, 0)
    st.style.backgroundImage = `url(${c.toDataURL()})`
  }
  // Myth counter (top-right), myth banner (top-left), REAL/BUSTED stamp (pops in).
  {
    const u = Math.min(window.innerHeight, window.innerWidth) / 1080
    const c = layer('fxcounter', 6, '')
    c.style.cssText = `position:fixed;right:${36 * u}px;top:${30 * u}px;pointer-events:none;z-index:6;display:${f.counter ? 'block' : 'none'};font:900 ${64 * u}px Impact,'Arial Black',sans-serif;color:#fff;background:rgba(10,0,20,.72);border:${4 * u}px solid #b066ff;border-radius:${14 * u}px;padding:${6 * u}px ${22 * u}px;text-shadow:0 ${4 * u}px 0 #000`
    c.textContent = f.counter || ''
    const lb = layer('fxlabel', 6, '')
    lb.style.cssText = `position:fixed;left:${36 * u}px;top:${30 * u}px;max-width:62%;pointer-events:none;z-index:6;display:${f.label ? 'block' : 'none'};font:800 ${48 * u}px 'Arial Black',Impact,sans-serif;color:#fff;background:rgba(0,0,0,.72);border-left:${10 * u}px solid #ffd21f;padding:${10 * u}px ${22 * u}px;line-height:1.15;text-shadow:0 ${3 * u}px 0 #000`
    lb.textContent = f.label || ''
    const sp = layer('fxstamp', 6, '')
    if (f.stamp) {
      const real = f.stamp.text === 'REAL'
      const k = Math.min(1, f.stamp.age / 0.18)
      const sc = 1.8 - 0.8 * (1 - Math.pow(1 - k, 3))
      sp.style.cssText = `position:fixed;right:${80 * u}px;top:${190 * u}px;pointer-events:none;z-index:6;display:block;font:900 ${120 * u}px Impact,'Arial Black',sans-serif;letter-spacing:${4 * u}px;color:${real ? '#39ff6a' : '#ff3030'};border:${10 * u}px solid currentColor;border-radius:${18 * u}px;padding:${4 * u}px ${34 * u}px;background:rgba(0,0,0,.55);transform:rotate(-8deg) scale(${sc});opacity:${k};text-shadow:0 ${6 * u}px 0 #000`
      sp.textContent = (real ? '✔ ' : '✘ ') + f.stamp.text
    } else sp.style.display = 'none'
  }
  // DAY counter + survival HUD (hotbar with items, hardcore hearts, hunger), drawn from the real GUI textures.
  {
    const u = Math.min(window.innerHeight, window.innerWidth) / 1080
    const dy = layer('fxday', 6, '')
    dy.style.cssText = `position:fixed;right:${44 * u}px;top:${30 * u}px;pointer-events:none;z-index:6;display:${f.day ? 'block' : 'none'};font:900 ${110 * u}px Impact,'Arial Black',sans-serif;color:#fff;letter-spacing:${2 * u}px;-webkit-text-stroke:${7 * u}px #000;paint-order:stroke fill;text-shadow:0 ${8 * u}px 0 #000`
    dy.textContent = f.day ? 'DAY ' + f.day : ''
    const hd = layer('fxhud', 3, '')
    if (f.hud) {
      const g = 3 * u // one GUI pixel
      const T = '/textures/1.16.4/gui/'
      const spr = (img, sx, sy, w, h, x, y, extra = '') => `<div style="position:absolute;left:${x * g}px;top:${y * g}px;width:${w * g}px;height:${h * g}px;background:url(${T}${img}) ${-sx * g}px ${-sy * g}px/${256 * g}px ${256 * g}px;image-rendering:pixelated;${extra}"></div>`
      let html = spr('widgets.png', 0, 0, 182, 22, 0, 17) + spr('widgets.png', 0, 22, 24, 24, -1 + 20 * (f.hud.slot || 0), 16)
      ;(f.hud.items || []).forEach((it, i) => {
        if (!it) return
        const src = it.includes('/') ? it : 'items/' + it
        html += `<img src="/textures/1.16.4/${src}.png" style="position:absolute;left:${(3 + 20 * i) * g}px;top:${20 * g}px;width:${16 * g}px;height:${16 * g}px;image-rendering:pixelated">`
      })
      const hv = 45 * (f.hud.hardcore === false ? 0 : 1) // hardcore heart row
      const hearts = Math.max(0, Math.min(10, f.hud.hearts ?? 10))
      for (let i = 0; i < 10; i++) {
        html += spr('icons.png', 16, hv, 9, 9, i * 8, 6)
        if (hearts >= i + 1) html += spr('icons.png', 52, hv, 9, 9, i * 8, 6)
        else if (hearts > i) html += spr('icons.png', 61, hv, 9, 9, i * 8, 6)
        const food = f.hud.food ?? 10
        html += spr('icons.png', 16, 27, 9, 9, 182 - 9 - i * 8, 6)
        if (food >= i + 1) html += spr('icons.png', 52, 27, 9, 9, 182 - 9 - i * 8, 6)
        else if (food > i) html += spr('icons.png', 61, 27, 9, 9, 182 - 9 - i * 8, 6)
      }
      hd.style.cssText = `position:fixed;left:50%;bottom:${4 * u}px;width:${182 * g}px;height:${40 * g}px;transform:translateX(-50%);pointer-events:none;z-index:3;display:block`
      hd.innerHTML = html
    } else { hd.style.display = 'none'; hd.innerHTML = '' }
  }
  // Book page (journal), drawn on the real book texture: f.book = "text" (\n for new lines).
  {
    const bk = layer('fxbook', 6, '')
    if (f.book) {
      const g = 4.2 * Math.min(window.innerHeight, window.innerWidth) / 1080
      bk.style.cssText = `position:fixed;inset:0;pointer-events:none;z-index:6;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.45)`
      bk.innerHTML = `<div style="position:relative;width:${192 * g}px;height:${192 * g}px;background:url(/textures/1.16.4/gui/book.png) 0 0/${256 * g}px ${256 * g}px;image-rendering:pixelated">
        <div style="position:absolute;left:${36 * g}px;top:${30 * g}px;width:${114 * g}px;font:${9.5 * g}px/1.25 ui-monospace,Consolas,monospace;color:#1a1a1a;white-space:pre-wrap">${f.book.replace(/</g, '&lt;')}</div></div>`
    } else { bk.style.display = 'none'; bk.innerHTML = '' }
  }
  // In-game chat, bottom-left like Minecraft: f.chat = ['<Steve> hi', ...]
  const ch = layer('fxchat', 6, '')
  if (f.chat && f.chat.length) {
    const u = Math.min(window.innerHeight, window.innerWidth) / 1080
    ch.style.cssText = `position:fixed;left:${24 * u}px;bottom:${window.innerHeight * 0.3}px;pointer-events:none;z-index:6;display:flex;flex-direction:column;gap:${4 * u}px`
    ch.innerHTML = f.chat.map((l) => `<div style="background:rgba(0,0,0,.5);padding:${6 * u}px ${14 * u}px;font:${38 * u}px ui-monospace,Consolas,monospace;color:${/left the game|joined the game/.test(l) ? '#ffff55' : '#fff'};text-shadow:${3 * u}px ${3 * u}px 0 #3f3f3f;white-space:pre">${l.replace(/</g, '&lt;')}</div>`).join('')
  } else { ch.style.display = 'none'; ch.innerHTML = '' }
  const dk = layer('fxdesktop', 7, 'display:none')
  if (f.desktop && f.desktop.p > 0) {
    const p = f.desktop.p
    const text = f.desktop.text || ''
    const typed = text.slice(0, Math.round(text.length * Math.max(0, Math.min(1, (p - 0.4) / 0.5))))
    const u = Math.min(window.innerHeight, window.innerWidth) / 1080
    const file = f.desktop.file || 'GLITCH.txt'
    const icon = `<div style="position:absolute;left:${60 * u}px;top:${60 * u}px;width:${150 * u}px;text-align:center;font:${22 * u}px system-ui,sans-serif;color:#fff;text-shadow:0 1px 3px #000">
      <div style="width:${80 * u}px;height:${100 * u}px;margin:0 auto ${10 * u}px;background:#f4f4f4;border-radius:${4 * u}px;box-shadow:0 2px 6px rgba(0,0,0,.5);position:relative">
        <div style="position:absolute;left:${14 * u}px;right:${14 * u}px;top:${24 * u}px;height:${50 * u}px;background:repeating-linear-gradient(#9aa 0 ${3 * u}px, transparent 0 ${10 * u}px)"></div></div>
      <span style="background:${p > 0.25 ? '#2b62c4' : 'transparent'};padding:${2 * u}px ${6 * u}px">${file}</span></div>`
    const win = p > 0.3 ? `<div style="position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);width:${900 * u}px;height:${480 * u}px;background:#fff;border-radius:${8 * u}px;box-shadow:0 ${20 * u}px ${60 * u}px rgba(0,0,0,.6);overflow:hidden;font-family:system-ui,sans-serif">
      <div style="height:${52 * u}px;background:#eceff3;display:flex;align-items:center;padding:0 ${20 * u}px;font-size:${22 * u}px;color:#333;border-bottom:1px solid #d5d9df">${file} — Text Editor<span style="margin-left:auto;letter-spacing:${18 * u}px;color:#777">– ▢ ✕</span></div>
      <div style="padding:${36 * u}px ${40 * u}px;font:${54 * u}px ui-monospace,Consolas,monospace;color:#111;white-space:pre-wrap">${typed}<span style="border-left:${4 * u}px solid #111;margin-left:${2 * u}px;opacity:${(f.seed || 0) % 20 < 10 ? 1 : 0}"></span></div></div>` : ''
    dk.style.cssText = `position:fixed;inset:0;pointer-events:none;z-index:7;display:block;background:radial-gradient(ellipse at 30% 20%, #3a6fa8, #0f2742 70%)`
    dk.innerHTML = icon + win + `<div style="position:absolute;left:0;right:0;bottom:0;height:${56 * u}px;background:rgba(10,14,22,.85);display:flex;align-items:center;justify-content:flex-end;padding:0 ${24 * u}px;font:${22 * u}px system-ui,sans-serif;color:#dde">3:33 AM</div>`
  } else dk.style.display = 'none'
  let black = document.getElementById('fxblack')
  if (!black) { black = document.createElement('div'); black.id = 'fxblack'; black.style.cssText = 'position:fixed;inset:0;background:#000;pointer-events:none;z-index:5'; document.body.appendChild(black) }
  black.style.opacity = String(f.black || 0)
}
