// Turns a plain-language story into a script.yaml using Claude (needs your Anthropic API key).
const fs = require('fs')
const path = require('path')
const Anthropic = require('@anthropic-ai/sdk')
const YAML = require('yaml')

const MODEL = 'claude-opus-5'

function systemPrompt (root) {
  const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8')
  const format = readme.slice(readme.indexOf('## Script format'), readme.indexOf('## Folder layout'))
  const example = fs.readFileSync(path.join(root, 'videos', 'haunted', 'script.yaml'), 'utf8')
  const styleFile = path.join(root, 'CHANNEL_STYLE.md')
  const style = fs.existsSync(styleFile) ? fs.readFileSync(styleFile, 'utf8') : ''
  return `You write shot scripts for an automated Minecraft video maker that turns script.yaml into a YouTube video (vertical Short or landscape long-form).
The engine renders a flat Minecraft world (grass at y=63; the first block above ground is y=64) with the Steve model for every character.

${format}

## What the engine can and cannot show
- Glitch-horror tools (see the format section): custom skins glitch / glitch_mouth / missing, actor glow / float / still / scale, leash, cubes props, fx checker / grid / static / desktop, gui null items, music home / home_stutter / warped / void, sfx static / whoosh. videos/glitch-short/script.yaml is a finished Short using them.
- Structures: camp, hut, cottage, house, farm, hill. Anything else is built with "fills" (boxes) and "blocks" (Minecraft 1.16 block names).
- Use format: landscape for long-form videos (over ~60 s) and vertical for Shorts.
- Hut at [x, z] occupies x-2..x+2, z-2..z+2; its door is at [x, z+2] facing south; the inside floor is x-1..x+1, z-1..z+1.
- Camp at [x, z] occupies about x-6..x+4, z-2..z+4 (campfire at [x, z], barrels at [x+2, z-1] and [x+3, z-1]).
- Not drawn as blocks: chests and beds (use the chest/bed props), animals, lava, particles, the HUD. Characters: Steve, the alex skin, villager, zombie, armor_stand.
- Camera positions must never be inside blocks: keep at least 0.7 blocks from any wall; enter buildings only through an open door.
- Actors walk at up to ~4.5 blocks/second; the camera at ~4 while "running". Keep moves physically plausible.
- The whole world is inside x -48..47, z -64..31; keep action within x -25..25, z -40..10.

## Writing rules for a good Short
- 25–45 seconds total, 5–8 shots. Hook in the first 2 seconds. Tell one compact story with a reveal or punchline.
- Narration: short spoken lines that fit the shot (about 2.8 words per second). Leave silence where tension helps.
- Captions: max ~8 words per line, split with \\n. Use caption_style: big for one-word shock moments.
- Pick a music mood per shot (mystery, tension, silence, awkward, chase, calm, happy).
- End on a hard cut that loops back to the opening line when possible.
- Stage it as gameplay; never claim a secret or official game feature.

## Channel style (follow it)
${style}

## Example (a finished, working script)
\`\`\`yaml
${example}
\`\`\`

Reply with the complete script inside a single \`\`\`yaml code block and nothing else.`
}

async function writeScript ({ apiKey, story, root, current }) {
  const client = new Anthropic({ apiKey })
  let user = `Write the script.yaml for this video idea:\n\n${story}`
  if (current) user += `\n\nHere is the current script. Improve it to match the idea, keeping what already works:\n\`\`\`yaml\n${current}\n\`\`\``
  const stream = client.beta.messages.stream({
    model: MODEL,
    max_tokens: 32000,
    thinking: { type: 'adaptive' },
    betas: ['server-side-fallback-2026-07-01'],
    fallbacks: 'default', // if the request is declined, Anthropic re-runs it on its recommended fallback model
    system: systemPrompt(root),
    messages: [{ role: 'user', content: user }]
  })
  let msg
  try {
    msg = await stream.finalMessage()
  } catch (e) {
    if (e instanceof Anthropic.AuthenticationError) throw new Error('Your Anthropic API key was rejected. Check it in Settings.')
    if (e instanceof Anthropic.RateLimitError) throw new Error('Rate limited by the Anthropic API. Wait a minute and try again.')
    if (e instanceof Anthropic.APIConnectionError) throw new Error('Could not reach the Anthropic API. Check your internet connection.')
    throw e
  }
  if (msg.stop_reason === 'refusal') throw new Error('Claude declined to write this script. Try rewording the idea.')
  if (msg.stop_reason === 'max_tokens') throw new Error('The script came out too long. Try a shorter idea.')
  const text = msg.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n')
  const m = text.match(/```ya?ml\s*\n([\s\S]*?)```/)
  const yamlText = (m ? m[1] : text).trim() + '\n'
  const doc = YAML.parse(yamlText)
  if (!doc || !Array.isArray(doc.shots) || !doc.shots.length) throw new Error('Claude returned a script without shots. Try again.')
  for (const [i, s] of doc.shots.entries()) {
    if (!s.duration || !s.camera || !Array.isArray(s.camera.keys)) throw new Error(`Shot ${i + 1} is missing duration or camera keys. Try again.`)
  }
  return yamlText
}

module.exports = { writeScript }
