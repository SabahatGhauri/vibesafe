// Game Narrator local app: a dashboard at http://localhost:4747 for writing, previewing and rendering videos.
// Start with start.bat (Windows) / start.command (Mac) / ./start.sh (Linux), or: node app/server.js
const fs = require('fs')
const path = require('path')
const { spawn, spawnSync } = require('child_process')
const express = require('express')
const YAML = require('yaml')
const { writeScript } = require('./writer')

const ROOT = path.join(__dirname, '..')
const VIDEOS = path.join(ROOT, 'videos')
const CONFIG = path.join(ROOT, 'app', 'config.json')
const PORT = Number(process.env.PORT) || 4747

const app = express()
app.use(express.json({ limit: '2mb' }))
app.use('/samples', express.static(path.join(ROOT, 'app', 'samples'), { maxAge: 0 }))
app.use('/', express.static(path.join(__dirname, 'public')))
app.use('/files', express.static(VIDEOS, { etag: false, maxAge: 0 }))

// ---------- helpers ----------
const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40)
const videoDir = (name) => {
  const n = slug(name)
  if (!n) throw new Error('bad video name')
  return path.join(VIDEOS, n)
}
function readConfig () {
  try { return JSON.parse(fs.readFileSync(CONFIG, 'utf8')) } catch { return {} }
}
function writeConfig (c) { fs.writeFileSync(CONFIG, JSON.stringify(c, null, 2)) }

let PYTHON = null
function python () {
  if (PYTHON) return PYTHON
  for (const cmd of [process.env.PYTHON, 'python3', 'python', 'py'].filter(Boolean)) {
    const r = spawnSync(cmd, ['--version'], { encoding: 'utf8', shell: process.platform === 'win32' })
    if (r.status === 0 && /Python 3/.test(r.stdout + r.stderr)) return (PYTHON = cmd)
  }
  return null
}

function fileInfo (dir, name) {
  const p = path.join(dir, name)
  return fs.existsSync(p) ? { url: `/files/${path.basename(dir)}/${name}?v=${Math.round(fs.statSync(p).mtimeMs)}` } : null
}

// ---------- jobs (one render at a time) ----------
const jobs = {}
let running = null
function startJob (name, args) {
  if (running) throw new Error('Another job is still running. Wait for it to finish.')
  const id = Date.now().toString(36)
  const job = { id, name, args, log: [], done: false, ok: null, listeners: new Set(), started: Date.now() }
  jobs[id] = job
  running = job
  const py = python()
  if (!py) throw new Error('Python 3 not found. Install it from python.org and run setup again.')
  const child = spawn(py, ['-u', path.join(ROOT, 'make_video.py'), ...args], { cwd: ROOT, shell: process.platform === 'win32' })
  const push = (line) => {
    job.log.push(line)
    for (const l of job.listeners) l(`data: ${JSON.stringify({ line })}\n\n`)
  }
  let buf = ''
  const onData = (d) => {
    buf += d.toString()
    const parts = buf.split(/\r?\n/)
    buf = parts.pop()
    parts.filter((l) => l.trim()).forEach(push)
  }
  child.stdout.on('data', onData)
  child.stderr.on('data', onData)
  child.on('close', (code) => {
    if (buf.trim()) push(buf)
    job.done = true
    job.ok = code === 0
    push(code === 0 ? `✔ finished in ${Math.round((Date.now() - job.started) / 1000)}s` : `✖ failed (exit ${code})`)
    for (const l of job.listeners) l(`event: done\ndata: ${JSON.stringify({ ok: job.ok })}\n\n`)
    running = null
  })
  return job
}

// ---------- API ----------
const wrap = (fn) => async (req, res) => {
  try { res.json(await fn(req, res)) } catch (e) { res.status(400).json({ error: e.message }) }
}

app.get('/api/health', wrap(() => {
  const checks = {
    node_modules: fs.existsSync(path.join(ROOT, 'node_modules', 'prismarine-viewer')),
    studio: fs.existsSync(path.join(ROOT, 'studio', 'dist', 'studio.js')),
    python: !!python(),
    voice_model: fs.existsSync(path.join(ROOT, 'models', 'kokoro-v1.0.onnx')),
    api_key: !!(readConfig().apiKey || process.env.ANTHROPIC_API_KEY)
  }
  return { checks, running: running ? { id: running.id, name: running.name } : null }
}))

app.get('/api/videos', wrap(() => {
  if (!fs.existsSync(VIDEOS)) return []
  return fs.readdirSync(VIDEOS).filter((n) => fs.existsSync(path.join(VIDEOS, n, 'script.yaml'))).map((n) => {
    let title = n
    try { title = YAML.parse(fs.readFileSync(path.join(VIDEOS, n, 'script.yaml'), 'utf8')).title || n } catch {}
    return { name: n, title, hasVideo: fs.existsSync(path.join(VIDEOS, n, `${n}.mp4`)), mtime: fs.statSync(path.join(VIDEOS, n, 'script.yaml')).mtimeMs }
  }).sort((a, b) => b.mtime - a.mtime)
}))

function uploadText (doc, file) {
  const tags = (doc.tags || []).map((t) => '#' + String(t).replace(/^#/, '')).join(' ')
  return `TITLE:\n${doc.title || ''}\n\nDESCRIPTION:\n${(doc.description || '').trim()}\n${tags}\n\nFILE: ${file}\n`
}

// Voice lines of a video: text, style, the rendered AI line (if any) and your own recording (if any).
function voiceLines (dir, doc) {
  const n = path.basename(dir)
  const mineDir = path.join(dir, 'my_voice')
  return (doc.shots || []).map((s, i) => {
    const id = i + 1
    if (!s.vo) return null
    const mine = fs.existsSync(mineDir) ? fs.readdirSync(mineDir).find((f) => f.startsWith(`shot${id}.`)) : null
    const ai = path.join(dir, 'build', 'vo', `shot${id}.wav`)
    return {
      id,
      text: s.vo,
      style: s.vo_style || '',
      ai: !mine && fs.existsSync(ai) ? `/files/${n}/build/vo/shot${id}.wav?v=${Math.round(fs.statSync(ai).mtimeMs)}` : null,
      mine: mine ? `/files/${n}/my_voice/${mine}?v=${Math.round(fs.statSync(path.join(mineDir, mine)).mtimeMs)}` : null
    }
  }).filter(Boolean)
}

app.get('/api/videos/:name', wrap((req) => {
  const dir = videoDir(req.params.name)
  const n = path.basename(dir)
  const text = fs.readFileSync(path.join(dir, 'script.yaml'), 'utf8')
  let doc = {}
  try { doc = YAML.parse(text) || {} } catch {}
  return {
    details: { title: doc.title || '', description: doc.description || '', tags: (doc.tags || []).join(', '), voice: doc.voice || '' },
    isExample: doc.example === true,
    hasKey: !!(readConfig().apiKey || process.env.ANTHROPIC_API_KEY),
    lines: voiceLines(dir, doc),
    srt: fileInfo(dir, `${n}.srt`),
    name: n,
    script: fs.readFileSync(path.join(dir, 'script.yaml'), 'utf8'),
    story: fs.existsSync(path.join(dir, 'story.txt')) ? fs.readFileSync(path.join(dir, 'story.txt'), 'utf8') : '',
    preview: fileInfo(dir, 'preview.jpg'),
    video: fileInfo(dir, `${n}.mp4`),
    thumbnail: fileInfo(dir, 'thumbnail.jpg'),
    upload: fs.existsSync(path.join(dir, 'upload.txt')) ? fs.readFileSync(path.join(dir, 'upload.txt'), 'utf8') : ''
  }
}))

app.post('/api/videos', wrap((req) => {
  const dir = videoDir(req.body.name)
  if (fs.existsSync(dir)) throw new Error('A video with that name already exists.')
  fs.mkdirSync(dir, { recursive: true })
  const template = path.join(VIDEOS, 'haunted', 'script.yaml')
  const title = String(req.body.name).trim().replace(/\n/g, ' ')
  const text = fs.existsSync(template) ? fs.readFileSync(template, 'utf8') : 'title: New video\nshots: []\n'
  // Start from the example so there's always something that renders; give it the new title.
  // The copied example is marked so it can never be rendered by mistake as "your" video.
  fs.writeFileSync(path.join(dir, 'script.yaml'), text.replace(/^title:.*$/m, `title: ${JSON.stringify(title)}\nexample: true   # remove this line (or click "Write script with Claude") once this is your own script`))
  if (req.body.story) fs.writeFileSync(path.join(dir, 'story.txt'), req.body.story)
  return { name: path.basename(dir) }
}))

app.put('/api/videos/:name/script', wrap((req) => {
  const dir = videoDir(req.params.name)
  const text = String(req.body.script || '')
  const doc = YAML.parse(text) // throws with a line number if the YAML is broken
  if (!doc || !Array.isArray(doc.shots)) throw new Error('The script needs a "shots:" list.')
  fs.writeFileSync(path.join(dir, 'script.yaml'), text)
  if (typeof req.body.story === 'string') fs.writeFileSync(path.join(dir, 'story.txt'), req.body.story)
  return { ok: true }
}))

// Replace one top-level key in a YAML file without touching the rest of it (layout and comments stay as written).
function setTopKey (text, key, value) {
  let block
  if (Array.isArray(value)) block = `${key}: [${value.map((v) => JSON.stringify(v)).join(', ')}]`
  else if (typeof value === 'string' && value.includes('\n')) block = `${key}: |\n${value.split('\n').map((l) => '  ' + l).join('\n')}`
  else block = `${key}: ${JSON.stringify(value)}`
  // FIX-2026-10-04: handles block-style lists ("- item") and Windows line endings.
  const lines = text.replace(/\r\n/g, '\n').split('\n')
  const start = lines.findIndex((l) => l.startsWith(key + ':'))
  if (start === -1) {
    const t = lines.findIndex((l) => l.startsWith('title:'))
    lines.splice(t === -1 ? 0 : t + 1, 0, block)
    return lines.join('\n')
  }
  let end = start + 1
  // A value continues on indented lines and, for lists written in block style, on "- item" lines at column 0.
  const cont = (l) => l !== undefined && (l.startsWith(' ') || l.startsWith('- ') || l === '-')
  const nextFilled = (i) => { while (i < lines.length && lines[i] === '') i++; return lines[i] }
  while (end < lines.length && (cont(lines[end]) || (lines[end] === '' && cont(nextFilled(end))))) end++
  lines.splice(start, end - start, block)
  return lines.join('\n')
}

// Save title / description / tags / voice into script.yaml (only those lines change) and refresh upload.txt.
app.put('/api/videos/:name/details', wrap((req) => {
  const dir = videoDir(req.params.name)
  const n = path.basename(dir)
  const file = path.join(dir, 'script.yaml')
  let text = fs.readFileSync(file, 'utf8')
  const b = req.body
  if (typeof b.title === 'string') text = setTopKey(text, 'title', b.title.trim())
  if (typeof b.description === 'string') text = setTopKey(text, 'description', b.description.trim())
  if (typeof b.tags === 'string') text = setTopKey(text, 'tags', b.tags.split(/[,\n]/).map((t) => t.trim().replace(/^#/, '')).filter(Boolean))
  if (typeof b.voice === 'string' && b.voice) text = setTopKey(text, 'voice', b.voice.replace(/[^a-z_]/g, ''))
  const doc = YAML.parse(text) // make sure the result is still valid
  fs.writeFileSync(file, text)
  fs.writeFileSync(path.join(dir, 'upload.txt'), uploadText(doc, `${n}.mp4`))
  return { ok: true, script: text }
}))

// Play a voice before rendering: synthesizes one line with the chosen voice (cached).
app.post('/api/voice-sample', wrap((req) => new Promise((resolve, reject) => {
  const voice = String(req.body.voice || 'gamer').replace(/[^a-z_]/g, '')
  const text = String(req.body.text || 'I found my inventory in a camp I have never visited.').slice(0, 300)
  const style = String(req.body.style || 'normal').replace(/[^a-z]/g, '')
  const outDir = path.join(ROOT, 'app', 'samples')
  fs.mkdirSync(outDir, { recursive: true })
  const key = require('crypto').createHash('md5').update(voice + '|' + style + '|' + text).digest('hex').slice(0, 12)
  const out = path.join(outDir, `${voice}-${key}.wav`)
  if (fs.existsSync(out)) return resolve({ url: `/samples/${path.basename(out)}` })
  const py = python()
  if (!py) return reject(new Error('Python 3 not found.'))
  const child = spawn(py, [path.join(ROOT, 'tools', 'voice_sample.py'), voice, style, out, path.join(ROOT, 'models')], { cwd: ROOT, shell: process.platform === 'win32' })
  let err = ''
  child.stdin.end(text)
  child.stderr.on('data', (d) => { err += d })
  child.on('close', (code) => code === 0 ? resolve({ url: `/samples/${path.basename(out)}` }) : reject(new Error('Could not make the sample: ' + err.split('\n').filter(Boolean).pop())))
})))

// Upload your own recording for one line (any audio format). It replaces the AI voice for that line.
app.put('/api/videos/:name/my-voice/:shot', express.raw({ type: () => true, limit: '60mb' }), wrap((req) => {
  const dir = videoDir(req.params.name)
  const shot = Number(req.params.shot)
  const ext = String(req.query.ext || 'wav').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'wav'
  if (!shot || !req.body || !req.body.length) throw new Error('No audio received.')
  const mineDir = path.join(dir, 'my_voice')
  fs.mkdirSync(mineDir, { recursive: true })
  for (const f of fs.readdirSync(mineDir)) if (f.startsWith(`shot${shot}.`)) fs.unlinkSync(path.join(mineDir, f))
  fs.writeFileSync(path.join(mineDir, `shot${shot}.${ext}`), req.body)
  return { ok: true }
}))
app.delete('/api/videos/:name/my-voice/:shot', wrap((req) => {
  const mineDir = path.join(videoDir(req.params.name), 'my_voice')
  const shot = Number(req.params.shot)
  if (fs.existsSync(mineDir)) for (const f of fs.readdirSync(mineDir)) if (f.startsWith(`shot${shot}.`)) fs.unlinkSync(path.join(mineDir, f))
  return { ok: true }
}))

// Show the video's folder in Explorer / Finder.
app.post('/api/videos/:name/open-folder', wrap((req) => {
  const dir = videoDir(req.params.name)
  const opener = process.platform === 'win32' ? ['explorer', [dir]] : process.platform === 'darwin' ? ['open', [dir]] : ['xdg-open', [dir]]
  const c = spawn(opener[0], opener[1], { stdio: 'ignore', detached: true })
  c.on('error', () => {})
  c.unref()
  return { path: dir }
}))

app.post('/api/videos/:name/generate', wrap(async (req) => {
  const dir = videoDir(req.params.name)
  const apiKey = readConfig().apiKey || process.env.ANTHROPIC_API_KEY
  if (!apiKey) throw new Error('Add your Anthropic API key in Settings first.')
  const story = String(req.body.story || '').trim()
  if (!story) throw new Error('Write the story first.')
  fs.writeFileSync(path.join(dir, 'story.txt'), story)
  const yamlText = await writeScript({ apiKey, story, root: ROOT, current: req.body.revise ? fs.readFileSync(path.join(dir, 'script.yaml'), 'utf8') : null })
  fs.writeFileSync(path.join(dir, 'script.yaml'), yamlText)
  return { script: yamlText }
}))

app.post('/api/videos/:name/run', wrap((req) => {
  const dir = videoDir(req.params.name)
  const args = [path.join(dir, 'script.yaml')]
  const mode = req.body.mode
  if (mode === 'preview') args.push('--preview')
  else if (mode === 'audio') args.push('--no-render')
  else if (mode === 'only') {
    const shots = String(req.body.shots || '').replace(/[^0-9,]/g, '')
    if (!shots) throw new Error('Type the shot numbers to re-render, e.g. 5,6')
    args.push('--only', shots)
  }
  let doc = {}
  try { doc = YAML.parse(fs.readFileSync(path.join(dir, 'script.yaml'), 'utf8')) || {} } catch {}
  if (doc.example === true) {
    throw new Error('This video still has the EXAMPLE script (the haunted Short), so it would make the old video again. ' +
      'First turn your story into a script: click "✨ Write script with Claude" in step 1, or paste your own script into step 2 and click Save.')
  }
  const job = startJob(path.basename(dir), args)
  return { job: job.id }
}))

app.get('/api/jobs/:id/stream', (req, res) => {
  const job = jobs[req.params.id]
  if (!job) return res.status(404).end()
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' })
  for (const line of job.log) res.write(`data: ${JSON.stringify({ line })}\n\n`)
  if (job.done) return res.end(`event: done\ndata: ${JSON.stringify({ ok: job.ok })}\n\n`)
  const l = (s) => res.write(s)
  job.listeners.add(l)
  req.on('close', () => job.listeners.delete(l))
})

app.get('/api/settings', wrap(() => {
  const c = readConfig()
  return { apiKeySet: !!c.apiKey, apiKeyHint: c.apiKey ? '…' + c.apiKey.slice(-4) : '', envKey: !!process.env.ANTHROPIC_API_KEY, voice: c.voice || 'gamer' }
}))
app.put('/api/settings', wrap((req) => {
  const c = readConfig()
  if (typeof req.body.apiKey === 'string') c.apiKey = req.body.apiKey.trim() || undefined
  if (req.body.voice) c.voice = String(req.body.voice)
  writeConfig(c)
  return { ok: true }
}))

// Only listen on this computer, never on the network.
app.listen(PORT, '127.0.0.1', () => {
  const url = `http://localhost:${PORT}`
  console.log(`\n  Game Narrator is running →  ${url}\n  (keep this window open; press Ctrl+C to stop)\n`)
  if (!process.env.NO_OPEN) {
    const opener = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]]
    try { const c = spawn(opener[0], opener[1], { stdio: 'ignore', detached: true }); c.on('error', () => {}); c.unref() } catch {}
  }
})
