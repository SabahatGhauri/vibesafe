// Finds a Chromium to render with: CHROME_PATH, a Playwright browsers folder, installed Chrome/Edge, or Playwright's download.
const fs = require('fs')
const path = require('path')
const { chromium } = require('playwright-core')

function findChrome () {
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers'
  if (!fs.existsSync(base)) return undefined // let playwright find its own
  for (const d of fs.readdirSync(base).filter((n) => n.startsWith('chromium-')).sort().reverse()) {
    const p = path.join(base, d, 'chrome-linux', 'chrome')
    if (fs.existsSync(p)) return p
  }
  return undefined
}

const CHROME = process.env.CHROME_PATH || findChrome()

// Use a known Chromium path, else installed Chrome/Edge, else Playwright's own download.
// On Windows/Mac the graphics card draws the frames (many times faster than the CPU). Set RENDER_GPU=0 to force
// software rendering, or RENDER_GPU=1 to try the GPU on Linux too.
const SOFTWARE = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']
function gpuArgs () {
  const want = process.env.RENDER_GPU ?? (process.platform === 'win32' || process.platform === 'darwin' ? '1' : '0')
  if (want !== '1') return null
  const angle = process.platform === 'win32' ? 'd3d11' : process.platform === 'darwin' ? 'metal' : 'vulkan'
  return ['--use-gl=angle', `--use-angle=${angle}`, '--ignore-gpu-blocklist', '--enable-gpu', '--enable-gpu-rasterization']
}

async function launchBrowser () {
  const gpu = gpuArgs()
  const tries = [CHROME ? { executablePath: CHROME } : null, { channel: 'chrome' }, { channel: 'msedge' }, {}].filter(Boolean)
  let lastErr
  for (const args of gpu ? [gpu, SOFTWARE] : [SOFTWARE]) {
    for (const t of tries) {
      try {
        const b = await chromium.launch({ ...t, args })
        console.log(args === SOFTWARE ? 'renderer: software (CPU)' : 'renderer: graphics card (GPU)')
        return b
      } catch (e) { lastErr = e }
    }
  }
  throw new Error('No browser found for rendering. Install Google Chrome, or run: npx playwright-core install chromium\n' + lastErr.message)
}

module.exports = { launchBrowser }
