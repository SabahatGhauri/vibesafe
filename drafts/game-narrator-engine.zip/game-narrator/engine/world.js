// Builds a Minecraft world from the script's `world` section.
const { Vec3 } = require('vec3')

const VERSION = '1.16.4'
const World = require('prismarine-world')(VERSION)
const Chunk = require('prismarine-chunk')(VERSION)
const Block = require('prismarine-block')(VERSION)
const mcData = require('minecraft-data')(VERSION)
const PLAINS = mcData.biomesByName.plains.id

const st = (name, props = {}) => Block.fromProperties(name, props, PLAINS).stateId

function makeRand (seed) {
  let s = seed || 42
  return () => { s = (s * 16807) % 2147483647; return s / 2147483647 }
}

const inRect = (x, z, r) => x >= r[0] && x <= r[2] && z >= r[1] && z <= r[3]
const airState = () => st('air')

// Reusable set pieces. `at` is [x, z] on the ground (y = 64 is the first block above grass).
const STRUCTURES = {
  // Rounded hill: at [x, z] = centre, radius [rx, rz], height h (blocks above ground). Solid stone inside.
  async hill (set, [x, z], opts = {}) {
    const [rx, rz] = opts.radius || [14, 12]
    const h = opts.height || 10
    for (let dx = -rx; dx <= rx; dx++) {
      for (let dz = -rz; dz <= rz; dz++) {
        const d = Math.hypot(dx / rx, dz / rz)
        if (d > 1) continue
        const top = 63 + Math.max(0, Math.round(h * Math.pow(1 - d * d, 0.7)))
        for (let y = 55; y <= top; y++) {
          const b = y === top ? (top > 63 ? 'grass_block' : 'grass_block') : y >= top - 2 ? 'dirt' : 'stone'
          await set(x + dx, y, z + dz, b === 'grass_block' ? st('grass_block', { snowy: false }) : st(b))
        }
      }
    }
    return [x - rx, z - rz, x + rx, z + rz]
  },
  // Cozy cottage: 5x5 inside, oak walls, cobblestone back (north) wall, door in the south wall at [x, z+3].
  // Inside floor: x-2..x+2, z-2..z+2. Furnace, crafting table, bookshelf, lantern. Add the bed as a prop.
  async cottage (set, [x, z]) {
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        await set(x + dx, 63, z + dz, st('oak_planks')) // floor
        for (let y = 64; y <= 66; y++) {
          const corner = Math.abs(dx) === 3 && Math.abs(dz) === 3
          const wall = Math.abs(dx) === 3 || Math.abs(dz) === 3
          if (!wall) { await set(x + dx, y, z + dz, st('air')); continue }
          let b = corner ? st('oak_log', { axis: 'y' }) : dz === -3 ? st('cobblestone') : st('oak_planks')
          if (!corner && y === 65 && dz !== -3 && Math.abs(dx) !== 0 && (Math.abs(dx) === 2 || Math.abs(dz) === 2)) b = st('glass')
          await set(x + dx, y, z + dz, b)
        }
      }
    }
    // Stepped roof.
    for (let layer = 0; layer < 3; layer++) {
      const r = 4 - layer
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
        if (layer < 2 && Math.abs(dx) < r && Math.abs(dz) < r) continue
        await set(x + dx, 67 + layer, z + dz, st(layer === 2 ? 'oak_planks' : 'spruce_planks'))
      }
    }
    await set(x, 69, z, st('oak_planks'))
    await setDoor(set, x, z + 3, false)
    await set(x - 2, 64, z - 2, st('furnace', { facing: 'east', lit: true }))
    await set(x - 2, 64, z - 1, st('crafting_table'))
    await set(x + 2, 64, z + 2, st('bookshelf'))
    await set(x + 2, 65, z + 2, st('bookshelf'))
    await set(x - 2, 64, z + 2, st('barrel', { facing: 'up', open: false }))
    await set(x + 2, 64, z - 2, st('lantern', { hanging: false }))
    return [x - 4, z - 4, x + 4, z + 6]
  },
  // Island in the ocean (use with world.ocean): at [x, z], radius [rx, rz]. Grass top at y 63 with a sand beach,
  // dirt below, and (deep: true) solid stone down to y 48 with a few ores, so it can be mined.
  async island (set, [x, z], opts = {}) {
    const [rx, rz] = opts.radius || [9, 7]
    const deep = opts.deep
    for (let dx = -rx; dx <= rx; dx++) {
      for (let dz = -rz; dz <= rz; dz++) {
        const d = Math.hypot(dx / rx, dz / rz)
        if (d > 1) continue
        const beach = d > (opts.beach ?? 0.72)
        for (let y = deep ? 48 : 57; y <= 63; y++) {
          let b
          if (y === 63) b = beach ? st('sand') : st('grass_block', { snowy: false })
          else if (y >= 60) b = beach ? st('sand') : st('dirt')
          else b = st('stone')
          if (deep && y < 60 && !beach && ((dx * 7 + dz * 13 + y * 5) % 23 === 0)) b = st(y < 54 ? 'iron_ore' : 'coal_ore')
          await set(x + dx, y, z + dz, b)
        }
      }
    }
    return [x - rx, z - rz, x + rx, z + rz]
  },
  // Small village house (5x5), door facing south.
  async house (set, [x, z]) {
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        await set(x + dx, 63, z + dz, st('cobblestone'))
        for (let y = 64; y <= 66; y++) {
          const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2
          if (!wall) continue
          const corner = Math.abs(dx) === 2 && Math.abs(dz) === 2
          await set(x + dx, y, z + dz, corner ? st('oak_log', { axis: 'y' }) : y === 65 && (dx === 0 || dz === 0) ? st('glass') : st('oak_planks'))
        }
        await set(x + dx, 67, z + dz, st('oak_planks'))
      }
    }
    await setDoor(set, x, z + 2, false)
    return [x - 3, z - 3, x + 3, z + 4]
  },
  // Wheat farm w x d with a water channel down the middle.
  async farm (set, [x, z], opts = {}) {
    const [w, d] = opts.size || [7, 5]
    for (let dx = 0; dx < w; dx++) {
      for (let dz = 0; dz < d; dz++) {
        const water = dx === Math.floor(w / 2)
        await set(x + dx, 63, z + dz, water ? st('water', { level: 0 }) : st('farmland', { moisture: 7 }))
        if (!water) await set(x + dx, 64, z + dz, st('wheat', { age: 7 }))
      }
    }
    return [x - 1, z - 1, x + w, z + d]
  },
  async camp (set, [x, z]) {
    await set(x, 64, z, st('campfire', { lit: true, facing: 'north', signal_fire: false, waterlogged: false }))
    await set(x + 2, 64, z - 1, st('barrel', { facing: 'up', open: false }))
    await set(x + 3, 64, z - 1, st('barrel', { facing: 'north', open: false }))
    await set(x - 2, 64, z - 1, st('crafting_table'))
    await set(x, 64, z + 2, st('oak_log', { axis: 'x' }))
    await set(x + 1, 64, z + 2, st('oak_log', { axis: 'x' }))
    for (let dz = 1; dz <= 3; dz++) {
      await set(x - 5, 64, z + dz, st('white_wool'))
      await set(x - 3, 64, z + dz, st('white_wool'))
      await set(x - 4, 65, z + dz, st('white_wool'))
    }
    return [x - 6, z - 2, x + 4, z + 4]
  },
  // The Far Lands: a wall of stretched, layered terrain (the real early-Minecraft glitch at 12,550,821 blocks).
  // Occupies x from at[0] to at[0] + depth (the face looks toward -x), z from at[1] - half to at[1] + half, up to `height` blocks.
  // Long horizontal tunnels run through it. opts: {depth, half, height}
  async farlands (set, [x0, zc], opts = {}) {
    const depth = opts.depth || 24
    const half = opts.half || 40
    const height = opts.height || 70
    const STONE = st('stone'); const DIRT = st('dirt'); const GRASS = st('grass_block', { snowy: false })
    const GRAVEL = st('gravel'); const SANDB = st('sand'); const AIR = st('air')
    const solidAt = (x, y, z) => {
      const v = Math.sin(y * 0.55 + Math.sin(z * 0.07) * 2.2) + 0.6 * Math.sin(z * 0.31 + y * 0.05) + 0.35 * Math.sin((x - x0) * 0.9 + z * 0.2)
      const face = (x - x0) > 1.5 + 1.5 * Math.sin(z * 0.45) + Math.sin(y * 0.3) // jagged front face
      return face && v > -0.8
    }
    for (let x = x0; x <= x0 + depth; x++) {
      for (let z = zc - half; z <= zc + half; z++) {
        for (let y = 64; y <= 64 + height; y++) {
          if (!solidAt(x, y, z)) { await set(x, y, z, AIR); continue }
          const above = solidAt(x, y + 1, z)
          const band = Math.floor(y / 5) % 7
          const b = !above ? GRASS : !solidAt(x, y + 2, z) ? DIRT : band === 3 ? GRAVEL : band === 5 ? SANDB : STONE
          await set(x, y, z, b)
        }
      }
    }
    return [x0 - 2, zc - half, x0 + depth, zc + half]
  },
  // A Nether room: netherrack box (inside x0..x1, z0..z1, floor y 63, ceiling y 72) with lava pools and glowstone.
  async nether (set, [x0, z0], opts = {}) {
    const [w, d] = opts.size || [26, 20]
    const x1 = x0 + w; const z1 = z0 + d
    const F = opts.y ?? 63 // floor block level (put it underground, e.g. 30, so it can't be seen from the overworld)
    const NR = st('netherrack'); const LAVA = st('lava', { level: 0 }); const GLOW = st('glowstone'); const SOUL = st('soul_sand'); const AIR = st('air')
    for (let x = x0 - 1; x <= x1 + 1; x++) {
      for (let z = z0 - 1; z <= z1 + 1; z++) {
        for (let y = F - 3; y <= F + 10; y++) {
          const wall = x < x0 || x > x1 || z < z0 || z > z1 || y <= F || y >= F + 10
          const bumpy = y >= F + 7 && Math.sin(x * 0.7) + Math.cos(z * 0.6) > 1.1
          await set(x, y, z, wall || bumpy ? NR : AIR)
        }
        const lava = Math.sin(x * 0.35) * Math.cos(z * 0.4) > 0.55 && x > x0 + 3 && x < x1 - 3
        if (lava) await set(x, F, z, LAVA)
        else if ((x * 7 + z * 3) % 11 === 0) await set(x, F, z, SOUL)
        if ((x * 5 + z * 9) % 23 === 0) await set(x, F + 9, z, GLOW)
      }
    }
    return [x0 - 1, z0 - 1, x1 + 1, z1 + 1]
  },
  // 5x5 hut centred on `at`, door in the middle of the south wall (at z + 2).
  async hut (set, [x, z], opts = {}) {
    const mat = opts.material || 'dirt'
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let y = 64; y <= 67; y++) {
          if (Math.abs(dx) === 2 || Math.abs(dz) === 2 || y === 67) await set(x + dx, y, z + dz, st(mat))
        }
      }
    }
    await setDoor(set, x, z + 2, false)
    await set(x - 1, 64, z - 1, st('crafting_table'))
    return [x - 3, z - 3, x + 3, z + 4]
  }
}

async function setDoor (set, x, z, open) {
  for (const half of ['lower', 'upper']) {
    await set(x, half === 'lower' ? 64 : 65, z, doorState(half, open))
  }
}
const doorState = (half, open) => st('oak_door', { half, facing: 'south', open, hinge: 'left', powered: false })

async function buildWorld (spec) {
  const GRASS = st('grass_block', { snowy: false })
  const ocean = spec.ocean
  const WATER = st('water', { level: 0 })
  const SAND = st('sand')
  const world = new World(() => {
    const chunk = new Chunk()
    for (let x = 0; x < 16; x++) {
      for (let z = 0; z < 16; z++) {
        if (ocean) {
          // Open sea: sand seabed at y 57, water up to y 63 (islands are structures).
          chunk.setBlockStateId(new Vec3(x, 57, z), SAND)
          for (let y = 58; y <= 63; y++) chunk.setBlockStateId(new Vec3(x, y, z), WATER)
        } else {
          chunk.setBlockStateId(new Vec3(x, 63, z), GRASS)
          for (let y = 58; y < 63; y++) chunk.setBlockType(new Vec3(x, y, z), mcData.blocksByName.dirt.id)
        }
        for (let y = 0; y < 256; y++) {
          chunk.setBiome(new Vec3(x, y, z), PLAINS)
          if (y >= 64) chunk.setSkyLight(new Vec3(x, y, z), 15)
        }
      }
    }
    return chunk
  })
  const set = (x, y, z, s) => world.setBlockStateId(new Vec3(x, y, z), s)
  const rand = makeRand(spec.seed)
  const keepClear = (spec.keep_clear || []).slice()

  for (const s of spec.structures || []) {
    if (!STRUCTURES[s.type]) throw new Error(`Unknown structure "${s.type}". Known: ${Object.keys(STRUCTURES).join(', ')}`)
    keepClear.push(await STRUCTURES[s.type](set, s.at, s))
  }
  // fills: [x0, y0, z0, x1, y1, z1, block, {props}] boxes (use "air" to carve tunnels and rooms)
  for (const f of spec.fills || []) {
    const [x0, y0, z0, x1, y1, z1, name, props] = f
    const sid = st(name, props || {})
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
      for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
        for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) await set(x, y, z, sid)
      }
    }
  }
  for (const b of spec.blocks || []) await set(b[0], b[1], b[2], st(b[3], b[4] || {}))
  for (const p of spec.paths || []) keepClear.push(p) // [x0,z0,x1,z1] strips kept free of plants

  const trees = spec.trees ?? 60
  const fixedTrees = spec.tree_at || [] // [[x, z], ...] exact tree positions (islands)
  for (let n = 0; n < trees + fixedTrees.length; n++) {
    let x, z
    if (n < fixedTrees.length) {
      [x, z] = fixedTrees[n]
    } else {
      x = Math.floor(rand() * 60) - 30
      z = Math.floor(rand() * 60) - 40
      if (keepClear.some((r) => inRect(x, z, [r[0] - 3, r[1] - 3, r[2] + 3, r[3] + 3]))) continue
    }
    const h = 4 + Math.floor(rand() * 2)
    for (let y = 64; y < 64 + h; y++) await set(x, y, z, st('oak_log', { axis: 'y' }))
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let dy = h - 2; dy <= h; dy++) {
          if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue
          if (dy === h && (Math.abs(dx) > 1 || Math.abs(dz) > 1)) continue
          if (dx === 0 && dz === 0 && dy < h) continue
          await set(x + dx, 64 + dy, z + dz, st('oak_leaves', { persistent: true, distance: 1 }))
        }
      }
    }
  }
  const plants = spec.plants ?? 500
  for (let n = 0; n < plants; n++) {
    const x = Math.floor(rand() * 70) - 35
    const z = Math.floor(rand() * 70) - 45
    if (keepClear.some((r) => inRect(x, z, r))) continue
    const b = await world.getBlock(new Vec3(x, 64, z))
    if (b && b.name !== 'air') continue
    const below = await world.getBlock(new Vec3(x, 63, z))
    if (!below || below.name !== 'grass_block') continue // never on water or sand
    const r = rand()
    await set(x, 64, z, r < 0.8 ? st('grass') : r < 0.9 ? st('poppy') : st('dandelion'))
  }
  return world
}

module.exports = { VERSION, buildWorld, doorState, st }
