// Renders every shot of a resolved script to JPEG frames, plus sound cues for the SFX step.
// Usage: node engine/render.js <build/script.json> [--only=1,3] [--stills=0.1,0.5,0.9]
const fs = require('fs')
const path = require('path')
const express = require('express')
const { launchBrowser } = require('./browser')
const { VERSION, buildWorld, doorState } = require('./world')

const FPS = 30
let W = 1080
let H = 1920
const EYE = 1.62
const ROOT = path.join(__dirname, '..')

const SKIES = {
  dusk: { color: '#e9a47c', fog: [9, 32], ambient: 0.72, sun: 0.45 },
  day: { color: '#9cc9ff', fog: [30, 70], ambient: 0.85, sun: 0.55 },
  night: { color: '#0d1630', fog: [6, 26], ambient: 0.32, sun: 0.12 },
  foggy: { color: '#b9c2c9', fog: [4, 20], ambient: 0.7, sun: 0.3 },
  sunset: { color: '#f2a46b', fog: [30, 80], ambient: 0.78, ambientColor: '#ffd9b0', sun: 0.5 },
  interior_night: { color: '#0d1630', fog: [6, 30], ambient: 0.55, ambientColor: '#ffc98a', sun: 0.08 },
  cave_red: { color: '#050203', fog: [1.5, 11], ambient: 0.55, ambientColor: '#ff3b2e', sun: 0.0 },
  dark: { color: '#000000', fog: [2, 12], ambient: 0.28, ambientColor: '#9aa3b5', sun: 0.0 },
  cave_dark: { color: '#05070a', fog: [2, 14], ambient: 0.45, ambientColor: '#8ea2c8', sun: 0.0 },
  cave_torch: { color: '#07060a', fog: [3, 16], ambient: 0.55, ambientColor: '#ffb35c', sun: 0.0 },
  glitch: { color: '#5e5e66', fog: [10, 40], ambient: 0.7, ambientColor: '#c9c3d6', sun: 0.25 },
  void: { color: '#000000', fog: [3, 18], ambient: 0.85, ambientColor: '#b066ff', sun: 0.0 }
}

// ---------- math ----------
const clamp01 = (t) => Math.max(0, Math.min(1, t))
const smooth = (t) => { t = clamp01(t); return t * t * (3 - 2 * t) }
const lerp = (a, b, t) => a + (b - a) * t
const rad = (d) => (d * Math.PI) / 180
const compassToYaw = (deg) => -rad(deg) // compass: 0 north, 90 east, 180 south, 270 west

function lookAngles (from, to) {
  const dx = to[0] - from[0]
  const dy = to[1] - from[1]
  const dz = to[2] - from[2]
  return { yaw: Math.atan2(-dx, -dz), pitch: Math.atan2(dy, Math.hypot(dx, dz)) }
}

// Interpolate a list of keys [{t, ...values}] at time t; fields = numeric arrays or numbers.
function sampleKeys (keys, t, ease) {
  if (t <= keys[0].t) return keys[0]
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i]
    const b = keys[i + 1]
    if (t <= b.t) {
      const e = b.ease || ease
      const u = e === 'linear' ? clamp01((t - a.t) / (b.t - a.t)) : smooth((t - a.t) / (b.t - a.t))
      const out = { t }
      for (const k of Object.keys(a)) {
        if (k === 't') continue
        if (Array.isArray(a[k])) out[k] = a[k].map((v, j) => lerp(v, b[k] ? b[k][j] : v, u))
        else if (typeof a[k] === 'number') out[k] = lerp(a[k], b[k] ?? a[k], u)
        else if (k !== 'ease') out[k] = u < 0.5 ? a[k] : b[k] ?? a[k]
      }
      return out
    }
  }
  return keys[keys.length - 1]
}

const eyePos = (p, floor = 64) => (p.length === 2 ? [p[0], floor + EYE, p[1]] : p)

// Normalise camera keys: resolve look targets into yaw/pitch (radians), unwrap yaw so turns take the short way
// unless the script says otherwise.
function cameraKeys (cam) {
  let prevYaw = null
  return cam.keys.map((k) => {
    const pos = eyePos(k.pos, k.floor ?? cam.floor ?? 64)
    let yaw, pitch
    if (k.look) {
      const a = lookAngles(pos, eyePos(k.look, k.floor ?? cam.floor ?? 64))
      yaw = a.yaw
      pitch = a.pitch
    } else {
      yaw = compassToYaw(k.yaw ?? 0)
      pitch = rad(k.pitch ?? 0)
    }
    if (prevYaw !== null && !k.spin) {
      while (yaw - prevYaw > Math.PI) yaw -= 2 * Math.PI
      while (yaw - prevYaw < -Math.PI) yaw += 2 * Math.PI
    }
    prevYaw = yaw
    return { t: k.t, pos, yaw, pitch, fov: k.fov ?? cam.fov ?? 70, ease: k.ease }
  })
}

function retentionCam (shot, script, t, c) {
  const cam = shot.camera || {}
  const sway = cam.shake ?? script.camera_shake ?? 0.25 // 0 = locked-off tripod
  const seed = (shot.id || 1) * 1.7
  let yaw = c.yaw + sway * 0.03 * (Math.sin(t * 1.3 + seed) + 0.5 * Math.sin(t * 2.9 + seed * 2))
  let pitch = c.pitch + sway * 0.02 * (Math.sin(t * 1.1 + seed * 3) + 0.5 * Math.sin(t * 3.7 + seed))
  const stings = cam.auto_scare === false ? [] : (shot.sfx || []).filter((s) => s.type === 'sting').map((s) => [s.t, s.level ?? 0.8])
  for (const [t0, amt] of [...(cam.jolt || []), ...stings]) {
    const u = t - t0
    if (u >= 0 && u < 0.45) {
      const k = (1 - u / 0.45) * amt
      yaw += 0.05 * k * Math.sin(u * 70)
      pitch += 0.035 * k * Math.sin(u * 53 + 1)
    }
  }
  let zoom = 1
  for (const [t0, amt] of [...(cam.punch || []), ...stings.map(([s, l]) => [s, 0.12 * l])]) {
    const u = (t - t0) / 0.12
    if (u > 0) zoom *= 1 - amt * Math.min(1, u * u * (3 - 2 * Math.min(1, u)))
  }
  return { yaw, pitch, fov: c.fov * zoom }
}

// Pre-compute every frame of a shot: camera, actors, gui, events, and sound cues.
function planShot (shot, script) {
  const frames = Math.round(shot.duration * FPS)
  const cam = cameraKeys(shot.camera)
  const out = []
  const cues = []
  let camDist = 0
  let prevCam = null
  const actorState = {}
  for (let f = 0; f < frames; f++) {
    const t = f / FPS
    const c = sampleKeys(cam, t, shot.camera.ease)
    const pos = c.pos.slice()
    if (prevCam) {
      const d = Math.hypot(pos[0] - prevCam[0], pos[2] - prevCam[2])
      const before = Math.floor(camDist / 0.9)
      camDist += d
      if (Math.floor(camDist / 0.9) > before) cues.push({ t, type: 'step', level: 0.55 })
    }
    prevCam = pos.slice()
    // Head bob follows distance walked, so it only happens while the camera moves.
    pos[1] += Math.abs(Math.sin((camDist / 0.9) * Math.PI)) * (shot.camera.bob ?? 0.06)
    // Retention editing: handheld sway (so no shot is a frozen still), a violent jolt and a fast
    // punch-in zoom on every scare. Jolts/punches come from camera.jolt / camera.punch [[t, amount]]
    // and, unless camera.auto_scare is false, from every "sting" sound cue in the shot.
    const { yaw, pitch, fov } = retentionCam(shot, script, t, c)
    const frame = { t, cam: [pos[0], pos[1], pos[2], yaw, pitch, fov], actors: {} }

    for (const [name, a] of Object.entries(shot.actors || {})) {
      const sc = (v) => (Array.isArray(v) ? v : [v, v, v])
      let lastScale = sc(a.scale ?? 1)
      const keys = a.keys.map((k) => {
        if (k.scale !== undefined) lastScale = sc(k.scale)
        return { t: k.t, at: k.at, y: k.y ?? a.y ?? 64, scale: lastScale, face: typeof k.face === 'number' ? compassToYaw(k.face) : undefined }
      })
      const s = sampleKeys(keys, t, a.ease || 'linear')
      const prev = sampleKeys(keys, Math.max(0, t - 1 / FPS), a.ease || 'linear')
      const st = actorState[name] || (actorState[name] = { phase: 0, dist: 0 })
      const speed = Math.hypot(s.at[0] - prev.at[0], s.at[1] - prev.at[1]) * FPS
      const before = Math.floor(st.dist / 0.9)
      st.dist += speed / FPS
      if (Math.floor(st.dist / 0.9) > before) cues.push({ t, type: 'step', level: a.step_level ?? 0.3 })
      st.phase += (speed / FPS) * 2.2
      let yaw = s.face
      if (a.face === 'camera') yaw = Math.atan2(-(pos[0] - s.at[0]), -(pos[2] - s.at[1]))
      else if (yaw === undefined && speed > 0.2) yaw = Math.atan2(-(s.at[0] - prev.at[0]), -(s.at[1] - prev.at[1]))
      if (yaw === undefined) yaw = st.lastYaw ?? 0
      st.lastYaw = yaw
      const arm = a.arm ? sampleKeys(a.arm.map(([kt, v]) => ({ t: kt, v })), t).v : 0
      const head = a.head ? sampleKeys(a.head.map(([kt, hy, hp, hr]) => ({ t: kt, v: [hy, hp, hr || 0] })), t).v : [0, 0, 0]
      // float: hover amplitude in blocks (a gentle bob, like something that isn't touching the ground)
      const base = (script.actors || {})[name] || {}
      const float = a.float ?? base.float
      const hover = float ? float * (1 + Math.sin(t * 2.1 + name.length)) / 2 : 0
      frame.actors[name] = {
        x: s.at[0], y: s.y + hover, z: s.at[1], yaw, scale: s.scale, headRoll: rad(head[2] || 0), still: !!(a.still ?? base.still),
        walk: st.phase, walkAmp: Math.min(0.9, speed * 0.22),
        armRaise: rad(arm), headYaw: rad(head[0]), headPitch: rad(head[1])
      }
    }
    if (shot.gui) {
      const g = shot.gui
      const [s0, s1] = g.scale || [4.9, 4.9]
      const z = lerp(s0, s1, 1 - Math.pow(1 - clamp01(t / (g.zoom ?? 0.45)), 3)) + (g.drift ?? 0.03) * t
      frame.gui = { scale: z, highlight: Array.isArray(g.highlight) ? (g.highlight.filter(([ht]) => t >= ht).pop() || [0, null])[1] : t >= (g.highlight_at ?? 0) ? g.highlight : null, title: g.title || (g.type === 'trade' ? 'Villager' : 'Chest'), top: g.top ?? 250 }
    }
    const key1 = (list, def) => (list ? sampleKeys(list.map(([kt, v]) => ({ t: kt, v })), t, 'linear').v : def)
    const fx = shot.fx || {}
    frame.fx = { black: key1(fx.fade, 0), vignette: key1(typeof fx.vignette === 'number' ? [[0, fx.vignette]] : fx.vignette, 0), vignetteColor: fx.vignette_color, glitch: key1(fx.glitch, 0), seed: f + 1,
      checker: key1(typeof fx.checker === 'number' ? [[0, fx.checker]] : fx.checker, 0),
      grid: key1(typeof fx.grid === 'number' ? [[0, fx.grid]] : fx.grid, 0),
      static: key1(typeof fx.static === 'number' ? [[0, fx.static]] : fx.static, 0),
      // Myth-test overlays: counter (spins between keys), a title banner, and a REAL/BUSTED stamp.
      counter: fx.counter ? `#${Math.round(key1(fx.counter, 0))} / ${fx.counter_total || (script.counter_total ?? 100)}` : null,
      // 100-days format: big DAY counter (top-right) and a Minecraft HUD (hotbar, hardcore hearts, hunger).
      day: fx.day ? Math.round(key1(typeof fx.day === 'number' ? [[0, fx.day]] : fx.day, 0)) : null,
      hud: fx.hud ? { ...fx.hud, hearts: key1(typeof fx.hud.hearts === 'number' || fx.hud.hearts === undefined ? [[0, fx.hud.hearts ?? 10]] : fx.hud.hearts, 10) } : null,
      book: fx.book ? (fx.book.filter(([bt]) => t >= bt).pop() || [0, null])[1] : null,
      label: fx.label ? (fx.label.filter(([lt]) => t >= lt).pop() || [0, null])[1] : null,
      stamp: fx.stamp ? (() => { const st = fx.stamp.filter(([sti]) => t >= sti).pop(); return st && st[1] ? { text: st[1], age: t - st[0] } : null })() : null,
      chat: fx.chat ? fx.chat.filter(([ct]) => t >= ct).map(([, text]) => text).slice(-6) : null,
      desktop: fx.desktop ? { p: key1(fx.desktop.keys, 0), text: fx.desktop.text, file: fx.desktop.file } : null,
      // Kids pack: bouncy reaction text pops [[t, text, color]], colour flashes [[t, color]], speed lines 0..1, colour grade.
      pops: (fx.pop || []).map(([pt, text, color], i) => ({ text, color, i, age: t - pt })).filter((p) => p.age >= 0 && p.age < 1.5),
      flash: (() => { const fl = (fx.flash || []).filter(([ft]) => t >= ft && t - ft < 0.35).pop(); return fl ? { color: fl[1] || '#fff', a: 1 - (t - fl[0]) / 0.35 } : null })(),
      speed: key1(typeof fx.speed === 'number' ? [[0, fx.speed]] : fx.speed, 0),
      grade: fx.grade ?? script.grade ?? null,
      // F3-style coordinates readout: coords [[t, x]] (interpolated), coords_yz [y, z]; coords_glitch 0..1 scrambles digits.
      coords: fx.coords ? { x: key1(typeof fx.coords === 'number' ? [[0, fx.coords]] : fx.coords, 0), yz: fx.coords_yz || [70, 4], g: key1(typeof fx.coords_glitch === 'number' ? [[0, fx.coords_glitch]] : fx.coords_glitch, 0) } : null }
    // Flicker: deterministic random dips in the light (torches failing, redstone pulsing).
    const fl = key1(typeof fx.flicker === 'number' ? [[0, fx.flicker]] : fx.flicker, 0)
    frame.lightMul = fl ? 1 - fl * (Math.sin(f * 12.9898) * 43758.5453 % 1 + 1) % 1 : 1
    if (shot.hand) {
      const swings = shot.hand.swings || []
      const len = shot.hand.swing_len || 0.3
      const sw = swings.map((st) => (t >= st && t < st + len ? (t - st) / len : 0)).find((v) => v > 0) || 0
      frame.hand = { item: shot.hand.item.includes('/') ? shot.hand.item : 'items/' + shot.hand.item, swing: sw, bob: Math.abs(Math.sin((camDist / 0.9) * Math.PI)) * 18 }
    }
    if (shot.leash) {
      const l = shot.leash
      const until = l.until ?? 1e9
      const a = frame.actors[l.to]
      const h = l.from && l.from !== 'camera' ? frame.actors[l.from] : null
      if (a && t < until) {
        let from
        if (h) {
          from = [h.x - Math.sin(h.yaw) * 0.3 + Math.cos(h.yaw) * 0.35, h.y + 0.95, h.z - Math.cos(h.yaw) * 0.3 - Math.sin(h.yaw) * 0.35]
        } else {
          const fwd = [-Math.sin(c.yaw), -Math.cos(c.yaw)]
          const right = [Math.cos(c.yaw), -Math.sin(c.yaw)]
          from = [pos[0] + fwd[0] * 0.6 + right[0] * 0.35, pos[1] - 0.45, pos[2] + fwd[1] * 0.6 + right[1] * 0.35]
        }
        frame.leash = { from, to: [a.x, a.y + 1.1 * (a.scale ? a.scale[1] : 1), a.z] }
      }
    }
    out.push(frame)
  }
  for (const e of shot.events || []) {
    if (e.door && e.sound !== false) cues.push({ t: e.t, type: 'clack', level: 1.0, pitch: 1.0 })
    if (e.show && e.sound !== false) cues.push({ t: e.t, type: 'clack', level: 0.8, pitch: 1.4 })
    if (e.break) cues.push({ t: e.t, type: 'break', level: 1.0 })
    if (typeof e.sound === 'string') cues.push({ t: e.t, type: e.sound, level: e.level ?? 1.0 })
  }
  for (const [stt, stv] of (shot.fx && shot.fx.stamp) || []) if (stv) cues.push({ t: stt, type: stv === 'REAL' ? 'sting' : 'thud', level: stv === 'REAL' ? 0.5 : 0.8, dur: 0.6 })
  for (const [bt] of (shot.fx && shot.fx.book) || []) cues.push({ t: bt, type: 'clack', level: 0.5, pitch: 1.6 })
  for (const [ct] of (shot.fx && shot.fx.chat) || []) cues.push({ t: ct, type: 'tick', level: 0.6 })
  for (const [pt] of (shot.fx && shot.fx.pop) || []) cues.push({ t: pt, type: 'pop', level: 0.7 })
  for (const c of shot.sfx || []) cues.push({ t: c.t, type: c.type, level: c.level ?? 1.0, dur: c.dur })
  if (shot.hand) for (const st of shot.hand.swings || []) cues.push({ t: st, type: 'swing', level: 0.5 })
  if (shot.gui && shot.gui.sound !== false) cues.push({ t: 0, type: 'clack', level: 0.9, pitch: 0.8 })
  return { frames: out, cues }
}

async function main () {
  const scriptPath = process.argv[2]
  const opt = Object.fromEntries(process.argv.slice(3).map((a) => a.replace(/^--/, '').split('=')))
  const script = JSON.parse(fs.readFileSync(scriptPath, 'utf8'))
  if (script.format === 'landscape') { W = 1920; H = 1080 }
  // --scale=0.667 renders at 720p (2.25x fewer pixels, ~2x faster on CPU); assembly upscales back to full size.
  const SCALE = Number(opt.scale || process.env.RENDER_SCALE || 1)
  W = Math.round(W * SCALE / 2) * 2; H = Math.round(H * SCALE / 2) * 2
  const buildDir = path.dirname(scriptPath)
  const only = opt.only ? opt.only.split(',').map(Number) : null
  const stills = opt.stills ? opt.stills.split(',').map(Number) : null

  const world = await buildWorld(script.world || {})
  const app = express()
  const http = require('http').createServer(app)
  const io = require('socket.io')(http)
  // Custom skins (glitch, missing…) are served next to the stock entity textures.
  app.use('/textures/' + VERSION + '/entity', express.static(path.join(ROOT, 'assets', 'skins')))
  require('prismarine-viewer/lib/common').setupRoutes(app, '')
  app.use('/', express.static(path.join(ROOT, 'studio', 'dist')))
  const area = (script.world && script.world.area) || [-3, -4, 2, 1]
  const chunkCount = (area[2] - area[0] + 1) * (area[3] - area[1] + 1)
  io.on('connection', async (socket) => {
    socket.emit('version', VERSION)
    for (let cx = area[0]; cx <= area[2]; cx++) {
      for (let cz = area[1]; cz <= area[3]; cz++) {
        socket.emit('loadChunk', { x: cx * 16, z: cz * 16, chunk: (await world.getColumn(cx, cz)).toJson() })
      }
    }
  })
  await new Promise((resolve) => http.listen(0, resolve))
  const port = http.address().port

  const browser = await launchBrowser()
  const page = await browser.newPage({ viewport: { width: W, height: H } })
  page.on('pageerror', (e) => console.log('pageerror:', e.message))
  await page.goto(`http://localhost:${port}/studio.html`)
  await page.waitForFunction((n) => window.studio && window.studio.chunks() >= n, chunkCount, { timeout: 120000 })
  const lightOf = (l) => {
    const base = SKIES[(script.world && script.world.time) || 'dusk']
    if (!l) return base
    if (typeof l === 'string') return SKIES[l] || base
    return { ...(SKIES[l.preset] || base), ...l }
  }
  const baseLight = lightOf(null)
  await page.evaluate(async (l) => {
    window.studio.setLight({ ...l, sky: l.color })
    await window.studio.waitRender()
  }, baseLight)

  // Actors and props.
  await page.evaluate(({ actors, props }) => {
    const s = window.studio
    for (const [name, a] of Object.entries(actors || {})) {
      s.addPlayer(name, { model: a.model, skin: a.skin, shade: a.shade, glow: a.glow })
      if (a.holds) s.holdItem(name, a.holds)
    }
    window.__props = props || {}
    for (const [name, p] of Object.entries(props || {})) {
      if (p.type === 'items') p.points.forEach((pt, i) => s.addItem(name + i, p.item, !!p.block))
      if (p.type === 'sign') s.addSign(name, p.at[0], p.y ?? 64, p.at[1], Math.PI - (p.face || 0) * Math.PI / 180, p.lines)
      if (p.type === 'bed') s.addBed(name, p.at[0], p.y ?? 64, p.at[1], p.face || 0, p.color || 'red')
      if (p.type === 'chest') s.addChest(name, p.at[0], p.y ?? 64, p.at[1], p.face || 180)
      if (p.type === 'cubes') s.addCubes(name, p.points, p.style || 'missing', p.size || 1)
    }
  }, { actors: script.actors, props: script.props })
  await page.waitForTimeout(2500)

  // Persistent state across shots: door states and prop visibility.
  const doors = {}
  const visible = {}
  for (const [name, p] of Object.entries(script.props || {})) visible[name] = !p.hidden
  const cuesAll = {}

  for (const shot of script.shots) {
    const plan = planShot(shot, script)
    cuesAll[shot.id] = { duration: shot.duration, cues: plan.cues, ambience: shot.ambience || null }
    // Apply events that happen before this shot if we skip shots (keep state consistent).
    const events = (shot.events || []).slice().sort((a, b) => a.t - b.t)
    if (only && !only.includes(shot.id)) {
      for (const e of events) applyState(e)
      continue
    }
    const dir = path.join(buildDir, 'frames', 'shot' + shot.id)
    fs.rmSync(dir, { recursive: true, force: true })
    fs.mkdirSync(dir, { recursive: true })
    const idx = stills ? stills.map((p) => Math.min(plan.frames.length - 1, Math.round(p * plan.frames.length))) : plan.frames.map((_, i) => i)
    let ei = 0
    const t0 = Date.now()
    const shotLight = lightOf(shot.light)
    await page.evaluate((l) => window.studio.setLight({ ...l, sky: l.color }), shotLight)
    if (shot.gui) await page.evaluate((g) => { window.__guiItems = g.items || []; window.__guiInv = g.inventory; window.__guiOffers = g.type === 'trade' ? (g.offers || []) : null }, shot.gui)
    for (const i of idx) {
      const fr = plan.frames[i]
      let changed = false
      while (ei < events.length && events[ei].t <= fr.t) {
        const e = events[ei++]
        if (e.door) {
          const key = e.door.join(',')
          if (doors[key] !== !!e.open) {
            doors[key] = !!e.open
            for (const half of ['lower', 'upper']) {
              io.emit('blockUpdate', { pos: { x: e.door[0], y: half === 'lower' ? 64 : 65, z: e.door[1] }, stateId: doorState(half, !!e.open) })
            }
            changed = true
          }
        }
        if (e.show) visible[e.show] = true
        if (e.hide) visible[e.hide] = false
        if (e.set || e.break) { applyBlocks(e); changed = true }
      }
      if (changed) {
        await page.waitForTimeout(400)
        await page.evaluate(() => window.studio.waitRender())
      }
      await page.evaluate(({ fr, visible, light }) => {
        const s = window.studio
        if (fr.lightMul !== 1) s.setLight({ ...light, sky: light.color, ambient: light.ambient * fr.lightMul, sun: light.sun * fr.lightMul })
        else if (window.__flickered) s.setLight({ ...light, sky: light.color })
        window.__flickered = fr.lightMul !== 1
        s.setFx(fr.fx)
        s.setHand(fr.hand ? fr.hand.item : null, fr.hand ? fr.hand.swing : 0, fr.hand ? fr.hand.bob : 0)
        s.setLeash(fr.leash || null)
        const [x, y, z, yaw, pitch, fov] = fr.cam
        s.setCamera(x, y, z, yaw, pitch, fov)
        for (const name of Object.keys(s.players())) {
          s.setPlayer(name, fr.actors[name] ? fr.actors[name] : { x: 0, y: -100, z: 0, visible: false })
        }
        for (const [name, p] of Object.entries(window.__props)) {
          if (p.type === 'items') p.points.forEach((pt, i) => s.setItem(name + i, pt[0], p.y ?? 64, pt[1], fr.t + i, visible[name]))
          else s.showProp(name, visible[name])
        }
        if (fr.gui) {
          s.overlayStyle(`align-items:flex-start;padding-top:${fr.gui.top}px;box-sizing:border-box;background:radial-gradient(rgba(16,16,16,.55),rgba(16,16,16,.8))`)
          s.overlayHTML(window.__guiOffers ? window.buildTradeGUI(fr.gui.scale, window.__guiOffers, fr.gui.highlight, fr.gui.title) : window.buildContainerGUI(fr.gui.scale, window.__guiItems, fr.gui.highlight, fr.gui.title, window.__guiInv))
        } else {
          s.overlayStyle('')
          s.overlayHTML('')
        }
        s.render()
      }, { fr, visible, light: shotLight })
      if (i === idx[0] && fr.gui) {
        // First GUI frame: give item icons time to load, then redraw.
        await page.evaluate(() => new Promise((resolve) => setTimeout(resolve, 600)))
        await page.evaluate((fr) => { window.studio.overlayHTML(window.__guiOffers ? window.buildTradeGUI(fr.gui.scale, window.__guiOffers, fr.gui.highlight, fr.gui.title) : window.buildContainerGUI(fr.gui.scale, window.__guiItems, fr.gui.highlight, fr.gui.title, window.__guiInv)); window.studio.render() }, fr)
      }
      await page.screenshot({ path: path.join(dir, String(idx.indexOf(i)).padStart(4, '0') + '.jpg'), type: 'jpeg', quality: 92 })
    }
    console.log(`shot ${shot.id}: ${idx.length} frames in ${((Date.now() - t0) / 1000).toFixed(0)}s`)
    for (; ei < events.length; ei++) applyState(events[ei])
  }

  function applyBlocks (e) {
    const { st } = require('./world')
    for (const b of e.set || []) io.emit('blockUpdate', { pos: { x: b[0], y: b[1], z: b[2] }, stateId: st(b[3], b[4] || {}) })
    for (const b of e.break || []) io.emit('blockUpdate', { pos: { x: b[0], y: b[1], z: b[2] }, stateId: st('air') })
  }

  function applyState (e) {
    if (e.set || e.break) applyBlocks(e)
    if (e.show) visible[e.show] = true
    if (e.hide) visible[e.hide] = false
    if (e.door) {
      const key = e.door.join(',')
      if (doors[key] !== !!e.open) {
        doors[key] = !!e.open
        for (const half of ['lower', 'upper']) {
          io.emit('blockUpdate', { pos: { x: e.door[0], y: half === 'lower' ? 64 : 65, z: e.door[1] }, stateId: doorState(half, !!e.open) })
        }
      }
    }
  }

  fs.writeFileSync(path.join(buildDir, 'cues.json'), JSON.stringify(cuesAll, null, 2))
  await browser.close()
  process.exit(0)
}

main().catch((e) => { console.error(e); process.exit(1) })
