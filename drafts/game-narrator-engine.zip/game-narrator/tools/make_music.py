"""Copyright-free background music built from moods, one section per run of shots with the same mood.

Moods: mystery, tension, horror, silence, none, awkward, chase, calm, cozy, happy,
music_box (creepy lullaby, beat-synced: 90 bpm, one bar = 2.667 s), home (warm piano), home_stutter (record skips, then cuts out), warped (pitched down, wobbling), void (distortion wall).
Usage: python make_music.py <build_dir>   (reads shots.json, writes music.wav)
"""
import json
import pathlib
import sys
import wave

import numpy as np

SR = 44100
rng = np.random.default_rng(3)


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def pad(n, chords, chord_len, level=0.12):
    t = np.arange(n) / SR
    out = np.zeros((n, 2))
    for k, start in enumerate(np.arange(0, n / SR, chord_len)):
        e = np.clip((t - start + 0.8) / 1.2, 0, 1) * np.clip((start + chord_len + 0.8 - t) / 1.2, 0, 1)
        for m in chords[k % len(chords)]:
            for ch, det in ((0, -0.2), (1, 0.2)):
                out[:, ch] += level * e * np.sin(2 * np.pi * (hz(m) + det) * t)
    return out


def hits(n, times, make):
    out = np.zeros((n, 2))
    for s in times:
        i0 = int(s * SR)
        snd = make()
        j = min(n, i0 + len(snd))
        if i0 < n:
            out[i0:j] += snd[: j - i0]
    return out


def heartbeat():
    tt = np.arange(int(0.45 * SR)) / SR
    a = np.sin(2 * np.pi * 55 * tt) * np.exp(-tt * 18)
    b = np.zeros_like(a)
    d = int(0.18 * SR)
    b[d:] = 0.6 * a[:-d]
    return 0.35 * np.stack([a + b, a + b], axis=1)


def pluck(m, dur=0.3, level=0.22, square=True, pan=0.5):
    tt = np.arange(int(dur * SR)) / SR
    wave_ = np.sign(np.sin(2 * np.pi * hz(m) * tt)) if square else np.sin(2 * np.pi * hz(m) * tt)
    s = level * wave_ * np.exp(-tt * 14)
    return np.stack([s * (1 - pan), s * pan], axis=1)


def kick():
    tt = np.arange(int(0.3 * SR)) / SR
    s = 0.5 * np.sin(2 * np.pi * (60 + 90 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 12)
    return np.stack([s, s], axis=1)


def piano(m, dur=2.4, level=0.16, pan=0.5):
    tt = np.arange(int(dur * SR)) / SR
    f = hz(m)
    s = sum(a * np.sin(2 * np.pi * f * k * tt) * np.exp(-tt * (2.2 + 1.8 * k)) for k, a in ((1, 1.0), (2, 0.35), (3, 0.12), (4, 0.05)))
    s = level * s * np.minimum(1, tt / 0.006)
    return np.stack([s * (1.2 - pan), s * (0.2 + pan)], axis=1) / 1.4


def home(n, dur):
    """Warm, slow, nostalgic piano over a soft pad (original; 72 bpm, D major)."""
    beat = 60 / 72
    prog = [[50, 57, 62, 66], [47, 54, 59, 62], [43, 50, 55, 59], [45, 52, 57, 61]]  # D, Bm, G, A
    out = pad(n, prog, beat * 4, 0.05)
    mel = [74, 78, 76, 73, 71, 74, 78, 81, 79, 78, 74, 76, 73, 76, 69, 71]
    for k, b in enumerate(np.arange(0.2, dur, beat)):
        bar = int(b / (beat * 4)) % 4
        root = prog[bar][0] - 12
        if k % 4 == 0:
            out += hits(n, [b], lambda r=root: piano(r, 3.0, 0.2, 0.4))
        out += hits(n, [b], lambda c=prog[bar][1 + k % 3]: piano(c, 1.6, 0.07, 0.6))
        if k % 2 == 0:
            out += hits(n, [b + 0.02], lambda m=mel[(k // 2) % len(mel)]: piano(m, 2.4, 0.14, 0.5))
    return out


def stutter(a, amount, seed=5):
    """Record-skip glitches: short slices repeat, like a scratched disc. amount 0..1 grows over time."""
    r = np.random.default_rng(seed)
    out = a.copy()
    n = len(a)
    i = int(SR * 1.5)
    while i < n - SR:
        prog = i / n
        if r.random() < amount * (0.3 + prog):
            sl = int(SR * r.uniform(0.06, 0.18))
            reps = int(r.integers(2, 6))
            seg = a[i:i + sl]
            for k in range(reps):
                j = i + k * sl
                if j + sl < n:
                    out[j:j + sl] = seg
            i += sl * reps
            if r.random() < 0.3:  # dropout
                g = int(SR * r.uniform(0.08, 0.3))
                out[i:i + g] *= 0.0
                i += g
        i += int(SR * r.uniform(0.6, 1.6))
    return out


def warp(a, depth=0.12, drop=0.82):
    """Pitch the track down and add tape wow, then crush the bits."""
    n = len(a)
    t = np.arange(n) / SR
    pos = np.cumsum(drop * (1 + depth * np.sin(2 * np.pi * 0.35 * t) + 0.04 * np.sin(2 * np.pi * 3.1 * t)))
    pos = np.clip(pos, 0, n - 1)
    out = np.stack([np.interp(pos, np.arange(n), a[:, c]) for c in (0, 1)], axis=1)
    out = np.round(out * 24) / 24
    return out


def void_noise(n):
    """Purple-noise distortion wall with a detuned low drone."""
    t = np.arange(n) / SR
    white = rng.standard_normal(n)
    purple = np.diff(np.concatenate([[0], white]))  # rising spectrum
    drone = sum(np.sin(2 * np.pi * f * t) for f in (41.2, 43.7, 61.7, 87.3))
    s = 0.25 * purple + 0.35 * np.tanh(2.5 * drone) + 0.1 * np.sign(np.sin(2 * np.pi * 7 * t)) * white
    return np.stack([s, np.roll(s, 97)], axis=1)


def box_note(m, dur=1.6, level=0.2, detune=0.0):
    """Music box tine: bright sine with an inharmonic partial, quick decay, slight detune."""
    tt = np.arange(int(dur * SR)) / SR
    f = hz(m) * (2 ** (detune / 1200))
    s = np.sin(2 * np.pi * f * tt) * np.exp(-tt * 3.2) + 0.35 * np.sin(2 * np.pi * f * 5.4 * tt) * np.exp(-tt * 9) + 0.2 * np.sin(2 * np.pi * f * 2 * tt) * np.exp(-tt * 5)
    s = level * s * np.minimum(1, tt / 0.002)
    return np.stack([s, s], axis=1)


def music_box(n, dur):
    """Original creepy music-box lullaby (A minor, 90 bpm, 2 bars per 2.667 s).
    Bars 1-4 alone, slowly going out of tune; bars 5+ add a low drone and heartbeat kick;
    the last bar winds down like a music box running out."""
    beat = 60 / 90
    step = beat / 2
    phrase = [76, 72, 69, 72, 76, 72, 69, 72,
              77, 74, 69, 74, 77, 74, 69, 74,
              76, 72, 69, 72, 74, 71, 68, 71,
              72, 71, 69, 68, 69, None, None, None]
    bass = [45, 50, 45, 40]
    out = np.zeros((n, 2))
    k = 0
    for b in np.arange(0, dur, step):
        m = phrase[k % len(phrase)]
        if m is not None:
            drift = 25 * (b / dur) ** 1.5 * np.sin(k * 1.7)  # grows more out of tune
            out += hits(n, [b], lambda m=m, d=drift: box_note(m, 1.6, 0.2, d))
        if k % 8 == 0:
            out += hits(n, [b], lambda bm=bass[(k // 8) % 4]: box_note(bm, 2.6, 0.16))
        k += 1
    drop = beat * 16  # after 4 bars
    t = np.arange(n) / SR
    drone = (0.07 * (np.sin(2 * np.pi * hz(33) * t) + 0.6 * np.sin(2 * np.pi * hz(33.3) * t)) * (t > drop))[:, None]
    out += drone * np.clip((t - drop) / 0.2, 0, 1)[:, None]
    out += hits(n, [b for b in np.arange(drop, dur - beat * 4, beat)], heartbeat) * 0.8
    # Reverb: a few feedback echoes.
    wet = out.copy()
    for d, g in ((0.043, 0.35), (0.087, 0.25), (0.19, 0.18), (0.31, 0.12)):
        i = int(d * SR)
        wet[i:] += g * out[:-i]
    out = wet
    # Wind-down: the last 4 beats slow down and drop in pitch.
    w0 = max(0, dur - beat * 4)
    i0 = int(w0 * SR)
    seg = out[i0:]
    m = len(seg)
    if m > 10:
        speed = np.linspace(1.0, 0.35, m)
        pos = np.clip(np.cumsum(speed), 0, m - 1)
        out[i0:] = np.stack([np.interp(pos, np.arange(m), seg[:, c]) for c in (0, 1)], axis=1) * np.linspace(1, 0.2, m)[:, None]
    return out


def mood_audio(mood, dur):
    n = int(dur * SR)
    t = np.arange(n) / SR
    if mood == "music_box":
        return music_box(n, dur)
    if mood == "home":
        return home(n, dur)
    if mood == "home_stutter":
        a = stutter(home(n, dur), 0.35)
        cut = int(max(0, dur - 1.6) * SR)  # the disc cuts out near the end of the section
        a[cut:] *= 0.0
        return a
    if mood == "warped":
        a = warp(stutter(home(n, dur), 0.5, 9))
        return a + 0.35 * np.abs(a).max() * void_noise(n) * np.clip(t / dur, 0, 1)[:, None] * 0.25
    if mood == "void":
        return void_noise(n)
    if mood == "mystery":
        out = pad(n, [[45, 52, 57, 60], [41, 48, 53, 57], [38, 50, 53, 57], [40, 52, 56, 59]], 5.25)
        beats, b = [], 0.8
        while b < dur - 0.4:
            beats.append(b)
            b += max(0.7, 1.1 - 0.35 * (b / max(dur, 1)))
        out += hits(n, beats, heartbeat)
        return out * (0.6 + 0.4 * np.clip(t / dur, 0, 1))[:, None]
    if mood == "tension":
        out = pad(n, [[40, 47, 52, 53]], dur + 1, 0.1)
        out += (0.08 * np.sin(2 * np.pi * hz(28) * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.5 * t)))[:, None]
        return out
    if mood == "none":
        return np.zeros((n, 2))
    if mood == "horror":
        # Dissonant low cluster, slow swells, a distant high screech now and then, and a heartbeat.
        out = pad(n, [[36, 37, 43, 48], [35, 36, 42, 47]], 6, 0.1)
        swell = (0.5 + 0.5 * np.sin(2 * np.pi * t / 7.0 - np.pi / 2))[:, None]
        out *= 0.6 + 0.6 * swell
        for s in np.arange(4.0, dur - 2, 9.0):
            m = int(3.0 * SR)
            i = int(s * SR)
            if i + m < n:
                tt = np.arange(m) / SR
                scr = 0.05 * np.sin(2 * np.pi * (1200 + 30 * np.sin(2 * np.pi * 5 * tt)) * tt) * np.sin(np.pi * tt / 3.0)
                out[i:i + m] += np.stack([scr, scr * 0.7], axis=1)
        beats = list(np.arange(1.0, dur - 0.5, 1.2))
        return out + hits(n, beats, heartbeat) * 0.7
    if mood == "cozy":
        mood = "calm"
    if mood == "silence":
        return (0.05 * np.clip(t / 1, 0, 1) * np.clip((dur - t) / 1.5, 0, 1) * np.sin(2 * np.pi * hz(33) * t))[:, None] * np.ones((1, 2))
    if mood == "awkward":
        times = [1.5 + i * 0.9 for i in range(3) if 1.5 + i * 0.9 < dur - 0.5]
        out = np.zeros((n, 2))
        for s, m in zip(times, [67, 64, 60]):
            out += hits(n, [s], lambda m=m: pluck(m, 0.8, 0.18, square=False))
        return out
    if mood == "chase":
        step = 60 / 160 / 2
        arp = [60, 64, 67, 72, 67, 64]
        out = np.zeros((n, 2))
        for k, s in enumerate(np.arange(0, dur, step)):
            out += hits(n, [s], lambda k=k: pluck(arp[k % 6], pan=0.3 if k % 2 else 0.7))
            if k % 2 == 0:
                out += hits(n, [s], kick)
        return out
    if mood == "happy":
        step = 60 / 120 / 2
        arp = [72, 76, 79, 76, 74, 77, 81, 77]
        out = pad(n, [[48, 52, 55, 60], [53, 57, 60, 65]], 4, 0.08)
        for k, s in enumerate(np.arange(0, dur, step)):
            out += hits(n, [s], lambda k=k: pluck(arp[k % 8], 0.25, 0.12, square=False, pan=0.4 if k % 2 else 0.6))
        return out
    # calm (default)
    out = pad(n, [[48, 55, 59, 64], [45, 52, 55, 60], [41, 48, 52, 57], [43, 50, 52, 59]], 8, 0.1)
    bells = [s + rng.uniform(-0.5, 0.5) for s in np.arange(2.0, dur - 2, 4.5)]
    for s in bells:
        out += hits(n, [s], lambda: pluck(int(rng.choice([72, 74, 76, 79, 81])), 3.0, 0.12, square=False, pan=rng.uniform(0.2, 0.8)))
    return out


def main():
    build = pathlib.Path(sys.argv[1])
    shots = json.loads((build / "shots.json").read_text(encoding="utf-8"))["shots"]
    # Merge consecutive shots with the same mood into one section.
    sections = []
    for s in shots:
        mood = s.get("music", "calm")
        if sections and sections[-1][0] == mood:
            sections[-1][1] += s["duration"]
        else:
            sections.append([mood, s["duration"]])
    parts = []
    for i, (mood, dur) in enumerate(sections):
        a = mood_audio(mood, dur)
        peak = np.abs(a).max()
        if peak > 0:
            a = a / peak * (0.35 if mood == "silence" else 0.6 if mood in ("horror", "void") else 0.85)
        # Short fades between sections, except the very end (a hard cut lets Shorts loop).
        f = int(0.15 * SR)
        if i > 0:
            a[:f] *= np.linspace(0, 1, f)[:, None]
        if i < len(sections) - 1:
            a[-f:] *= np.linspace(1, 0, f)[:, None]
        parts.append(a)
    mix = np.concatenate(parts)
    mix = mix / max(np.abs(mix).max(), 1e-9) * 0.85
    with wave.open(str(build / "music.wav"), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((mix * 32767).astype(np.int16).tobytes())
    print("music:", " → ".join(f"{m} {d:g}s" for m, d in sections))


if __name__ == "__main__":
    main()
