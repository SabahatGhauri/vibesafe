"""Long copyright-free horror background score (drone, wind, dissonant pads, music box, heartbeat, stingers).

Usage: python horror_score.py <out.wav> <seconds> [section_starts...]
Each section start (in seconds) raises the intensity one step; the last section ends on a lone music box.
Example (100 Days on a Haunted Island, 19:14): python horror_score.py score.wav 1154 0 249 492 725 936
"""
import sys
import wave

import numpy as np
from scipy.signal import butter, oaconvolve, sosfilt

SR = 44100
rng = np.random.default_rng(13)


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def env(t, a, b, fade):
    """1 between a and b with soft fades, 0 outside."""
    return np.clip((t - a) / fade, 0, 1) * np.clip((b - t) / fade, 0, 1)


def place(out, start, snd):
    i0 = int(start * SR)
    if i0 >= len(out):
        return
    j = min(len(out), i0 + len(snd))
    out[i0:j] += snd[: j - i0]


def stereo(s, pan=0.5):
    return np.stack([s * (1 - pan) * 2 ** 0.5, s * pan * 2 ** 0.5], axis=1) / 2 ** 0.5


def drone(t, root=26):
    """Low D drone with slow beating and a breathing swell."""
    s = np.zeros_like(t)
    for m, lvl in ((root, 1.0), (root + 7, 0.45), (root + 12, 0.3), (root + 13, 0.12)):
        for det in (-0.15, 0.15):
            s += lvl * np.sin(2 * np.pi * (hz(m) + det) * t + rng.uniform(0, 6))
    breathe = 0.65 + 0.35 * np.sin(2 * np.pi * t / 23.0)
    return 0.05 * s * breathe


def wind(n, t):
    noise = rng.standard_normal((n, 2))
    sos = butter(2, [120, 600], btype="band", fs=SR, output="sos")
    w = sosfilt(sos, noise, axis=0)
    gust = 0.4 + 0.6 * np.clip(np.sin(2 * np.pi * t / 37.0) * np.sin(2 * np.pi * t / 11.3 + 1), 0, 1)
    return 0.045 * w * gust[:, None]


PADS = [(50, 51, 57, 62), (50, 53, 56, 61), (46, 50, 53, 58), (49, 52, 55, 61), (50, 51, 55, 58)]


def pads(t, intensity):
    out = np.zeros((len(t), 2))
    span = 16.0
    for k, start in enumerate(np.arange(0, t[-1], span)):
        i0, i1 = int(start * SR), min(len(t), int((start + span + 4) * SR))
        tt = t[i0:i1]
        e = env(tt, start, start + span + 4, 4.0) * (0.5 + 0.5 * intensity[i0:i1])
        for m in PADS[k % len(PADS)]:
            for ch, det in ((0, -0.3), (1, 0.3)):
                vib = hz(m) * 0.004 / 5.1 * np.sin(2 * np.pi * 5.1 * tt + m)  # phase-integrated vibrato
                out[i0:i1, ch] += 0.03 * e * np.sin(2 * np.pi * hz(m) * tt + vib + det)
    return out


def box_note(m, dur=2.2, level=0.09):
    tt = np.arange(int(dur * SR)) / SR
    f = hz(m)
    s = (np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * f * 3.01 * tt) + 0.15 * np.sin(2 * np.pi * f * 5.4 * tt))
    return level * s * np.exp(-tt * 3.2) * np.clip(tt / 0.004, 0, 1)


LULLABY = [(74, 0), (77, 1), (76, 2), (74, 3), (73, 4.5), (74, 5), (69, 6),
           (70, 8), (69, 9), (67, 10), (65, 11), (64, 12.5), (62, 13)]


def lullaby(start, tempo=0.62, transpose=0, wobble=0.0):
    """Creepy lullaby phrase; wobble detunes later notes (the box is 'breaking')."""
    out = np.zeros((int(12 * SR), 2))
    for i, (m, beat) in enumerate(LULLABY):
        cents = wobble * rng.uniform(-60, 60) * i / len(LULLABY)
        note = box_note(m + transpose + cents / 100)
        place(out, beat * tempo, stereo(note, 0.35 + 0.3 * rng.random()))
    return start, out


def heartbeat():
    tt = np.arange(int(0.45 * SR)) / SR
    a = np.sin(2 * np.pi * 50 * tt) * np.exp(-tt * 16)
    b = np.zeros_like(a)
    d = int(0.2 * SR)
    b[d:] = 0.65 * a[:-d]
    return stereo(0.32 * (a + b))


def stinger():
    """Reverse swell into a dissonant hit."""
    dur = 3.0
    tt = np.arange(int(dur * SR)) / SR
    swell = rng.standard_normal(len(tt)) * (tt / dur) ** 3
    sos = butter(2, 2500, fs=SR, output="sos")
    swell = sosfilt(sos, swell) * 0.25
    hit_t = np.arange(int(2.5 * SR)) / SR
    hit = sum(np.sin(2 * np.pi * hz(m) * hit_t) for m in (38, 39, 50, 51, 63)) * np.exp(-hit_t * 2.2)
    hit += 0.6 * np.sin(2 * np.pi * 36 * hit_t) * np.exp(-hit_t * 4)
    s = np.concatenate([swell, 0.09 * hit])
    return stereo(s), dur


def screech(dur=5.0):
    """Thin high string glide with vibrato."""
    tt = np.arange(int(dur * SR)) / SR
    f = hz(86) * (1 - 0.06 * tt / dur) * (1 + 0.008 * np.sin(2 * np.pi * 6.5 * tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    e = np.clip(tt / 1.5, 0, 1) * np.clip((dur - tt) / 1.5, 0, 1)
    return stereo(0.022 * e * (np.sin(ph) + 0.3 * np.sin(2 * ph)), rng.uniform(0.2, 0.8))


def reverb(x, seconds=3.2, mix=0.35):
    n = int(seconds * SR)
    tt = np.arange(n) / SR
    out = np.empty_like(x)
    for ch in range(2):
        ir = rng.standard_normal(n) * np.exp(-tt * 6.9 / seconds)
        ir /= np.sqrt(np.sum(ir ** 2))
        out[:, ch] = oaconvolve(x[:, ch], ir)[: len(x)]
    return (1 - mix) * x + mix * out


def main():
    path, total = sys.argv[1], float(sys.argv[2])
    sections = [float(s) for s in sys.argv[3:]] or [0.0]
    n = int(total * SR)
    t = np.arange(n) / SR

    # Intensity 0..1 rises by section and inside each section (dread builds toward each cliffhanger).
    intensity = np.zeros(n)
    bounds = sections + [total]
    for k in range(len(sections)):
        a, b = bounds[k], bounds[k + 1]
        i0, i1 = int(a * SR), int(b * SR)
        base = k / max(1, len(sections) - 1)
        intensity[i0:i1] = 0.25 + 0.5 * base + 0.25 * ((t[i0:i1] - a) / (b - a)) ** 2

    bed = stereo(drone(t)) * (0.8 + 0.4 * intensity[:, None])
    bed += wind(n, t) * (0.6 + 0.6 * intensity[:, None])
    bed += pads(t, intensity)

    fx = np.zeros((n, 2))
    # Music box phrases: sparse early, more broken later.
    s = 6.0
    while s < total - 14:
        i = intensity[int(s * SR)]
        start, ph = lullaby(s, tempo=0.62 + 0.2 * i, transpose=-12 if rng.random() < i * 0.5 else 0, wobble=i)
        place(fx, start, ph)
        s += rng.uniform(55, 80) * (1.2 - 0.5 * i)

    # Heartbeat in the last 45 s of each section (the cliffhangers), speeding up.
    for k in range(len(sections)):
        end = bounds[k + 1]
        beat, bt = 1.1, max(bounds[k], end - 45)
        while bt < end - 3:
            place(fx, bt, heartbeat())
            beat = max(0.62, beat * 0.985)
            bt += beat

    # Stingers and high screeches spread through, denser as intensity rises.
    s = 40.0
    while s < total - 20:
        snd, lead = stinger()
        place(fx, s - lead, snd)
        s += rng.uniform(70, 120) * (1.3 - 0.6 * intensity[int(s * SR)])
    s = 25.0
    while s < total - 10:
        place(fx, s, screech(rng.uniform(4, 7)))
        s += rng.uniform(45, 90)

    # Ending: everything fades out, one last lone lullaby, silence.
    fade = np.clip((total - 16 - t) / 10, 0, 1)
    mix = bed * fade[:, None] + fx * np.clip((total - 15 - t) / 3, 0, 1)[:, None]
    start, ph = lullaby(total - 14, tempo=0.85, wobble=1.0)
    place(mix, start, ph * 1.3)
    mix *= np.clip(t / 4, 0, 1)[:, None]  # fade in

    mix = reverb(mix)
    mix = np.tanh(mix / np.max(np.abs(mix)) * 1.4) / np.tanh(1.4) * 0.85
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print(f"wrote {path} ({total:.0f}s)")


if __name__ == "__main__":
    main()
