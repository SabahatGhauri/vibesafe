"""Synthesize game sound effects per shot from the render's cues (footsteps, wood clacks), copyright-free.
Usage: python make_sfx.py <build_dir>   (reads cues.json, writes sfx/shotN.wav)"""
import json
import pathlib
import sys
import wave

import numpy as np

SR = 48000
rng = np.random.default_rng(11)


def lowpass(x, cutoff):
    a = np.exp(-2 * np.pi * cutoff / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc = a * acc + (1 - a) * v
        y[i] = acc
    return y


def footstep(level):
    n = int(0.11 * SR)
    t = np.arange(n) / SR
    crunch = lowpass(rng.standard_normal(n), rng.uniform(1800, 2600)) * np.exp(-t * 45)
    thump = np.sin(2 * np.pi * rng.uniform(70, 90) * t) * np.exp(-t * 40) * 0.6
    s = crunch * 3 + thump
    return level * s / np.abs(s).max()


def clack(level, pitch):
    n = int(0.35 * SR)
    t = np.arange(n) / SR
    knock = lowpass(rng.standard_normal(n), 900) * np.exp(-t * 30) * 4
    body = (np.sin(2 * np.pi * 180 * pitch * t) + 0.5 * np.sin(2 * np.pi * 330 * pitch * t)) * np.exp(-t * 18)
    creak = np.sin(2 * np.pi * (420 + 160 * t) * pitch * t) * np.exp(-t * 12) * 0.25
    s = knock + body + creak
    return level * s / np.abs(s).max()


def noise(n):
    return rng.standard_normal(n)


def env(n, attack, decay):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(attack, 1e-4)) * np.exp(-t * decay)


def thud(level):
    n = int(0.6 * SR)
    t = np.arange(n) / SR
    s = np.sin(2 * np.pi * (45 + 40 * np.exp(-t * 20)) * t) * env(n, 0.003, 7) + 0.5 * lowpass(noise(n), 300) * env(n, 0.002, 14) * 6
    return level * s / np.abs(s).max()


def scrape(level, dur=1.2):
    n = int(dur * SR)
    t = np.arange(n) / SR
    grit = lowpass(noise(n), 1400) * (1 + 0.6 * np.sign(np.sin(2 * np.pi * 23 * t)))
    shape = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.6
    s = grit * shape
    return level * s / np.abs(s).max()


def tick(level):
    n = int(0.05 * SR)
    s = noise(n) * env(n, 0.0005, 180) + np.sin(2 * np.pi * 2400 * np.arange(n) / SR) * env(n, 0.0005, 120) * 0.5
    return level * 0.35 * s / np.abs(s).max()


def breath(level, dur=3.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    air = lowpass(noise(n), 900) - lowpass(noise(n), 200)
    cycle = np.abs(np.sin(np.pi * t / 0.75)) ** 2  # fast, scared breathing
    s = air * cycle
    return level * 0.7 * s / np.abs(s).max()


def break_block(level):
    n = int(0.35 * SR)
    s = lowpass(noise(n), 2200) * env(n, 0.001, 16) * 3 + np.sin(2 * np.pi * 110 * np.arange(n) / SR) * env(n, 0.001, 25)
    return level * s / np.abs(s).max()


def swing(level):
    n = int(0.25 * SR)
    t = np.arange(n) / SR
    s = (lowpass(noise(n), 1600) - lowpass(noise(n), 400)) * np.sin(np.pi * t / 0.25)
    return level * 0.5 * s / np.abs(s).max()


def sting(level, dur=1.6):
    n = int(dur * SR)
    t = np.arange(n) / SR
    tone = np.sin(2 * np.pi * (2600 + 900 * np.sin(2 * np.pi * 7 * t)) * t)
    crush = np.round(noise(n) * 4) / 4
    s = (tone * 0.7 + crush * 0.5) * np.minimum(1, t / 0.01)
    s[int(0.9 * n):] *= np.linspace(1, 0, n - int(0.9 * n))
    return level * s / np.abs(s).max()


def rumble(level, dur):
    n = int(dur * SR)
    return level * 0.35 * lowpass(noise(n), 90) / 0.05


def static_burst(level, dur=1.2):
    n = int(dur * SR)
    t = np.arange(n) / SR
    white = noise(n)
    s = white * (0.7 + 0.3 * np.sign(np.sin(2 * np.pi * 50 * t))) + 0.4 * np.sign(np.sin(2 * np.pi * 120 * t))
    s *= np.minimum(1, t / 0.005)
    return level * 0.9 * s / np.abs(s).max()


def whoosh(level, dur=1.5):
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = lowpass(noise(n), 700) * np.sin(np.pi * t / dur) ** 2 + 0.4 * np.sin(2 * np.pi * (200 - 150 * t / dur) * t) * np.exp(-t * 1.5)
    return level * s / np.abs(s).max()


def blip(level):
    """Short digital glitch: bit-crushed chirp + noise stutter (~0.18 s)."""
    n = int(0.18 * SR)
    t = np.arange(n) / SR
    chirp = np.sign(np.sin(2 * np.pi * (1800 - 7000 * t) * t))
    gate = (np.sin(2 * np.pi * 45 * t) > 0).astype(float)
    s = (0.6 * chirp + 0.5 * np.round(noise(n) * 3) / 3) * gate * np.exp(-t * 9)
    return level * s / np.abs(s).max()


# ---- Kids / meme pack: bright, punchy hits for fast-paced edits ----
def boom(level):
    """Deep bass drop ("vine boom"): pitch-dropping sine + click, ~1.2 s."""
    n = int(1.2 * SR)
    t = np.arange(n) / SR
    f = 95 * np.exp(-t * 1.6) + 38
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 2.6)
    s += 0.5 * np.tanh(4 * s) + 0.3 * noise(n) * np.exp(-t * 60)
    return level * s / np.abs(s).max()


def pop(level):
    n = int(0.12 * SR)
    t = np.arange(n) / SR
    s = np.sin(2 * np.pi * (900 - 4000 * t) * t) * np.exp(-t * 45)
    return level * s / np.abs(s).max()


def boing(level):
    n = int(0.7 * SR)
    t = np.arange(n) / SR
    f = 180 + 260 * np.exp(-t * 5) * (1 + 0.5 * np.sin(2 * np.pi * 14 * t))
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 4)
    return level * s / np.abs(s).max()


def ding(level):
    n = int(1.4 * SR)
    t = np.arange(n) / SR
    s = sum(a * np.sin(2 * np.pi * 1318 * m * t) for a, m in ((1, 1), (0.4, 2.76), (0.2, 5.4))) * np.exp(-t * 3.5)
    return level * s / np.abs(s).max()


def riser(level, dur=1.5):
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = 200 * (8 ** (t / dur))
    s = 0.6 * np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.6 * lowpass(noise(n), 3000) * (t / dur)
    s *= (t / dur) ** 2
    return level * s / np.abs(s).max()


def scratch(level):
    """Record scratch: fast back-and-forth pitched noise, ~0.45 s."""
    n = int(0.45 * SR)
    t = np.arange(n) / SR
    wob = np.sin(2 * np.pi * 9 * t)
    s = lowpass(noise(n), 2500) * (0.5 + 0.5 * np.abs(wob)) + 0.5 * np.sin(2 * np.pi * np.cumsum(400 + 300 * wob) / SR)
    s *= np.exp(-t * 3)
    return level * s / np.abs(s).max()


def dundun(level):
    """Dramatic "dun dun DUNNN" brass hits."""
    out = np.zeros(int(2.4 * SR))
    for start, m, d in ((0.0, 50, 0.32), (0.4, 49, 0.32), (0.8, 45, 1.5)):
        n = int(d * SR)
        t = np.arange(n) / SR
        f = 440.0 * 2 ** ((m - 69) / 12)
        h = sum(np.sign(np.sin(2 * np.pi * f * k * t)) / k for k in (1, 2, 3))
        h = lowpass(h, 1800) * np.minimum(1, t / 0.02) * np.exp(-t * (1.2 if d > 1 else 5))
        i = int(start * SR)
        out[i:i + n] += h
    return level * out / np.abs(out).max()


def sparkle(level):
    out = np.zeros(int(0.9 * SR))
    for k, m in enumerate((2093, 2637, 3136, 4186)):
        n = int(0.5 * SR)
        t = np.arange(n) / SR
        i = int(k * 0.08 * SR)
        out[i:i + n] += np.sin(2 * np.pi * m * t) * np.exp(-t * 9)
    return level * out / np.abs(out).max()


SOUNDS = {"step": footstep, "blip": blip, "static": static_burst, "whoosh": whoosh, "thud": thud, "scrape": scrape, "tick": tick, "breath": breath, "break": break_block, "swing": swing, "sting": sting,
          "boom": boom, "pop": pop, "boing": boing, "ding": ding, "riser": riser, "scratch": scratch, "dundun": dundun, "sparkle": sparkle}


def ambience(kind, dur):
    n = int(dur * SR)
    out = np.zeros(n)
    if kind in ("cave", "cave_red"):
        out += np.clip(rumble(0.5, dur), -0.3, 0.3)
        for s in np.arange(0.7, dur, 2.3):  # water drips
            i = int((s + rng.uniform(-0.4, 0.4)) * SR)
            m = int(0.08 * SR)
            if 0 <= i < n - m:
                tt = np.arange(m) / SR
                out[i:i + m] += 0.25 * np.sin(2 * np.pi * (1800 - 6000 * tt) * tt) * np.exp(-tt * 60)
    if kind in ("clock", "room"):
        for s in np.arange(0.5, dur, 1.0):
            snd = tick(1.0)
            i = int(s * SR)
            out[i:i + len(snd)] += snd[: max(0, min(len(snd), n - i))]
    if kind == "night":
        t = np.arange(n) / SR
        out += 0.06 * lowpass(noise(n), 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.1 * t))
    return out


def main():
    build = pathlib.Path(sys.argv[1])
    cues = json.loads((build / "cues.json").read_text())
    (build / "sfx").mkdir(exist_ok=True)
    for shot_id, info in cues.items():
        buf = np.zeros(int(info["duration"] * SR))
        if info.get("ambience"):
            buf += ambience(info["ambience"], info["duration"])[: len(buf)]
        for c in info["cues"]:
            kind = c["type"]
            if kind == "step":
                snd = footstep(c["level"])
            elif kind in ("scrape", "breath", "sting", "static", "whoosh", "riser") and c.get("dur"):
                snd = SOUNDS[kind](c["level"], c["dur"])
            elif kind in SOUNDS:
                snd = SOUNDS[kind](c["level"])
            else:
                snd = clack(c["level"], c.get("pitch", 1.0))
            i = int(c["t"] * SR)
            j = min(len(buf), i + len(snd))
            if i < len(buf):
                buf[i:j] += snd[: j - i]
        buf = np.clip(buf * 0.8, -1, 1)
        stereo = np.stack([buf, buf], axis=1)
        with wave.open(str(build / "sfx" / f"shot{shot_id}.wav"), "wb") as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes((stereo * 32767).astype(np.int16).tobytes())
    print(f"sfx: {len(cues)} shots")


if __name__ == "__main__":
    main()
