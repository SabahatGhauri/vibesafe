"""Generate voice lines with Kokoro TTS (Apache 2.0, OK for monetized videos), styled like a gaming YouTuber.

Usage: python voice.py <build_dir> [voice] [models_dir]
  voice = a preset below (gamer, gamer_hype, gamer_chill, storyteller) or any raw Kokoro voice (am_michael, af_heart…)
Reads shots.json; writes vo/shotN.wav. Lines you recorded yourself ("vo_file") are never touched.

Per-line emotion in the script: `vo_style: shout | excited | flat | quiet | normal`.
Lines written in CAPS with "!" are treated as shout automatically.
"""
import json
import pathlib
import sys

import numpy as np
import soundfile as sf
from scipy.signal import butter, lfilter, resample_poly

# Presets: a Kokoro voice (or a blend of several), base speed, pitch shift in semitones, mic processing strength.
PRESETS = {
    # Young, quick, punchy: the typical Minecraft Shorts narrator.
    "gamer": {"blend": {"am_puck": 0.7, "am_liam": 0.3}, "speed": 1.2, "pitch": 1.0, "fx": 1.0},
    # Louder and more reactive, for chaotic/funny videos.
    "gamer_hype": {"blend": {"am_puck": 0.5, "am_fenrir": 0.5}, "speed": 1.25, "pitch": 1.8, "fx": 1.2},
    # Relaxed gamer, for build/cozy videos.
    "gamer_chill": {"blend": {"am_liam": 0.6, "am_michael": 0.4}, "speed": 1.1, "pitch": 0.5, "fx": 0.8},
    # Warm storyteller (the original narrator), for mystery/lore.
    "storyteller": {"blend": {"am_michael": 1.0}, "speed": 1.12, "pitch": 0.0, "fx": 0.5},
}

STYLES = {  # pitch (semitones), speed multiplier, gain (dB), extra drive
    "normal": (0.0, 1.0, 0.0, 0.0),
    "excited": (1.2, 1.08, 1.5, 0.2),
    "shout": (2.5, 1.1, 3.0, 0.6),
    "flat": (-1.0, 0.88, -1.0, 0.0),
    "quiet": (-0.5, 0.92, -5.0, 0.0),
}


def voice_style(k, spec):
    if spec in PRESETS:
        spec = PRESETS[spec]["blend"]
    if isinstance(spec, str):
        return k.get_voice_style(spec)
    total = sum(spec.values())
    return sum(k.get_voice_style(name) * (w / total) for name, w in spec.items()).astype(np.float32)


def pitch_shift(audio, semitones):
    """Shift pitch by resampling (this also changes tempo; the caller compensates in the TTS speed)."""
    if abs(semitones) < 0.05:
        return audio
    ratio = 2 ** (semitones / 12)
    up, down = int(round(1000 / ratio)), 1000
    return resample_poly(audio, up, down).astype(np.float32)


def peaking(x, sr, f0, gain_db, q=1.0):
    a = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * f0 / sr
    alpha = np.sin(w0) / (2 * q)
    b = [1 + alpha * a, -2 * np.cos(w0), 1 - alpha * a]
    den = [1 + alpha / a, -2 * np.cos(w0), 1 - alpha / a]
    return lfilter(np.array(b) / den[0], np.array(den) / den[0], x)


def mic_chain(x, sr, amount=1.0, drive=0.0):
    """YouTuber mic sound: cut rumble, a bit of chest warmth, bright presence, compression, gentle saturation."""
    b, a = butter(2, 90 / (sr / 2), "high")
    x = lfilter(b, a, x)
    x = peaking(x, sr, 180, 2.0 * amount, 0.8)
    x = peaking(x, sr, 3800, 4.0 * amount, 0.9)
    x = peaking(x, sr, 9000, 2.0 * amount, 0.7)
    # Compressor (RMS follower): evens out loud/soft words like a streamer's mic.
    env = np.sqrt(lfilter([0.002], [1, -0.998], x ** 2) + 1e-9)
    thr = 0.08
    ratio = 1 + 3 * amount
    gain = np.where(env > thr, (thr + (env - thr) / ratio) / env, 1.0)
    x = x * gain
    # Soft saturation for energy.
    d = 1 + 2 * drive + 0.5 * amount
    x = np.tanh(x * d) / np.tanh(d)
    return x / max(np.abs(x).max(), 1e-9) * 0.95


def line_style(s):
    st = s.get("vo_style")
    if st:
        return st
    text = s.get("vo") or ""
    letters = [c for c in text if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.8 and "!" in text:
        return "shout"
    return "normal"


def synth(k, text, preset, style="normal", speed_mult=1.0):
    p = PRESETS.get(preset, {"blend": preset, "speed": 1.12, "pitch": 0.0, "fx": 0.6})
    sp, sm, gain_db, drive = STYLES.get(style, STYLES["normal"])
    semis = p["pitch"] + sp
    ratio = 2 ** (semis / 12)
    # Pitch shifting by resampling also speeds speech up by `ratio`, so ask the TTS for correspondingly slower speech.
    speed = max(0.5, min(2.0, p["speed"] * sm * speed_mult / ratio))
    audio, sr = k.create(text, voice=voice_style(k, preset), speed=speed, lang="en-us")
    audio = pitch_shift(audio, semis)
    audio = mic_chain(audio, sr, p["fx"], drive) * (10 ** (gain_db / 20))
    idx = np.where(np.abs(audio) > 0.02)[0]  # trim silence so the line starts exactly at vo_at
    if len(idx):
        audio = audio[max(0, idx[0] - int(0.02 * sr)): idx[-1] + int(0.08 * sr)]
    return audio.astype(np.float32), sr


def main():
    from kokoro_onnx import Kokoro
    build = pathlib.Path(sys.argv[1])
    preset = sys.argv[2] if len(sys.argv) > 2 else "gamer"
    models = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else pathlib.Path(__file__).parent.parent / "models"
    k = Kokoro(str(models / "kokoro-v1.0.onnx"), str(models / "voices-v1.0.bin"))
    shots = json.loads((build / "shots.json").read_text(encoding="utf-8"))["shots"]
    (build / "vo").mkdir(exist_ok=True)
    for s in shots:
        out = build / "vo" / f"shot{s['id']}.wav"
        if not s.get("vo") or s.get("vo_file"):
            continue
        style = line_style(s)
        # vo_speed in the script is relative to the preset's own pace (1.12 was the old default).
        audio, sr = synth(k, s["vo"], s.get("voice", preset), style, s.get("vo_speed", 1.12) / 1.12)
        sf.write(out, audio, sr)
        end = s.get("vo_at", 0) + len(audio) / sr
        warn = f"  ⚠ runs {end - s['duration']:.1f}s past the shot" if end > s["duration"] + 0.3 else ""
        print(f"voice shot{s['id']} [{style}]: {len(audio) / sr:.2f}s{warn}")


if __name__ == "__main__":
    main()
