"""Make one voice sample for the app's ▶ button.
Usage: echo "text" | python voice_sample.py <voice> <style> <out.wav> <models_dir>"""
import pathlib
import sys

import soundfile as sf
from kokoro_onnx import Kokoro

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import voice as V  # noqa: E402

voice, style, out, models = sys.argv[1], sys.argv[2], sys.argv[3], pathlib.Path(sys.argv[4])
text = sys.stdin.read().strip() or "Hello!"
k = Kokoro(str(models / "kokoro-v1.0.onnx"), str(models / "voices-v1.0.bin"))
audio, sr = V.synth(k, text, voice, style if style in V.STYLES else "normal")
sf.write(out, audio, sr)
