"""Build the vertical Short (1080x1920, 60 fps) from the clips in a build folder.
Usage: python assemble.py <build_dir> <output.mp4>

Put your recordings in clips/shot1.mp4 ... clips/shot7.mp4 (any length; each is trimmed to the shot's
duration in shots.json, starting at its "clip_start" seconds). Missing clips become labelled placeholder cards, so you can
render a timing preview (animatic) before recording anything.
Voice lines go in vo/shot1.wav ... (missing lines are skipped). Music: music.wav (from make_music.py).

Usage: python assemble.py            -> short.mp4
Needs: ffmpeg on PATH (or `pip install imageio-ffmpeg`), and `pip install pillow`.
"""
import json
import pathlib
import shutil
import sys
import subprocess

from PIL import Image, ImageDraw, ImageFont

HERE = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(__file__).parent
BUILD = HERE / "tmp"
OUT = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / "short.mp4"
W, H, FPS = 1080, 1920, 60


def ffmpeg_exe():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


FF = ffmpeg_exe()


def run(args):
    subprocess.run([FF, "-y", "-hide_banner", "-loglevel", "error", *args], check=True)


def has_audio(path):
    r = subprocess.run([FF, "-hide_banner", "-i", str(path)], capture_output=True, text=True)
    return "Audio:" in r.stderr


def font(size):
    for name in ("DejaVuSans-Bold.ttf", "arialbd.ttf", "Arial Bold.ttf",
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                 "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def find(folder, stem):
    for ext in (".mp4", ".mkv", ".mov", ".wav", ".mp3", ".m4a"):
        p = HERE / folder / f"{stem}{ext}"
        if p.exists():
            return p
    return None


def wrap(d, text, f, max_w, stroke):
    """Re-wrap each line so it fits within max_w pixels."""
    out = []
    for para in text.split("\n"):
        line = ""
        for word in para.split():
            trial = f"{line} {word}".strip()
            if line and d.textlength(trial, font=f) + 2 * stroke > max_w:
                out.append(line)
                line = word
            else:
                line = trial
        out.append(line)
    return "\n".join(out)


def drawable(text):
    """Drop emoji and joiners: the caption font has no glyphs for them (they would show as empty boxes)."""
    return "".join(ch for ch in text if ord(ch) < 0x1F000 and ord(ch) not in (0xFE0F, 0x200D)).replace("  ", " ").strip()


def draw_centered(img, text, size, y, fill="white", stroke=8, max_w=940):
    text = drawable(text)
    d = ImageDraw.Draw(img)
    f = font(size)
    text = wrap(d, text, f, max_w, stroke)
    box = d.multiline_textbbox((0, 0), text, font=f, align="center", stroke_width=stroke, spacing=12)
    x = (W - (box[2] - box[0])) / 2
    d.multiline_text((x, y), text, font=f, fill=fill, align="center",
                     stroke_width=stroke, stroke_fill="black", spacing=12)


def placeholder(shot, path):
    img = Image.new("RGB", (W, H), (28, 32, 40))
    draw_centered(img, f"SHOT {shot['id']}", 110, 520, fill=(255, 200, 80), stroke=0)
    words, lines, line = shot["shot"].split(), [], ""
    for w in words:  # simple word wrap
        if len(line) + len(w) > 26:
            lines.append(line)
            line = w
        else:
            line = f"{line} {w}".strip()
    lines.append(line)
    draw_centered(img, "\n".join(lines), 54, 700, fill=(220, 220, 220), stroke=0)
    draw_centered(img, f"record clips/shot{shot['id']}.mp4", 40, 1650, fill=(140, 140, 140), stroke=0)
    img.save(path)


def caption_png(shot, path):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    landscape = W > H
    size = shot.get("caption_size")  # optional override in pixels
    if shot.get("caption_style") == "big":
        if landscape:
            draw_centered(img, shot["caption"], size or 170, H // 2 - 110, fill=(255, 60, 60), stroke=12, max_w=W - 200)
        else:
            draw_centered(img, shot["caption"], size or 260, 780 if not size else int(1300 - size * 4.5), fill=(255, 60, 60), stroke=14)
    elif landscape:
        # Lower third, like subtitles.
        draw_centered(img, shot["caption"], 52, H - 220, stroke=6, max_w=W - 360)
    else:
        # Keep captions above Shorts' bottom UI (title, buttons) and away from edges.
        draw_centered(img, shot["caption"], 64, 1180)
    img.save(path)


def main():
    global W, H
    data = json.loads((HERE / "shots.json").read_text(encoding="utf-8"))
    shots = data["shots"]
    if data.get("format") == "landscape":
        W, H = 1920, 1080
    BUILD.mkdir(exist_ok=True)

    # 1) One normalized segment per shot (video + game audio, exact duration).
    seg_list, start, timeline = [], 0.0, []
    for s in shots:
        dur, seg = s["duration"], BUILD / f"seg{s['id']}.mp4"
        clip = find("clips", f"shot{s['id']}")
        vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={FPS},setsar=1"
        if s.get("punch_in"):  # fast punch-in over the first 0.5 s
            vf += f",zoompan=z='min(1+0.35*on/{FPS // 2},1.35)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s={W}x{H}:fps={FPS}"
        if clip:
            inputs = ["-ss", str(s.get("clip_start", 0.0)), "-t", str(dur), "-i", str(clip)]
            audio = "[0:a]aresample=48000,aformat=channel_layouts=stereo,apad[a]" if has_audio(clip) else None
        else:
            png = BUILD / f"placeholder{s['id']}.png"
            placeholder(s, png)
            inputs = ["-loop", "1", "-t", str(dur), "-i", str(png)]
            audio = None
        inputs += ["-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=48000:cl=stereo"]
        # tpad holds the last frame if a clip is shorter than its shot, so timing never drifts.
        fc = f"[0:v]{vf},tpad=stop_mode=clone:stop_duration={dur},format=yuv420p[v];" + (audio or "[1:a]anull[a]")
        run([*inputs, "-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-t", str(dur),
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-c:a", "aac", "-b:a", "192k", str(seg)])
        seg_list.append(seg)
        timeline.append((s, start))
        start += dur
    total = start

    concat = BUILD / "concat.txt"
    concat.write_text("".join(f"file '{p.name}'\n" for p in seg_list))
    body = BUILD / "body.mp4"
    run(["-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", str(body)])

    # 2) Final pass: captions, voice, ducked music, loudness for YouTube.
    inputs, vchain, n = ["-i", str(body)], "[0:v]", 1
    music = HERE / "music.wav"
    filters, last_v = [], "[0:v]"
    for s, t0 in timeline:
        if not s.get("caption"):
            continue
        png = BUILD / f"caption{s['id']}.png"
        caption_png(s, png)
        a = t0 + s.get("caption_at", s.get("vo_at", 0.0))
        b = t0 + s["duration"]
        inputs += ["-i", str(png)]
        filters.append(f"{last_v}[{n}:v]overlay=0:0:enable='between(t,{a:.2f},{b:.2f})'[v{n}]")
        last_v, n = f"[v{n}]", n + 1

    vo_labels = []
    for s, t0 in timeline:
        vo = find("vo", f"shot{s['id']}")
        if not vo:
            continue
        ms = int((t0 + s.get("vo_at", 0.0)) * 1000)
        inputs += ["-i", str(vo)]
        filters.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,adelay={ms}|{ms},volume=1.6[vo{n}]")
        vo_labels.append(f"[vo{n}]")
        n += 1

    filters.append("[0:a]volume=0.55[game]")
    mix_inputs = ["[game]"]
    if vo_labels:
        filters.append(f"{''.join(vo_labels)}amix=inputs={len(vo_labels)}:normalize=0,asplit=2[vo][key]")
        mix_inputs.append("[vo]")
    if music.exists():
        inputs += ["-i", str(music)]
        filters.append(f"[{n}:a]aresample=48000,volume=0.45[mus]")
        if vo_labels:  # duck music under the voice
            filters.append("[mus][key]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=300[musd]")
            mix_inputs.append("[musd]")
        else:
            mix_inputs.append("[mus]")
        n += 1
    filters.append(f"{''.join(mix_inputs)}amix=inputs={len(mix_inputs)}:normalize=0,"
                   "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[aout]")

    out = OUT
    # With no captions there is no video filter output, so map the input stream directly.
    video_map = "0:v" if last_v == "[0:v]" else last_v
    run([*inputs, "-filter_complex", ";".join(filters), "-map", video_map, "-map", "[aout]",
         "-t", f"{total:.2f}", "-r", str(FPS), "-c:v", "libx264", "-preset", "medium", "-crf", "18",
         "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)])
    print(f"wrote {out} ({total:.0f}s)")
    shutil.rmtree(BUILD, ignore_errors=True)


if __name__ == "__main__":
    main()
